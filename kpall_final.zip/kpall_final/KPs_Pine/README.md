# KP's Pine

Scan + Pine strategy - auto option SL guard - Android app (Chaquopy + WebView), dashboard port 5052.

Engine = latest KP's Algo AI build (Futures + Options, Profit lock, Auto SL, Pine guard).
Look = colourful per-app theme (static/kp_ui.css) + bottom navigation (static/kp_nav.js).
Build: see ../HOW_TO_BUILD.md
