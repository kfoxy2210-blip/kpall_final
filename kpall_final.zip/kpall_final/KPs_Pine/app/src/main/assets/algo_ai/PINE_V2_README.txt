KP's Pine v2 - poori Pine script ab project me chalti hai
==========================================================
Nayi file: pine_orb2.py (plain Python, app.py usse scan_mode me jodta hai). Baaki sab (scanner, orders, Stop, DRY/LIVE, safety gates) pehle jaisa.

Pine script ke saare inputs ab dashboard me hain (Scan + Pine > 'Pine strategy settings'):
  LONG/SHORT, min % beyond 9:15 open, min TICKS move, candle CLOSE confirm, Timeframe auto-adapt (entry window + exit time) ya manual 'entries till 9:XX',
  Stop loss %, Risk:Reward, ATR trailing stop after 1R (ATR length, multiplier), Gap filter, EMA trend filter (EMA length), Force exit time.

Accuracy (sahi signal):
  * Candle CLOSE confirm ab candle-exact hai: jab last tick trigger level ke bilkul paas ho tab Kite ka OFFICIAL candle liya jata hai,
    isliye signal TradingView/Kite candle se match karta hai.
  * EMA aur ATR REAL candle history (8 din) se nikalte hain, ATR Pine ke RMA rule se (live candle ke saath).
  * Entry window / exit time ke formulas Pine ke formulas se ek-ek karke match (rounding, ceil, manual mode).
  * Trend filter ON ho aur EMA data na mile to trade NAHI hota (safe).
Speed:
  * History price-feed bante hi (9:15 se pehle) background me load ho jati hai, 9:15 par koi intezaar nahi.
  * Saaf breakout / no-breakout live tick se turant decide hota hai (koi network call nahi); official candle sirf marginal case me.
  * EMA/ATR ki refine background thread me.

Test: python test_pine_orb2.py   (Pine formulas, 600 simulated days vs candle-based reference, trend veto, ATR trail, fallback)
Note: 'Wait for candle CLOSE' ab default ON hai (Pine script ke default jaisa). Band karoge to instant-on-price mode chalta hai.
Agar pine_orb2 load na ho to purani standard Pine strategy chalti rehti hai (console me message aata hai).

Data-fetching fix (v2.1): "indicator history not available" / "trend filter ON but EMA is not available"
  Cause: Kite allows only 3 historical-data requests per second. Scan + Pine opens many price feeds together, so some of them
  were refused and those stocks were left with no EMA / ATR data (and with the trend filter ON they could not trade).
  Now: all history requests share one speed limit (max 2.5 per second) and are retried 3 times; one fetch per stock at a time;
  history before today is loaded once and kept for the session (nothing is requested again in the 9:15 rush); a failed load is
  retried in the background every 20 s; and the trend filter makes one last quick attempt before it refuses a trade.
  If it still says "not available (...)", the text in brackets is Kite's own reason (for example a missing historical-data permission on the API key).
