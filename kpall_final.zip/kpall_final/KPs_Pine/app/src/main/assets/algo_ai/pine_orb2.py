"""KP's Pine v2 - the COMPLETE "Instant Open-Break 9:15 Breakout | Exit @Time | TF-ADAPTIVE (Fixed)" Pine script in Python.

It plugs into the existing Scan + Pine runner (scan_mode.py) by replacing its strategy class, so the scanner,
the order engine, the stop buttons, DRY/LIVE and every safety gate stay exactly as they were.

Everything of the Pine script is here
  Direction .......... Take LONG (CALL) / Take SHORT (PUT)
  Entry .............. min % beyond the 9:15 open, min TICKS move, wait for candle CLOSE (or instant)
  Timeframe adaptive . entry window = N candles after 9:15 (auto), or "allow entries till 9:XX" (manual);
                       exit time pushed forward on big candles exactly like the script
  Risk ............... fixed stop-loss %, target = R:R x risk, optional ATR trailing stop after 1R
  Filters ............ gap filter, EMA trend filter
  Time ............... force exit at the exit time (IST)
  One trade per day per stock.

What is better than the plain port (accuracy + speed)
  ACCURACY
  * Candle-exact confirmation: at every candle close the breakout test uses the candle CLOSE.  When the last tick is
    far from the trigger level the decision is taken instantly from the tick; only when it is within a hair of the
    level (where one tick of difference could flip the decision) the OFFICIAL candle is fetched from Kite, so the
    signal matches the TradingView / Kite candle.
  * EMA (trend filter) and ATR (trailing) are computed from REAL candle history (several days, so they are already
    "warm" at 9:15 - same numbers TradingView shows), ATR uses Pine's own RMA rule including the live bar.
  * Window / exit-time maths copies the Pine formulas one to one (rounding, ceil, manual mode).
  SPEED
  * History for EMA / ATR is pre-loaded in the background the moment the price feed is created (before 9:15), so
    nothing waits at the open.
  * Clear breakouts / non-breakouts are decided from the live tick with no network call; the official candle is
    only used for the rare marginal ones, and candle refinement for indicators runs in a background thread.
Every network call is wrapped: if Kite history is not available the strategy falls back to tick-built candles (the
same behaviour as before) and keeps trading; a missing trend-filter value never creates a trade.
"""
import dataclasses
import math
import threading
import time
from dataclasses import dataclass, fields
from datetime import datetime, timedelta, timezone

IST = timezone(timedelta(hours=5, minutes=30))
MARKET_OPEN_MOD = 9 * 60 + 15            # 555
_INTERVALS = {1.0: "minute", 3.0: "3minute", 5.0: "5minute", 10.0: "10minute",
              15.0: "15minute", 30.0: "30minute", 60.0: "60minute"}
HISTORY_DAYS = 8


def ist_now():
    return datetime.now(IST)


def _mod(dt):
    return dt.hour * 60 + dt.minute


def _secs(dt):
    return dt.hour * 3600 + dt.minute * 60 + dt.second + dt.microsecond / 1e6


def _round_half_up(x):
    return int(math.floor(x + 0.5))


# ----------------------------------------------------------------------------- parameters (all Pine inputs)
@dataclass
class PineParams:
    trade_long: bool = True
    trade_short: bool = True
    breakout_buf_pct: float = 0.15
    min_ticks_move: int = 1
    confirm_on_close: bool = True
    tf_min: float = 1.0
    entry_bars: int = 5
    sl_pct: float = 0.3
    rr: float = 1.5
    use_gap_filter: bool = False
    max_gap_pct: float = 2.0
    exit_hour: int = 9
    exit_minute: int = 30
    mintick: float = 0.05
    # --- new in the latest Pine script
    tf_adaptive: bool = True         # (the dashboard sends its own values; its default is the fixed 9:15-9:25 window)
    entry_end_minute: int = 20
    use_trail: bool = False
    atr_len: int = 14
    atr_mult: float = 1.0
    use_trend_filter: bool = False
    ema_len: int = 50

    @classmethod
    def from_dict(cls, d):
        p = cls()
        for f in fields(cls):
            if not isinstance(d, dict) or f.name not in d:
                continue
            v = d[f.name]
            cur = getattr(p, f.name)
            if isinstance(cur, bool):
                v = v if isinstance(v, bool) else str(v).strip().lower() in ("1", "true", "yes", "on")
            elif isinstance(cur, int):
                v = int(float(v))
            else:
                v = float(v)
            setattr(p, f.name, v)
        p.validate()
        return p

    def validate(self):
        def need(cond, msg):
            if not cond:
                raise ValueError(msg)
        need(self.trade_long or self.trade_short, "Tick at least LONG or SHORT")
        need(0 <= self.breakout_buf_pct <= 5, "Breakout buffer % must be between 0 and 5")
        need(self.min_ticks_move >= 0, "Min ticks must be 0 or more")
        need(0.1 <= self.tf_min <= 60, "Candle minutes must be between 0.1 and 60")
        need(1 <= self.entry_bars <= 60, "Entry window candles must be between 1 and 60")
        need(15 <= self.entry_end_minute <= 29, "Manual 'entries till minute' must be between 15 and 29")
        need(0.05 <= self.sl_pct <= 10, "Stop loss % must be between 0.05 and 10")
        need(0.5 <= self.rr <= 10, "Risk:Reward must be between 0.5 and 10")
        need(0 <= self.max_gap_pct <= 20, "Max gap % must be between 0 and 20")
        need(1 <= self.atr_len <= 200, "ATR length must be between 1 and 200")
        need(0.1 <= self.atr_mult <= 20, "ATR multiplier must be between 0.1 and 20")
        need(5 <= self.ema_len <= 500, "EMA length must be between 5 and 500")
        need(0 <= self.exit_hour <= 23 and 0 <= self.exit_minute <= 59, "Exit time is invalid")
        need(self.mintick > 0, "mintick must be positive")
        need(self.exit_hour * 60 + self.exit_minute > MARKET_OPEN_MOD, "Exit time must be after 9:15")

    # ---- the Pine formulas, one to one
    @property
    def entry_end_mod(self):
        if self.tf_adaptive:
            window = max(self.tf_min, self.entry_bars * self.tf_min)
            return MARKET_OPEN_MOD + _round_half_up(window)
        return 9 * 60 + self.entry_end_minute

    @property
    def exit_mod(self):
        user = self.exit_hour * 60 + self.exit_minute
        if self.tf_adaptive:
            return max(user, self.entry_end_mod + int(math.ceil(self.tf_min)))
        return user


@dataclass
class Signal:
    direction: str
    price: float
    day_open: float
    level: float
    stop: float
    target: float
    risk: float


# ----------------------------------------------------------------------------- indicators (Pine-exact)
def ema_series(values, n):
    out, e, k = [], None, 2.0 / (n + 1)
    for i, v in enumerate(values):
        if e is None:
            e = v
        else:
            e = v * k + e * (1 - k)
        out.append(e)
    return out


def true_range(h, l, prev_close):
    if prev_close is None:
        return h - l
    return max(h - l, abs(h - prev_close), abs(l - prev_close))


def atr_state(candles, n):
    """Pine ta.atr: RMA of the true range (seeded with the SMA of the first n values). -> (atr, last_close)"""
    atr, seed, prev_c, cnt = None, 0.0, None, 0
    for (_t, _o, h, l, c) in candles:
        tr = true_range(h, l, prev_c)
        cnt += 1
        if atr is None:
            seed += tr
            if cnt >= n:
                atr = seed / n
        else:
            atr = (atr * (n - 1) + tr) / n
        prev_c = c
    if atr is None and cnt:
        atr = seed / cnt
    return atr, prev_c


# ----------------------------------------------------------------------------- history cache (pre-loaded before 9:15)
_HIST = {}
_HIST_LOCK = threading.Lock()
_KEY_LOCKS = {}
_API_LOCK = threading.Lock()
_API_LAST = [0.0]
API_MIN_GAP = 0.4            # Kite allows 3 historical-data requests per second; we stay under it
API_TRIES = 3
HISTORY_KEEP_SECONDS = 6 * 3600   # candles before today never change, so one load per session is enough


def paced_history(kite, token, a, b, interval, tries=None):
    """kite.get_intraday_history with a global speed limit and retries. Scan + Pine opens many price feeds at once;
    without this Kite answers 'too many requests' to some of them and those stocks were left with no data."""
    tries = tries or API_TRIES
    last = None
    for i in range(tries):
        with _API_LOCK:
            wait = API_MIN_GAP - (time.time() - _API_LAST[0])
            if wait > 0:
                time.sleep(wait)
            _API_LAST[0] = time.time()
        try:
            return kite.get_intraday_history(token, a, b, interval)
        except Exception as exc:                                            # noqa: BLE001
            last = exc
            time.sleep(0.6 * (i + 1))
    raise last


def _row_to_candle(r):
    d = r["date"]
    d = d.replace(tzinfo=None) if getattr(d, "tzinfo", None) else d
    return (d, float(r["open"]), float(r["high"]), float(r["low"]), float(r["close"]))


def load_history(kite, token, interval, now=None, force=False, max_age=90):
    """Candles of the last HISTORY_DAYS days (naive IST datetimes). Cached for max_age seconds."""
    now = (now or ist_now()).replace(tzinfo=None)
    key = (token, interval)
    with _HIST_LOCK:
        hit = _HIST.get(key)
        if hit and not force and time.time() - hit[0] < max_age:
            return list(hit[1])
        klock = _KEY_LOCKS.setdefault(key, threading.Lock())
    with klock:                                    # one fetch per stock at a time; the others reuse its result
        with _HIST_LOCK:
            hit = _HIST.get(key)
            if hit and not force and time.time() - hit[0] < max_age:
                return list(hit[1])
        rows = paced_history(kite, token, now - timedelta(days=HISTORY_DAYS), now, interval)
        candles = [_row_to_candle(r) for r in (rows or [])]
        candles.sort(key=lambda x: x[0])
        if not candles:
            raise RuntimeError("Kite returned no candles (check the historical-data permission of the API key)")
        with _HIST_LOCK:
            _HIST[key] = (time.time(), candles)
        return list(candles)


# ----------------------------------------------------------------------------- the strategy
class PineOrb:
    """Same public surface as pine_orb.PineOrb (so scan_mode.py needs no change)."""

    def __init__(self, params):
        self.p = params
        self.day_open = None
        self.prev_close = None
        self.taken = False
        self.signal = None
        self._lock = threading.RLock()
        # live bar being built from ticks
        self._bar_idx = None
        self._bar = None            # [open, high, low, last]
        self._last_px = None
        # indicator state (through the last CLOSED candle)
        self._candles = None        # list of (t, o, h, l, c) - history + closed bars
        self._ema = None
        self._atr = None
        self._prev_close_c = None
        self._ind_ready = False
        self._ind_try_at = 0.0
        self._ind_busy = False
        self._last_note = None
        self._feed = None
        self._trail_on = False
        self._today = None
        self.notes = []

    # ------------------------------------------------------------------ simple Pine pieces
    def set_day_open(self, price, prev_close):
        self.day_open = float(price)
        self.prev_close = float(prev_close) if prev_close else None
        self._bind_feed()

    def levels(self):
        if self.day_open is None:
            return None, None
        eff = max(self.day_open * self.p.breakout_buf_pct / 100.0, self.p.min_ticks_move * self.p.mintick)
        return self.day_open + eff, self.day_open - eff

    def gap_pct(self):
        if self.day_open is None or not self.prev_close:
            return None
        return abs(self.day_open - self.prev_close) / self.prev_close * 100.0

    def gap_ok(self):
        if not self.p.use_gap_filter:
            return True
        g = self.gap_pct()
        return g is not None and g <= self.p.max_gap_pct

    def _bar_index(self, now):
        return int((_secs(now) - MARKET_OPEN_MOD * 60) // (self.p.tf_min * 60))

    def _bar_open_mod(self, idx):
        return MARKET_OPEN_MOD + idx * self.p.tf_min

    def _window_ok_for_bar(self, idx):
        bar_open = self._bar_open_mod(idx)
        if idx < 0:
            return False
        if self.p.tf_adaptive:
            return MARKET_OPEN_MOD <= bar_open <= self.p.entry_end_mod
        h, m = int(bar_open // 60), int(bar_open % 60)
        return h == 9 and m >= 15 and m <= self.p.entry_end_minute

    def window_open(self, now):
        return self._window_ok_for_bar(self._bar_index(now))

    def window_closed_for_good(self, now):
        """True only after the LAST allowed candle has closed AND its close was evaluated (1 s grace)."""
        last_close = self.p.entry_end_mod + self.p.tf_min
        if not self.p.tf_adaptive:
            last_close = 9 * 60 + self.p.entry_end_minute + self.p.tf_min
        return _secs(now) >= last_close * 60 + 1.0

    def entry_window_end_text(self):
        end = self.p.entry_end_mod + self.p.tf_min if self.p.tf_adaptive else 9 * 60 + self.p.entry_end_minute + self.p.tf_min
        end = int(round(end))
        return "%02d:%02d" % (end // 60, end % 60)

    def exit_time_text(self):
        return "%02d:%02d" % divmod(self.p.exit_mod, 60)

    def time_exit_due(self, now):
        return _secs(now) >= self.p.exit_mod * 60

    # ------------------------------------------------------------------ feed binding + indicators
    def _bind_feed(self):
        if self._feed is not None:
            return
        self._feed = getattr(_TL, "feed", None)
        if self._feed is not None and (self.p.use_trend_filter or self.p.use_trail):
            self._prepare_indicators()

    def _interval(self):
        return _INTERVALS.get(round(float(self.p.tf_min), 3))

    def _prepare_indicators(self, fresh=False):
        """Candles -> EMA + ATR through the last closed candle. Never raises. fresh=True re-reads Kite."""
        self._ind_try_at = time.time()
        try:
            interval = self._interval()
            f = self._feed
            if interval is None or f is None:
                raise RuntimeError("history needs a 1/3/5/10/15/30/60 minute candle")
            candles = load_history(f.kite, f.token, interval, max_age=HISTORY_KEEP_SECONDS, force=fresh)
            now_naive = ist_now().replace(tzinfo=None)
            span = timedelta(minutes=self.p.tf_min)
            candles = [c for c in candles if c[0] + span <= now_naive]       # closed candles only
            if len(candles) < 5:
                raise RuntimeError("only %d candles of history" % len(candles))
            with self._lock:                         # keep the bars this run has already tracked from ticks
                extra = [c for c in (self._candles or []) if c[0] > candles[-1][0]]
            self._set_candles(candles + extra)
            self._ind_ready = True
            if self._last_note:
                self._note("indicator history loaded (%d candles)" % len(candles))
                self._last_note = None
        except Exception as exc:                                            # noqa: BLE001
            self._ind_ready = False
            self._note("indicator history not available (%s) - will retry" % exc)

    def _maybe_retry_indicators(self):
        """History failed earlier (rate limit / network)? Try again in the background every 20 s."""
        if self._ind_ready or self._ind_busy or self._feed is None:
            return
        if not (self.p.use_trend_filter or self.p.use_trail):
            return
        if time.time() - self._ind_try_at < 20:
            return
        self._ind_busy = True

        def run():
            try:
                self._prepare_indicators(fresh=True)
            finally:
                self._ind_busy = False
        threading.Thread(target=run, daemon=True, name="pine-hist-retry").start()

    def _set_candles(self, candles):
        with self._lock:
            self._candles = list(candles)
            closes = [c[4] for c in self._candles]
            self._ema = ema_series(closes, self.p.ema_len)[-1] if closes else None
            self._atr, self._prev_close_c = atr_state(self._candles, self.p.atr_len)

    def _note(self, msg):
        if "not available" in msg:
            self._last_note = msg
        if self.notes and self.notes[-1] == msg:
            return
        self.notes.append(msg)
        print("[pine v2] %s" % msg)

    # ------------------------------------------------------------------ live bar tracking
    def _track(self, now, price):
        """Update the current bar from a tick. Returns (closed_idx, closed_bar) when a bar just completed."""
        idx = self._bar_index(now)
        closed = None
        with self._lock:
            self._today = now.date()
            if self._bar_idx is None:
                self._bar_idx, self._bar = idx, [price, price, price, price]
            elif idx > self._bar_idx:
                closed = (self._bar_idx, list(self._bar), self._last_px if self._last_px is not None else self._bar[3])
                self._bar_idx, self._bar = idx, [price, price, price, price]
            else:
                b = self._bar
                if price > b[1]:
                    b[1] = price
                if price < b[2]:
                    b[2] = price
                b[3] = price
            self._last_px = price
        return closed

    def _bar_dt(self, idx):
        day = self._today or ist_now().date()
        d = datetime(day.year, day.month, day.day, 9, 15)
        return d + timedelta(minutes=idx * self.p.tf_min)

    def _official(self, idx, tries=4, first_wait=0.6, wait=0.5):
        """Official OHLC of candle `idx` from Kite, or None."""
        f = self._feed
        interval = self._interval()
        if f is None or interval is None:
            return None
        bar_open = self._bar_dt(idx)
        span = timedelta(minutes=self.p.tf_min)
        time.sleep(first_wait)
        for _ in range(tries):
            try:
                rows = paced_history(f.kite, f.token, bar_open - span * 2, bar_open + span, interval, tries=1)
                for r in reversed(rows or []):
                    c = _row_to_candle(r)
                    if c[0] == bar_open:
                        return c
            except Exception:                                               # noqa: BLE001
                pass
            time.sleep(wait)
        return None

    def _finalize_bar(self, idx, bar, official=None):
        """Feed a CLOSED bar into EMA / ATR. Tick-built now, replaced by the official candle in the background."""
        if self._candles is None or idx < 0:
            return
        t = self._bar_dt(idx)
        cand = official or (t, bar[0], bar[1], bar[2], bar[3])
        with self._lock:
            if self._candles and self._candles[-1][0] == t:
                self._candles[-1] = cand
            elif not self._candles or self._candles[-1][0] < t:
                self._candles.append(cand)
            else:
                return
            snap = list(self._candles)
        self._set_candles(snap)
        if official is None and self._feed is not None and self._interval() and (self.p.use_trend_filter or self.p.use_trail):
            threading.Thread(target=self._refine, args=(idx,), daemon=True, name="pine-refine").start()

    def _refine(self, idx):
        try:
            c = self._official(idx, tries=3, first_wait=1.2, wait=0.8)
            if c is not None:
                self._finalize_bar(idx, None, official=c)
        except Exception:                                                   # noqa: BLE001
            pass

    # ------------------------------------------------------------------ entry
    def _trend_ok(self, direction, close):
        if not self.p.use_trend_filter:
            return True
        if (not self._ind_ready or self._ema is None) and self._feed is not None \
                and time.time() - self._ind_try_at > 5:
            self._prepare_indicators(fresh=True)                # last quick try before refusing the trade
        if not self._ind_ready or self._ema is None:
            self._note("trend filter ON but EMA is not available - NO entry taken (safe default)")
            return False
        k = 2.0 / (self.p.ema_len + 1)
        ema_now = close * k + self._ema * (1 - k)               # Pine's EMA includes the bar being evaluated
        return close > ema_now if direction == "CALL" else close < ema_now

    def _make_signal(self, direction, price, level):
        sl = self.p.sl_pct / 100.0
        if direction == "CALL":
            stop = price * (1 - sl)
            risk = price - stop
            target = price + risk * self.p.rr
        else:
            stop = price * (1 + sl)
            risk = stop - price
            target = price - risk * self.p.rr
        self.taken = True
        self.signal = Signal(direction, float(price), float(self.day_open), float(level), float(stop), float(target), float(risk))
        self._trail_on = False
        return self.signal

    def _evaluate(self, close_px, window_ok):
        if self.taken or self.day_open is None or not window_ok or not self.gap_ok():
            return None
        up, down = self.levels()
        if self.p.trade_long and close_px > up and self._trend_ok("CALL", close_px):
            return self._make_signal("CALL", close_px, up)
        if self.p.trade_short and close_px < down and self._trend_ok("PUT", close_px):
            return self._make_signal("PUT", close_px, down)
        return None

    def _is_marginal(self, close_px):
        up, down = self.levels()
        band = max(4 * self.p.mintick, 0.00015 * self.day_open)
        return abs(close_px - up) <= band or abs(close_px - down) <= band

    def on_price(self, now, price):
        if self.taken or self.day_open is None:
            return None
        price = float(price)
        if self._feed is None:
            self._bind_feed()
        self._maybe_retry_indicators()
        closed = self._track(now, price)
        if not self.p.confirm_on_close:                         # instant on price
            if not self.window_open(now):
                return None
            return self._evaluate(price, True)
        if closed is None:
            return None
        idx, bar, tick_close = closed
        window_ok = self._window_ok_for_bar(idx)
        # EMA / ATR learn from the finished bar either way
        close_px = tick_close
        official = None
        if window_ok and not self.taken and self._is_marginal(close_px):
            official = self._official(idx)                      # rare: decision could flip on one tick
            if official is not None:
                close_px = official[4]
        self._finalize_bar(idx, bar, official)
        return self._evaluate(close_px, window_ok)

    # ------------------------------------------------------------------ exit (stop / target / ATR trail / time)
    def _atr_live(self, bar):
        if self._atr is None:
            return None
        n = self.p.atr_len
        tr = true_range(bar[1], bar[2], self._prev_close_c)
        return (self._atr * (n - 1) + tr) / n

    def check_exit(self, now, price):
        s = self.signal
        if s is None:
            return None
        price = float(price)
        closed = self._track(now, price)
        if closed is not None:
            self._finalize_bar(closed[0], closed[1])
        self._maybe_retry_indicators()
        if self.p.use_trail and self._ind_ready:
            with self._lock:
                bar = list(self._bar) if self._bar else None
            if bar is not None:
                atr = self._atr_live(bar)
                if atr:
                    if s.direction == "CALL" and bar[1] >= s.price + s.risk:
                        new = price - atr * self.p.atr_mult
                        if new > s.stop:
                            s.stop = new
                            self._trail_on = True
                    elif s.direction == "PUT" and bar[2] <= s.price - s.risk:
                        new = price + atr * self.p.atr_mult
                        if new < s.stop:
                            s.stop = new
                            self._trail_on = True
        if s.direction == "CALL":
            if price <= s.stop:
                return "STOP_LOSS"
            if price >= s.target:
                return "TARGET"
        else:
            if price >= s.stop:
                return "STOP_LOSS"
            if price <= s.target:
                return "TARGET"
        if self.time_exit_due(now):
            return "TIME_EXIT"
        return None


# ----------------------------------------------------------------------------- hooking into scan_mode
_TL = threading.local()


def install(scan_mode):
    """Replace the strategy classes used by the Scan + Pine runner and pre-load history when the price feed starts."""
    base_feed = scan_mode.PriceFeed

    class SpyFeed(base_feed):
        def __init__(self, kite, token, symbol, hub):
            super().__init__(kite, token, symbol, hub)
            _TL.feed = self
            try:
                p = getattr(scan_mode.CTX, "params", None)
                if p is not None and (getattr(p, "use_trend_filter", False) or getattr(p, "use_trail", False)):
                    interval = _INTERVALS.get(round(float(p.tf_min), 3))
                    if interval:
                        threading.Thread(target=_safe_preload, args=(kite, token, interval), daemon=True,
                                         name="pine-preload").start()
            except Exception:                                               # noqa: BLE001
                pass

    scan_mode.PriceFeed = SpyFeed
    scan_mode.PineOrb = PineOrb
    scan_mode.PineParams = PineParams
    print("[pine v2] full Pine script strategy installed (trend filter, ATR trail, TF-adaptive, candle-exact)")
    return True


def _safe_preload(kite, token, interval):
    try:
        load_history(kite, token, interval)
    except Exception:                                                       # noqa: BLE001
        pass
