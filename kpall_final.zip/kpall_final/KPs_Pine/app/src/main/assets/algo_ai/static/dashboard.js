(function () {
  "use strict";

  // ------------------------------------------------------------ helpers

  function $(id) { return document.getElementById(id); }

  function toast(message, type) {
    const container = $("toastContainer");
    const el = document.createElement("div");
    el.className = "toast" + (type ? " " + type : "");
    el.textContent = message;
    container.appendChild(el);
    setTimeout(() => el.remove(), 4500);
  }

  function fmtMoney(n) {
    if (n === null || n === undefined || Number.isNaN(n)) return "—";
    const sign = n < 0 ? "-" : "";
    return sign + "₹" + Math.abs(n).toFixed(2);
  }

  function fmtPrice(n) {
    if (n === null || n === undefined || Number.isNaN(n)) return "—";
    return n.toFixed(2);
  }

  // ------------------------------------------------------------ live IST clock
  // Purely client-side (Date + Intl, formatted to Asia/Kolkata regardless of
  // the machine's own timezone) - next to the Time Exit field so you can see
  // the actual current market time while picking an exit time, without
  // depending on being logged in / Kite being reachable. Runs continuously,
  // market open or closed, and is always correct on reopen since it's
  // computed fresh from the real clock every tick, never cached.
  const liveClockEl = $("liveClock");
  if (liveClockEl) {
    const updateLiveClock = () => {
      liveClockEl.textContent = new Date().toLocaleTimeString("en-IN", {
        timeZone: "Asia/Kolkata", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: true,
      });
    };
    updateLiveClock();
    setInterval(updateLiveClock, 1000);
  }

  async function postJSON(url, body) {
    const resp = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body || {}),
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok || data.ok === false) {
      throw new Error(data.error || ("request failed: " + resp.status));
    }
    return data;
  }

  // ------------------------------------------------------------ settings form

  const providerSelect = $("ai_provider");
  const geminiField = $("geminiKeyField");
  const claudeField = $("claudeKeyField");

  function syncProviderFields() {
    const isGemini = providerSelect.value === "gemini";
    geminiField.style.display = isGemini ? "" : "none";
    claudeField.style.display = isGemini ? "none" : "";
  }
  providerSelect.addEventListener("change", syncProviderFields);
  syncProviderFields();

  function bindToggle(checkboxId, inputId) {
    const cb = $(checkboxId);
    const input = $(inputId);
    function sync() { input.disabled = !cb.checked; }
    cb.addEventListener("change", sync);
    sync();
  }
  bindToggle("sl_enabled", "max_loss");
  bindToggle("target_enabled", "target_profit");
  bindToggle("time_exit_enabled", "time_exit");
  bindToggle("proxy_enabled", "proxy_host");

  const settingsPanel = $("settingsPanel");
  $("settingsToggleBtn").addEventListener("click", () => {
    settingsPanel.classList.toggle("collapsed");
    // Settings is a tall section - toggling it changes how much the page can
    // scroll, but the browser keeps whatever raw scroll position you were
    // at. Without this, clicking Settings again while scrolled deep into the
    // form can land you in the middle of an unrelated section instead of
    // visibly returning to the top - this makes "go back" always work the
    // same way: scroll to the top of whichever view is now showing. Instant
    // (not smooth) - smooth scrollTo can silently fail to complete in some
    // browser/OS "reduced motion" configurations, and this needs to be
    // 100% reliable, not just usually-nice.
    window.scrollTo(0, 0);
  });

  const modeBadge = $("modeBadge");
  let modeSwitching = false;
  modeBadge.addEventListener("click", async () => {
    if (modeSwitching || running) return;
    const goingLive = modeBadge.classList.contains("badge-dry");
    if (goingLive) {
      const ok = confirm(
        "WARNING: This switches to LIVE trading.\n\n" +
        "Every future Execute run will place REAL orders on your Zerodha " +
        "account with REAL money - current risk per trade: Stop-Loss/Target " +
        "as set in Settings.\n\n" +
        "Click OK only if you are certain. Click Cancel to stay in DRY RUN."
      );
      if (!ok) return;
    }
    modeSwitching = true;
    modeBadge.disabled = true;
    try {
      const resp = await fetch("/api/mode", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ live: goingLive }),
      });
      const data = await resp.json();
      if (!data.ok) {
        toast(data.error || "Could not switch mode", "error");
        return;
      }
      modeBadge.classList.toggle("badge-dry", data.dry_run);
      modeBadge.classList.toggle("badge-live", !data.dry_run);
      modeBadge.textContent = data.dry_run ? "DRY RUN" : "LIVE";
      toast(data.dry_run ? "Switched to DRY RUN (simulated)" : "Switched to LIVE - real orders will be placed", data.dry_run ? "info" : "error");
    } catch (err) {
      toast("Could not reach server to switch mode", "error");
    } finally {
      modeSwitching = false;
      modeBadge.disabled = false;
    }
  });

  $("settingsForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const payload = {
      kite_api_key: $("kite_api_key").value.trim(),
      kite_api_secret: $("kite_api_secret").value.trim(),
      index: ($("index").value.trim() || "NIFTY").toUpperCase(),
      entry_strike_mode: $("entry_strike_mode").value,
      profit_check_mode: $("profit_check_mode").value,
      keep_awake: $("keep_awake").value,
      strategy_mode: $("strategy_mode").value,
      lotto_min_premium: parseFloat($("lotto_min_premium").value) || 5,
      lotto_max_premium: parseFloat($("lotto_max_premium").value) || 10,
      lotto_target_multiple: parseFloat($("lotto_target_multiple").value) || 3,
      lotto_sl_pct: parseFloat($("lotto_sl_pct").value) || 0,
      lotto_max_spend: parseFloat($("lotto_max_spend").value) || 0,
      lotto_max_spread_abs: parseFloat($("lotto_max_spread_abs").value) || 0,
      lotto_entry_start: $("lotto_entry_start").value || "14:30",
      lotto_entry_end: $("lotto_entry_end").value || "15:05",
      lotto_force_exit_time: $("lotto_force_exit_time").value || "15:35",
      live_reanalysis_enabled: $("live_reanalysis").value !== "off",
      require_trend_confirmation: $("require_trend_confirmation").checked,
      lotto_require_trend_confirmation: $("lotto_require_trend_confirmation").checked,
      ...($("live_reanalysis").value !== "off" ? { live_reanalysis_minutes: parseFloat($("live_reanalysis").value) || 15 } : {}),
      trail_enabled: $("trail_enabled").checked,
      trail_activate_profit: parseFloat($("trail_activate_profit").value) || 0,
      trail_giveback_pct: parseFloat($("trail_giveback_pct").value) || 35,
      max_spread_pct: parseFloat($("max_spread_pct").value) || 0,
      min_expected_move_pct: parseFloat($("min_expected_move_pct").value) || 0,
      entry_window_start: $("entry_window_start").value || "09:30",
      entry_window_end: $("entry_window_end").value || "14:30",
      lots: parseInt($("lots").value, 10) || 1,
      lot_sizing_mode: $("lot_sizing_mode").value,
      sizing_max_lots: parseInt($("sizing_max_lots").value, 10) || 10,
      sizing_amount_call: parseFloat($("sizing_amount_call").value) || 0,
      sizing_amount_put: parseFloat($("sizing_amount_put").value) || 0,
      sizing_amount_both: parseFloat($("sizing_amount_both").value) || 0,
      sizing_tiers: [0, 1, 2].map(i => ({
        from: parseFloat($("tier" + i + "_from").value), to: parseFloat($("tier" + i + "_to").value),
        lots: parseInt($("tier" + i + "_lots").value, 10) })).filter(t => isFinite(t.from) && isFinite(t.to) && t.lots >= 1),
      rr_filter_enabled: $("rr_filter_enabled").checked,
      rr_filter_ratio: parseFloat($("rr_filter_ratio").value) || 2,
      ai_provider: providerSelect.value,
      gemini_api_key: $("gemini_api_key").value.trim(),
      anthropic_api_key: $("anthropic_api_key").value.trim(),
      sl_enabled: $("sl_enabled").checked,
      max_loss: parseFloat($("max_loss").value) || 0,
      target_enabled: $("target_enabled").checked,
      target_profit: parseFloat($("target_profit").value) || 0,
      time_exit_enabled: $("time_exit_enabled").checked,
      time_exit: $("time_exit").value || "10:30",
      profit_margin_factor: parseFloat($("profit_margin_factor").value) || 1,
      momentum_min_fraction: parseFloat($("momentum_min_fraction").value) || 0,
      momentum_max_fraction: parseFloat($("momentum_max_fraction").value) || 1,
      oi_change_clamp: parseFloat($("oi_change_clamp").value) || 0,
      volatility_confidence_ratio_scale: parseFloat($("volatility_confidence_ratio_scale").value) || 0,
      volatility_confidence_orb_bonus: parseFloat($("volatility_confidence_orb_bonus").value) || 0,
      volatility_confidence_momentum_scale: parseFloat($("volatility_confidence_momentum_scale").value) || 0,
      volatility_confidence_oi_buildup_scale: parseFloat($("volatility_confidence_oi_buildup_scale").value) || 0,
      volatility_confidence_cpr_narrow_scale: parseFloat($("volatility_confidence_cpr_narrow_scale").value) || 0,
      custom_ai_note: $("custom_ai_note").value,
      proxy: {
        enabled: $("proxy_enabled").checked,
        host: $("proxy_host").value.trim(),
        port: $("proxy_port").value.trim(),
        user: $("proxy_user").value.trim(),
        pass: $("proxy_pass").value,
      },
    };
    try {
      const result = await postJSON("/api/settings", payload);
      toast("Settings saved", "success");
      (result.warnings || []).forEach(w => toast("Check your Kite key: " + w, "error"));
      window.__CONFIGURED__ = result.configured;
      refreshControlState();
      if (result.configured) settingsPanel.classList.add("collapsed");
      loadPromptPreview();
    } catch (err) {
      toast("Could not save settings: " + err.message, "error");
    }
  });

  function loadPromptPreview() {
    fetch("/api/prompt_preview")
      .then(r => r.json())
      .then(data => { $("promptPreview").value = data.prompt || ""; })
      .catch(() => { $("promptPreview").value = "(could not load prompt preview)"; });
  }
  loadPromptPreview();

  // ------------------------------------------------------------ control buttons

  const loginBtn = $("loginBtn");
  const loginDot = $("loginDot");
  const executeBtn = $("executeBtn");
  const analyzeBtn = $("analyzeBtn");
  const stopBtn = $("stopBtn");
  const engineStatusText = $("engineStatusText");
  const controlHint = $("controlHint");
  const manualTokenInput = $("manualTokenInput");
  const manualLoginBtn = $("manualLoginBtn");
  const manualTradeBtns = [$("manualCallBtn"), $("manualPutBtn"), $("manualBothBtn")];
  const manualEntryDetails = $("manualEntryDetails");
  const atmPreviewUnavailable = $("atmPreviewUnavailable");
  let atmPreviewTimer = null;
  let spotFeedTimer = null;
  let spotChartLoaded = false;

  let loggedIn = false;
  const multiSlots = {};   // Multi-trade: slot name -> {el, pnl, closed, done, stopping} (declared early: refreshControlState uses it)
  let running = false;
  let loggingIn = false;

  function setHint(text, kind) {
    controlHint.textContent = text || "";
    controlHint.className = "muted small" + (kind ? " hint-" + kind : "");
  }

  function refreshControlState() {
    loginBtn.disabled = running || loggingIn;
    executeBtn.disabled = !loggedIn || running || !window.__CONFIGURED__;
    analyzeBtn.disabled = !loggedIn || running || !window.__CONFIGURED__;
    stopBtn.disabled = !running;
    modeBadge.disabled = running;
    // Manual login is a fallback and stays usable even while the automatic
    // Login button is mid-attempt (e.g. still waiting on a redirect that
    // will never arrive) - only block it while the engine is running.
    manualLoginBtn.disabled = running;
    manualTokenInput.disabled = running;
    manualTradeBtns.forEach(btn => { btn.disabled = !loggedIn || running || !window.__CONFIGURED__; });
    syncMultiButtons();
    document.querySelectorAll(".option-pick-btn").forEach(btn => {
      btn.disabled = !loggedIn || running || !window.__CONFIGURED__ || Number(btn.dataset.lots) < 1;
    });
    loginDot.classList.toggle("on", loggedIn);
    engineStatusText.textContent = running ? "Running" : (loggedIn ? "Logged in - idle" : "Idle");
    syncAtmPreviewPolling();
    syncSpotFeed();
  }
  refreshControlState();

  // -------------------------------------------------- ATM CALL/PUT/BOTH live preview
  // Shows the live ATM premium each manual button would actually pay, BEFORE
  // any order is placed. Only polls while the Manual Entry section is
  // actually open (nobody's paying for quote() calls for a panel that's
  // hidden) and while idle (once running, the real position's own
  // pnl_update/tick events take over the main LTP box instead).
  function fmtOptionPrice(ltp) {
    if (ltp === null || ltp === undefined || Number.isNaN(ltp)) return "—";
    return `₹${ltp.toFixed(2)}`;
  }

  // Last lots value the preview actually saw in settings.json - shown in the
  // manual-trade confirm() dialog below so a forgotten "Save Settings" click
  // (typed a new Lots value but never saved it) is visible BEFORE the order
  // goes in, instead of only finding out afterward that it entered with the
  // old lots count.
  let lastKnownLots = null;
  let lastKnownLotsBy = {};

  async function fetchAtmPreview() {
    try {
      const resp = await fetch("/api/atm_preview");
      const data = await resp.json();
      if (!data.ok) {
        atmPreviewUnavailable.style.display = "block";
        $("atmPreviewError").textContent = data.error || "unknown error";
        $("previewCallPrice").textContent = "—";
        $("previewPutPrice").textContent = "—";
        $("previewBothPrice").textContent = "—";
        return;
      }
      atmPreviewUnavailable.style.display = "none";
      lastKnownLots = data.lots;
      lastKnownLotsBy = { CALL: data.lots_call, PUT: data.lots_put, BOTH: data.lots_both };
      $("previewCallPrice").textContent = fmtOptionPrice(data.call.ltp);
      $("previewPutPrice").textContent = fmtOptionPrice(data.put.ltp);
      $("previewBothPrice").textContent = fmtOptionPrice(data.both_combined_ltp);
      if (!running) {
        // Before Execute/manual entry there is no live ticker yet - this is
        // the only source of a live NIFTY number, so drive the same LTP box
        // the ticker drives once a run starts (see the "tick" handler below).
        $("ltpValue").textContent = fmtPrice(data.spot_ltp);
      }
    } catch (err) {
      // transient network hiccup - keep showing the last known values,
      // don't spam a toast on every failed 5s poll
    }
  }

  function syncAtmPreviewPolling() {
    const shouldPoll = loggedIn && !running && manualEntryDetails.open;
    if (shouldPoll && atmPreviewTimer === null) {
      fetchAtmPreview();
      atmPreviewTimer = setInterval(fetchAtmPreview, 5000);
    } else if (!shouldPoll && atmPreviewTimer !== null) {
      clearInterval(atmPreviewTimer);
      atmPreviewTimer = null;
    }
  }
  manualEntryDetails.addEventListener("toggle", syncAtmPreviewPolling);

  $("checkKeyBtn").addEventListener("click", async () => {
    const out = $("checkKeyResult");
    out.style.color = ""; out.textContent = " Asking Kite...";
    try {
      const r = await postJSON("/api/check_key", { kite_api_key: $("kite_api_key").value });
      const colour = r.state === "accepted" ? "#16a34a" : (r.state === "rejected" ? "#dc2626" : "#b45309");
      out.style.color = colour;
      out.textContent = " " + (r.state === "accepted" ? "✓ " : (r.state === "rejected" ? "✗ " : "? ")) + r.message +
        (r.warnings && r.warnings.length ? "  (" + r.warnings.join(" ") + ")" : "");
    } catch (err) {
      out.style.color = "#dc2626";
      out.textContent = " " + err.message;
    }
  });

  function syncSizingBoxes() {
    const m = $("lot_sizing_mode").value;
    $("sizingAmountBox").style.display = m === "AMOUNT" ? "" : "none";
    $("sizingTiersBox").style.display = m === "TIERS" ? "" : "none";
  }
  $("lot_sizing_mode").addEventListener("change", syncSizingBoxes);
  syncSizingBoxes();

  manualTradeBtns.forEach(btn => {
    btn.addEventListener("click", async () => {
      const direction = btn.dataset.direction;
      const isLive = modeBadge.classList.contains("badge-live");
      const label = direction === "BOTH" ? "CALL and PUT (straddle)" : direction;
      const lotsHere = (lastKnownLotsBy[direction] !== undefined) ? lastKnownLotsBy[direction] : lastKnownLots;
      const lotsNote = (lotsHere !== null && lotsHere !== undefined)
        ? `\n\nLots: ${lotsHere} (from Settings / lot sizing - if you just changed this, make sure you clicked Save Settings first).`
        : "";
      const ok = confirm(
        `Manual entry: buy ${label} directly, with NO analysis - only your own judgment.\n\n` +
        (isLive
          ? "You are in LIVE mode - this places a REAL order with REAL money right now."
          : "You are in DRY RUN - this will be simulated, no real order.") +
        lotsNote +
        "\n\nThe usual Stop-Loss/Target/time-exit safety net still applies once entered.\n\n" +
        "Click OK to proceed, Cancel to back out."
      );
      if (!ok) return;
      manualTradeBtns.forEach(b => { b.disabled = true; });
      $("engineErrorBanner").style.display = "none";
      try {
        await postJSON("/api/manual_trade", { direction });
        toast(`Manual ${direction} entry started`, "success");
      } catch (err) {
        toast("Could not start manual entry: " + err.message, "error");
        refreshControlState();
      }
    });
  });

  loginBtn.addEventListener("click", async () => {
    if (!window.__CONFIGURED__) {
      toast("Save your Kite/AI API keys in Settings first", "error");
      settingsPanel.classList.remove("collapsed");
      return;
    }
    loggingIn = true;
    refreshControlState();
    setHint("Opening Kite login in your browser - complete it there...", "info");
    try {
      await postJSON("/api/login", {});
    } catch (err) {
      toast("Login failed to start: " + err.message, "error");
      loggingIn = false;
      refreshControlState();
      setHint("Login failed to start: " + err.message, "error");
    }
  });

  async function submitManualToken() {
    const raw = manualTokenInput.value.trim();
    if (!raw) {
      toast("Paste the redirect URL or request_token first", "error");
      return;
    }
    if (!window.__CONFIGURED__) {
      toast("Save your Kite/AI API keys in Settings first", "error");
      settingsPanel.classList.remove("collapsed");
      return;
    }
    manualLoginBtn.disabled = true;
    setHint("Verifying token...", "info");
    try {
      await postJSON("/api/login/manual", { token_input: raw });
      manualTokenInput.value = "";
    } catch (err) {
      setHint("Manual login failed: " + err.message, "error");
      toast("Manual login failed: " + err.message, "error");
    } finally {
      manualLoginBtn.disabled = running;
    }
  }

  manualLoginBtn.addEventListener("click", submitManualToken);
  manualTokenInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") submitManualToken();
  });

  executeBtn.addEventListener("click", async () => {
    executeBtn.disabled = true;
    $("engineErrorBanner").style.display = "none";
    try {
      await postJSON("/api/execute", {});
      toast("Execute started", "success");
    } catch (err) {
      toast("Could not start: " + err.message, "error");
      executeBtn.disabled = false;
    }
  });

  analyzeBtn.addEventListener("click", async () => {
    analyzeBtn.disabled = true;
    $("engineErrorBanner").style.display = "none";
    try {
      await postJSON("/api/analyze", {});
      toast("Analysis started - no order will be placed", "success");
    } catch (err) {
      toast("Could not start analysis: " + err.message, "error");
      analyzeBtn.disabled = false;
    }
  });

  stopBtn.addEventListener("click", async () => {
    stopBtn.disabled = true;
    try {
      await postJSON("/api/stop", {});
      toast("Stop signal sent", "success");
    } catch (err) {
      toast("Stop failed: " + err.message, "error");
      stopBtn.disabled = false;
    }
  });

  // ------------------------------------------------------------ chart

  const chartEl = $("chart");

  // Lightweight Charts formats epoch seconds in UTC by default - since this
  // is an India-market tool, format all displayed times in the *viewer's*
  // local timezone instead (correct for IST without hardcoding it).
  function formatLocalTime(time) {
    const d = new Date(time * 1000);
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false });
  }

  const chart = LightweightCharts.createChart(chartEl, {
    layout: { background: { color: "#ffffff" }, textColor: "#475467", fontFamily: "Inter, sans-serif" },
    grid: { vertLines: { color: "#F0F0F0" }, horzLines: { color: "#F0F0F0" } },
    rightPriceScale: { borderColor: "#E4E7EC" },
    timeScale: {
      borderColor: "#E4E7EC", timeVisible: true, secondsVisible: false,
      tickMarkFormatter: formatLocalTime,
    },
    localization: { timeFormatter: formatLocalTime },
    crosshair: { mode: LightweightCharts.CrosshairMode.Normal },
    // The chart library captures mouse-wheel by default to zoom/pan its own
    // time axis - that "eats" the scroll wheel whenever the cursor happens
    // to be over the chart, making the PAGE feel like it randomly stops
    // scrolling. Disabling just the wheel handlers fixes that; click-drag
    // and touch (pinch/drag) interaction with the chart are left intact.
    handleScroll: { mouseWheel: false, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: true },
    handleScale: { mouseWheel: false, axisPressedMouseMove: true, pinch: true },
  });
  const candleSeries = chart.addCandlestickSeries({
    upColor: "#16A34A", downColor: "#DC2626",
    borderUpColor: "#16A34A", borderDownColor: "#DC2626",
    wickUpColor: "#16A34A", wickDownColor: "#DC2626",
  });

  window.addEventListener("resize", () => {
    chart.applyOptions({ width: chartEl.clientWidth, height: chartEl.clientHeight });
  });
  chart.applyOptions({ width: chartEl.clientWidth, height: chartEl.clientHeight });

  let currentCandle = null;
  let spotToken = null;

  const CANDLE_SECONDS = 300; // 5-minute candles, matching /api/spot_chart's backfill interval

  function feedSpotPrice(price) {
    const nowSec = Math.floor(Date.now() / 1000);
    const bucket = nowSec - (nowSec % CANDLE_SECONDS);
    if (!currentCandle || currentCandle.time !== bucket) {
      currentCandle = { time: bucket, open: price, high: price, low: price, close: price };
    } else {
      currentCandle.high = Math.max(currentCandle.high, price);
      currentCandle.low = Math.min(currentCandle.low, price);
      currentCandle.close = price;
    }
    candleSeries.update(currentCandle);
  }

  // -------------------------------------------------- always-on spot LTP/chart feed
  // Independent of Execute/manual trade entirely: as soon as you're logged
  // in, this backfills today's real 5-min candles (market open -> now) and
  // then keeps the LTP box + chart's current candle live via polling - so
  // the dashboard never sits blank just because no trade has been taken
  // yet. Once a real run starts, the actual tick stream (far more granular)
  // takes over and this polling pauses (see syncSpotFeed below).
  async function loadSpotChartBackfill() {
    try {
      const resp = await fetch("/api/spot_chart");
      const data = await resp.json();
      if (!data.ok || !data.candles || data.candles.length === 0) return;
      candleSeries.setData(data.candles);
      currentCandle = data.candles[data.candles.length - 1];
      spotToken = data.spot_token;
      $("chartTitle").textContent = data.spot_symbol + " — Live";
      spotChartLoaded = true;
    } catch (err) {
      // transient network hiccup - the periodic poll below will keep trying
      // to at least update the LTP box; chart backfill can be retried next
      // time syncSpotFeed() turns polling on (e.g. after a re-login)
    }
  }

  async function fetchSpotLtp() {
    try {
      const resp = await fetch("/api/spot_ltp");
      const data = await resp.json();
      if (!data.ok || data.ltp === null || data.ltp === undefined) return;
      $("ltpValue").textContent = fmtPrice(data.ltp);
      feedSpotPrice(data.ltp);
    } catch (err) {
      // transient network hiccup - keep showing the last known values
    }
  }

  function syncSpotFeed() {
    // Backfill runs once whenever logged in, REGARDLESS of running - a
    // freshly loaded/refreshed page has never seen the chart history yet
    // even if a run is already active (running=true), and the live tick
    // stream only ever adds NEW candles going forward, it never replays
    // history - so gating this on !running left the chart blank on any
    // refresh while a position was open.
    if (loggedIn && !spotChartLoaded) loadSpotChartBackfill();

    const shouldPoll = loggedIn && !running;
    if (shouldPoll && spotFeedTimer === null) {
      fetchSpotLtp();
      spotFeedTimer = setInterval(fetchSpotLtp, 5000);
    } else if (!shouldPoll && spotFeedTimer !== null) {
      clearInterval(spotFeedTimer);
      spotFeedTimer = null;
    }
    if (!loggedIn) spotChartLoaded = false; // re-backfill on next login (e.g. a different index)
  }

  // ------------------------------------------------------------ decision/positions UI

  function setDirectionBadge(el, value) {
    el.textContent = value || "—";
    el.className = "value direction-badge " + (value || "");
  }

  function setVolConfBadge(vc, evt) {
    const el = $("volConfBadge");
    if (vc === null || vc === undefined) {
      el.textContent = "—";
      el.className = "vol-conf-badge";
      el.title = "";
      return;
    }
    const rounded = Math.round(vc);
    el.textContent = rounded + "% big-move odds";
    el.className = "vol-conf-badge " + (rounded >= 70 ? "high" : rounded >= 40 ? "mid" : "low");

    const parts = [];
    if (evt && evt.expected_move !== null && evt.expected_move !== undefined && evt.avg_range) {
      parts.push(`VIX-implied move (${evt.expected_move.toFixed(0)}pts) vs recent avg daily range `
        + `(${evt.avg_range.toFixed(0)}pts) = ${(evt.expected_move / evt.avg_range).toFixed(2)}x`);
    }
    if (evt && evt.orb_bias && evt.orb_bias !== "NEUTRAL") {
      parts.push(`already broke today's ${evt.orb_minutes ?? 15}-min opening range (confirmed move)`);
    }
    if (evt && evt.momentum_used_fraction !== null && evt.momentum_used_fraction !== undefined) {
      parts.push(`${Math.round(evt.momentum_used_fraction * 100)}% of expected move already realized today`);
    }
    const oiRatios = evt
      ? [evt.resistance_oi_change_ratio, evt.support_oi_change_ratio].filter((r) => r !== null && r !== undefined)
      : [];
    if (oiRatios.length > 0) {
      const desc = oiRatios.map((r) => `${r >= 1 ? "+" : ""}${Math.round((r - 1) * 100)}%`).join(" / ");
      parts.push(`OI build-up/unwind at nearest walls vs yesterday: ${desc}`);
    }
    if (evt && evt.cpr_width_ratio !== null && evt.cpr_width_ratio !== undefined) {
      parts.push(`yesterday's CPR width ratio ${evt.cpr_width_ratio.toFixed(2)} (narrower = more likely a trend day)`);
    }
    el.title = parts.length > 0
      ? "Combines: " + parts.join(" · ")
      : "";
  }

  let shownPositions = [];
  function renderPositions(positions) {
    shownPositions = positions || [];
    const el = $("positionsList");
    if (!positions || positions.length === 0) {
      el.innerHTML = "No open position.";
      return;
    }
    el.innerHTML = positions.map(p => `
      <div class="position-row">
        <span>${p.tradingsymbol} (${p.type}) x${p.qty}</span>
        <span>${fmtPrice(p.entry_price)} → ${fmtPrice(p.ltp)}</span>
      </div>
    `).join("");
  }

  // Live market direction (display only) - refreshed by the engine every N
  // minutes while a trade is open. Never triggers any order/exit.
  function showLiveDirectionWaiting() {
    $("liveDirectionCard").style.display = "";
    $("liveDirectionValue").textContent = "Waiting for first check...";
    $("liveDirectionValue").className = "live-direction-value";
    $("liveDirectionAlign").textContent = "";
    $("liveDirectionMeta").textContent = "";
    $("liveDirectionTime").textContent = "";
  }

  function hideLiveDirection() {
    $("liveDirectionCard").style.display = "none";
  }

  function renderLiveDirection(evt) {
    const labels = { CALL: "BULLISH (CALL)", PUT: "BEARISH (PUT)", BOTH: "UNCLEAR - big move either way (BOTH)", NO_TRADE: "NO CLEAR EDGE (NO_TRADE)" };
    const cls = { CALL: "up", PUT: "down", BOTH: "both", NO_TRADE: "flat" };
    $("liveDirectionCard").style.display = "";
    const v = $("liveDirectionValue");
    v.textContent = labels[evt.direction] || evt.direction;
    v.className = "live-direction-value " + (cls[evt.direction] || "flat");
    $("liveDirectionTime").textContent = "· checked " + evt.checked_at +
      (evt.next_check_at ? " · next check at " + evt.next_check_at : "") +
      (evt.next_check_minutes ? " (every " + evt.next_check_minutes + " min)" : "");

    const a = $("liveDirectionAlign");
    if (evt.alignment === "AGAINST") {
      a.textContent = "⚠ Market now points AGAINST your open position - review it (no auto-exit is triggered by this).";
      a.className = "small live-align-against";
    } else if (evt.alignment === "AGREES") {
      a.textContent = "✓ Market still agrees with your open position.";
      a.className = "small live-align-agrees";
    } else {
      a.textContent = "Neutral vs your position (straddle or no clear direction).";
      a.className = "small muted";
    }

    const bits = [];
    if (evt.upside_probability !== null && evt.upside_probability !== undefined) {
      bits.push("Up " + Math.round(evt.upside_probability * 100) + "% / Down " + Math.round((evt.downside_probability || 0) * 100) + "%");
    }
    if (evt.spot !== null && evt.spot !== undefined) bits.push("Spot " + fmtPrice(evt.spot));
    if (evt.momentum_bias) bits.push("Momentum " + evt.momentum_bias);
    $("liveDirectionMeta").textContent = bits.join(" · ");
  }

  function setPnl(totalPnl) {
    const el = $("pnlValue");
    el.textContent = fmtMoney(totalPnl);
    el.className = "big-number " + (totalPnl > 0 ? "profit" : totalPnl < 0 ? "loss" : "neutral");
  }

  // ------------------------------------------------------------ socket.io

  const socket = io();

  socket.on("connect", () => {
    // no-op: don't clear controlHint here, it may be showing a persistent
    // login error/status the user hasn't acted on yet.
  });

  socket.on("log", (data) => {
    const panel = $("logPanel");
    const line = document.createElement("div");
    line.className = "log-line";
    const time = new Date().toLocaleTimeString();
    line.innerHTML = `<span class="log-time">${time}</span>${escapeHtml(data.message)}`;
    panel.appendChild(line);
    panel.scrollTop = panel.scrollHeight;
  });

  function escapeHtml(s) {
    const div = document.createElement("div");
    div.textContent = s;
    return div.innerHTML;
  }

  socket.on("login_status", (data) => {
    if (data.status === "waiting") {
      loggingIn = true;
      setHint("Waiting for you to finish logging in to Kite in the other browser tab (up to 4 minutes)... " +
        "If that tab shows \"connection refused\", paste its URL into the box below instead.", "info");
    } else if (data.status === "success") {
      loggingIn = false;
      loggedIn = true;
      setHint("✓ Logged in to Kite.", "success");
      toast("Kite login successful", "success");
    } else if (data.source === "manual") {
      loggingIn = false;
      loggedIn = false;
      setHint("Login failed: " + (data.message || "unknown error") + " — the token may be wrong, expired, or already used. Complete Kite login again and paste the new URL/token.", "error");
      toast("Manual login failed - see the note under the Login button", "error");
    } else {
      loggingIn = false;
      loggedIn = false;
      setHint(
        "Login failed: " + (data.message || "unknown error") +
        " — double-check your Kite app's Redirect URL is set to EXACTLY http://127.0.0.1:5000/ " +
        "(with the port and trailing slash) in the Kite developer console, or use the paste-token box below instead.",
        "error"
      );
      toast("Kite login failed - see the note under the Login button", "error");
    }
    refreshControlState();
  });

  const progressEl = $("engineProgressText");
  const errorBannerEl = $("engineErrorBanner");

  function showProgress(message) {
    progressEl.textContent = message;
    progressEl.style.display = "flex";
  }
  function hideProgress() {
    progressEl.style.display = "none";
  }
  function showErrorBanner(message) {
    errorBannerEl.textContent = "⚠ " + message;
    errorBannerEl.style.display = "block";
  }
  function hideErrorBanner() {
    errorBannerEl.style.display = "none";
  }

  socket.on("engine_status", (data) => {
    running = !!data.running;
    if (running) {
      hideErrorBanner();
      $("probBar").style.display = "none";
      $("probBarEmpty").style.display = "block";
      $("probBarEmpty").textContent = "Analyzing...";
    } else {
      hideProgress();
      if ($("probBarEmpty").style.display !== "none") {
        $("probBarEmpty").textContent = "Not analyzed yet - click Execute";
      }
    }
    refreshControlState();
  });

  let lastTickReceivedAt = null;
  const feedStatusEl = $("feedStatus");
  const FEED_STALE_MS = 20000;

  socket.on("tick", (tick) => {
    if (spotToken !== null && tick.instrument_token === spotToken) {
      if (tick.last_price !== null && tick.last_price !== undefined) {
        $("ltpValue").textContent = fmtPrice(tick.last_price);
        feedSpotPrice(tick.last_price);
        lastTickReceivedAt = Date.now();
      }
    }
  });

  function refreshFeedStatus() {
    if (!running) {
      feedStatusEl.style.display = "none";
      return;
    }
    feedStatusEl.style.display = "inline-block";
    const isStale = lastTickReceivedAt === null || (Date.now() - lastTickReceivedAt > FEED_STALE_MS);
    feedStatusEl.className = "feed-status " + (isStale ? "stale" : "live");
    feedStatusEl.textContent = isStale ? "Stale" : "Live";
  }
  setInterval(refreshFeedStatus, 3000);

  // Named (not an inline socket.on callback) so the exact same rendering
  // can also be replayed from /api/last_analysis on page load/refresh -
  // see loadLastAnalysis() below. Without this, refreshing the page while
  // a position is open (or any time after Execute has already run) wiped
  // the whole Signal Breakdown/Probability/chart-title back to blank,
  // since "universe_ready"/"decision" are one-time events with nothing
  // that re-sends them - only pnl_update repeats every monitoring tick,
  // which is why P&L/Open Positions alone used to survive a refresh.
  // -------------------------------------------------- live option premium + expected-move target
  // Elements marked data-opt-token="<instrument_token>" show that option's live price from the tick stream.
  function optPriceSpan(leg) {
    return `<b class="opt-px" data-opt-token="${leg.token}">${fmtOptionPrice(leg.ltp)}</b>`;
  }
  function legTargetText(l) {
    const parts = [];
    if (l.target_premium !== null && l.target_premium !== undefined) {
      const src = l.target_source === "SETTINGS" ? "your Settings target"
        : (l.target_source === "PCT" ? `${l.target_pct}% gain rule` : "expected move");
      parts.push(`🎯 Target ${fmtOptionPrice(l.target_premium)}` +
        (l.underlying_target !== null && l.underlying_target !== undefined ? ` (index ${Math.round(l.underlying_target)})` : "") +
        ` [${src}]`);
    }
    if (l.sl_premium !== null && l.sl_premium !== undefined) parts.push(`SL ${fmtOptionPrice(l.sl_premium)}`);
    return parts.length ? parts.join(" · ") : "Target n/a (no price)";
  }
  function bigOptionHtml(pick) {
    // the option the entry would really buy (entry_strike_mode), as big live price(s) with target
    const opt = pick.options.find(o => (o.mode === "ITM1") === (pick.entry_mode === "ITM1")) || pick.options[0];
    return opt.legs.map(l =>
      `<div class="opt-big"><span class="opt-big-name">${escapeHtml(pick.underlying)} ${l.strike} ${l.type} <span class="option-pick-tag ${l.moneyness === "ITM" ? "itm" : ""}">${l.moneyness}</span></span>
        <span class="opt-big-px" data-opt-token="${l.token}">${fmtOptionPrice(l.ltp)}</span>
        <span class="opt-big-target">${escapeHtml(legTargetText(l))}</span></div>`).join("");
  }
  socket.on("tick", (t) => {
    if (t.last_price === null || t.last_price === undefined) return;
    document.querySelectorAll(`[data-opt-token="${t.instrument_token}"]`).forEach(el => { el.textContent = fmtOptionPrice(t.last_price); });
  });

  // -------------------------------------------------- Suggested option (after Analyze / Execute)
  // Shows the exact ATM and ITM contract for the decided direction, with live premium, spread, lots and
  // cost. "Trade" buys exactly that contract through the same manual-entry path (same SL/target/exit net).
  function renderOptionPick(pick) {
    const box = $("optionPickCard"), rows = $("optionPickRows");
    rows.innerHTML = "";
    if (!pick || !pick.options || !pick.options.length) {
      box.style.display = "none"; $("optBox").style.display = "none"; $("optBoxBody").innerHTML = ""; return;
    }
    $("optBox").style.display = "block"; $("optBoxBody").innerHTML = bigOptionHtml(pick);
    box.style.display = "block";
    const maxSpread = pick.max_spread_pct;
    pick.options.forEach(opt => {
      const names = opt.legs.map(l => `${pick.underlying} ${l.strike} ${l.type}`).join(" + ");
      const prem = opt.legs.map(l => optPriceSpan(l)).join(" + ");
      const tgt = opt.legs.map(l => legTargetText(l)).join(" | ");
      const spreads = opt.legs.map(l => l.spread_pct);
      const worst = spreads.some(x => x === null || x === undefined) ? null : Math.max(...spreads);
      const wide = worst !== null && maxSpread && worst > maxSpread;
      const qty = opt.legs[0].lot_size * opt.lots;
      const row = document.createElement("div");
      row.className = "option-pick-row";
      const left = document.createElement("div");
      left.innerHTML = `<div class="option-pick-name">BUY ${escapeHtml(names)}
          <span class="option-pick-tag ${opt.label === "ITM" ? "itm" : ""}">${opt.label}</span></div>
        <div class="option-pick-meta">expiry ${escapeHtml(pick.expiry)} · premium ${prem} ·
          lots ${opt.lots} (qty ${qty}) · cost ${fmtMoney(opt.total_cost)} ·
          <br>${escapeHtml(tgt)}<br><span class="${wide ? "option-pick-warn" : ""}">spread ${worst === null ? "n/a" : worst.toFixed(1) + "%"}${wide ? " (above " + maxSpread + "% limit - entry would be blocked)" : ""}</span></div>`;
      const btn = document.createElement("button");
      btn.className = "btn btn-secondary option-pick-btn";
      btn.dataset.lots = String(opt.lots);
      btn.textContent = `Trade ${opt.label}`;
      btn.disabled = true;  // enabled by refreshControlState() once the analysis run has finished
      btn.addEventListener("click", async () => {
        const isLive = modeBadge.classList.contains("badge-live");
        if (!confirm(`Buy ${names} (${opt.label}) - ${opt.lots} lot(s), about ${fmtMoney(opt.total_cost)}.\n\n` +
            (isLive ? "LIVE mode: this places a REAL order with REAL money." : "DRY RUN: simulated, no real order.") +
            "\n\nSL / target / trailing / force-exit apply as usual. OK to proceed?")) return;
        btn.disabled = true;
        $("engineErrorBanner").style.display = "none";
        try {
          await postJSON("/api/manual_trade", { direction: pick.direction, strike_mode: opt.mode });
          toast(`${pick.direction} ${opt.label} entry started`, "success");
        } catch (err) {
          toast("Could not start entry: " + err.message, "error");
          refreshControlState();
        }
      });
      row.appendChild(left);
      row.appendChild(btn);
      rows.appendChild(row);
    });
  }

  function dispatchEngineEvent(evt) {
    switch (evt.type) {
      case "universe_ready":
        // Same underlying index/token the idle spot feed was already
        // showing - deliberately NOT resetting currentCandle here, so the
        // chart continues the same real candle series instead of jumping
        // to blank right as Execute/a manual trade is clicked.
        spotToken = evt.spot_token;
        $("chartTitle").textContent = evt.spot_symbol + " — Live";
        $("chartSubtitle").textContent =
          `ATM ${evt.atm_strike} · expiry ${evt.nearest_expiry} · strike step ${evt.strike_interval}`;
        lastTickReceivedAt = null;
        break;

      case "progress":
        showProgress(evt.message);
        break;

      case "decision": {
        hideProgress();

        if (evt.manual) {
          // Manual override: no analysis ran, so don't populate any of the
          // analysis fields with values that would look computed - show a
          // distinct, honest "no analysis" state instead.
          setDirectionBadge($("oiBias"), null); $("oiBias").title = "";
          setDirectionBadge($("atmOiBias"), null); $("atmOiBias").title = "";
          setDirectionBadge($("vwapBias"), null); $("vwapBias").title = "";
          setDirectionBadge($("orbBias"), null); $("orbBias").title = "";
          if ($("trendBias")) { setDirectionBadge($("trendBias"), null); $("trendBias").title = ""; }
          setDirectionBadge($("technicalBias"), null); $("technicalBias").title = "";
          setDirectionBadge($("aiSentiment"), null); $("aiSentiment").title = "";
          setDirectionBadge($("momentumBias"), null); $("momentumBias").title = "";
          $("largeGap").textContent = "—"; $("largeGap").title = "";
          setDirectionBadge($("finalDirection"), evt.direction);
          renderOptionPick(null);
          $("decisionRuleInfo").title = "Manual override - entered directly, no analysis performed";

          $("probBar").style.display = "none";
          $("probBarEmpty").style.display = "block";
          $("probBarEmpty").textContent = "Manual entry - no analysis performed";
          setVolConfBadge(null);
          $("rangeMeterSpotDot").style.display = "none";
          $("rangeMeterFill").style.display = "none";
          $("downsideTarget").textContent = "—";
          $("upsideTarget").textContent = "—";
          $("rangeMeterNote").textContent = "—";
          $("rangeMeterNote").title = "";
          $("callPremium").textContent = "—"; $("callRequiredMove").textContent = "—";
          $("putPremium").textContent = "—"; $("putRequiredMove").textContent = "—";
          $("netPremium").textContent = "—"; $("bothRequiredMove").textContent = "—"; $("bothRequiredMove").title = "";
          $("resistanceChipLine1").textContent = "—"; $("resistanceChipLine2").textContent = ""; $("resistanceChipLine2").title = "";
          $("supportChipLine1").textContent = "—"; $("supportChipLine2").textContent = ""; $("supportChipLine2").title = "";
          $("rangeTooTightNote").textContent = "";
          break;
        }

        setDirectionBadge($("oiBias"), evt.oi_bias);
        {
          const weightedNote = (evt.weighted_pcr !== null && evt.weighted_pcr !== undefined
            && Math.abs(evt.weighted_pcr - (evt.pcr ?? evt.weighted_pcr)) > 0.005)
            ? ` — proximity-weighted ${evt.weighted_pcr.toFixed(2)} decides bullish/bearish` : "";
          $("oiBias").title = (evt.pcr !== null && evt.pcr !== undefined)
            ? `Real PCR ${evt.pcr.toFixed(2)} (put OI / call OI across ATM ±5 strikes)${weightedNote}` : "";
        }

        setDirectionBadge($("atmOiBias"), evt.atm_oi_bias);
        {
          const fmtRatio = (r) => (r === null || r === undefined) ? "N/A" : `${r >= 1 ? "+" : ""}${Math.round((r - 1) * 100)}%`;
          $("atmOiBias").title = (evt.atm_ce_oi_change_ratio !== null && evt.atm_ce_oi_change_ratio !== undefined)
            || (evt.atm_pe_oi_change_ratio !== null && evt.atm_pe_oi_change_ratio !== undefined)
            ? `Fresh OI change right at ATM vs yesterday: CALL ${fmtRatio(evt.atm_ce_oi_change_ratio)}, `
              + `PUT ${fmtRatio(evt.atm_pe_oi_change_ratio)} - faster PUT build-up leans bullish, faster CALL build-up leans bearish`
            : "";
        }

        setDirectionBadge($("vwapBias"), evt.vwap_bias);
        {
          const src = evt.vwap_source_tradingsymbol ? ` (from ${evt.vwap_source_tradingsymbol} futures - the index itself has no volume)` : "";
          $("vwapBias").title = (evt.vwap !== null && evt.vwap !== undefined)
            ? `VWAP ${fmtPrice(evt.vwap)}${src}` : "";
        }

        setDirectionBadge($("orbBias"), evt.orb_bias);
        $("orbBias").title = (evt.orb_high !== null && evt.orb_high !== undefined)
          ? `${evt.orb_minutes ?? 15}-min opening range: ${fmtPrice(evt.orb_low)} - ${fmtPrice(evt.orb_high)}` : "";

        setDirectionBadge($("trendBias"), evt.trend_bias);
        $("trendBias").title = (evt.trend_ema_fast !== null && evt.trend_ema_fast !== undefined)
          ? `5-min EMA fast ${fmtPrice(evt.trend_ema_fast)} / slow ${fmtPrice(evt.trend_ema_slow)}`
            + ((evt.trend_rsi !== null && evt.trend_rsi !== undefined) ? `, RSI ${evt.trend_rsi.toFixed(0)}` : "")
          : "";

        setDirectionBadge($("technicalBias"), evt.technical_bias);
        $("technicalBias").title = "Reference only (2-of-3 OI/VWAP/ORB vote) - the trade decision is driven by Probability of Move, not this.";

        setDirectionBadge($("aiSentiment"), evt.ai_sentiment);
        $("aiSentiment").title = evt.ai_reason ? ("AI: " + evt.ai_reason) : "";

        setDirectionBadge($("momentumBias"), evt.momentum_bias);
        if (evt.momentum_used_fraction !== null && evt.momentum_used_fraction !== undefined) {
          const usedPct = Math.round(evt.momentum_used_fraction * 100);
          const minPct = Math.round((evt.momentum_min_fraction ?? 0) * 100);
          const maxPct = Math.round((evt.momentum_max_fraction ?? 1) * 100);
          $("momentumBias").title =
            `${usedPct}% of expected move already used today (band ${minPct}-${maxPct}% counts as evidence)`;
        } else {
          $("momentumBias").title = "";
        }
        $("largeGap").textContent = evt.large_gap ? "Yes" : "No";
        $("largeGap").title = (evt.gap_points !== null && evt.gap_points !== undefined)
          ? `Gap ${evt.gap_points.toFixed(0)} pts vs avg range ${evt.avg_range.toFixed(0)} pts` : "";
        setDirectionBadge($("finalDirection"), evt.direction);
        renderOptionPick(evt.option_pick);

        $("probBarEmpty").style.display = "none";
        $("probBar").style.display = "flex";
        const upPct = Math.round((evt.upside_probability ?? 0.5) * 100);
        const downPct = 100 - upPct;
        $("probUpBar").style.width = upPct + "%";
        $("probUpBar").textContent = upPct + "%";
        $("probDownBar").style.width = downPct + "%";
        $("probDownBar").textContent = downPct + "%";

        setVolConfBadge(evt.volatility_confidence, evt);

        if (evt.expected_move !== null && evt.expected_move !== undefined) {
          $("upsideTarget").textContent = `${fmtPrice(evt.expected_upside_target)} (+${evt.expected_move.toFixed(0)})`;
          $("downsideTarget").textContent = `${fmtPrice(evt.expected_downside_target)} (−${evt.expected_move.toFixed(0)})`;
          const hasBlend = evt.historical_oc_range !== null && evt.historical_oc_range !== undefined;
          const rangeLabel = hasBlend ? `VIX ${evt.india_vix?.toFixed(1) ?? "—"} + ${evt.historical_range_lookback_days ?? 15}d avg` : `VIX ${evt.india_vix?.toFixed(1) ?? "—"}`;
          let movedStr = "";
          if (evt.points_moved_from_open !== null && evt.points_moved_from_open !== undefined) {
            const sign = evt.points_moved_from_open >= 0 ? "+" : "";
            movedStr = ` · Moved ${sign}${evt.points_moved_from_open.toFixed(0)} pts from open (${fmtPrice(evt.day_open)})`;
          }
          $("rangeMeterNote").textContent = rangeLabel + movedStr;
          $("rangeMeterNote").title = hasBlend
            ? `Expected range blend: VIX-implied ±${evt.vix_expected_move.toFixed(0)}pts, ` +
              `${evt.historical_range_lookback_days ?? 15}-day avg open→close ±${evt.historical_oc_range.toFixed(0)}pts ` +
              `-> blended ±${evt.expected_move.toFixed(0)}pts`
            : "";

          if (evt.points_moved_from_open !== null && evt.points_moved_from_open !== undefined && evt.expected_move > 0) {
            const pct = Math.max(0, Math.min(100,
              ((evt.points_moved_from_open + evt.expected_move) / (2 * evt.expected_move)) * 100));
            $("rangeMeterSpotDot").style.left = pct + "%";
            $("rangeMeterSpotDot").style.display = "block";

            const fillEl = $("rangeMeterFill");
            if (pct >= 50) {
              fillEl.className = "range-meter-fill up";
              fillEl.style.left = "50%";
              fillEl.style.width = (pct - 50) + "%";
            } else {
              fillEl.className = "range-meter-fill down";
              fillEl.style.left = pct + "%";
              fillEl.style.width = (50 - pct) + "%";
            }
            fillEl.style.display = "block";
          } else {
            $("rangeMeterSpotDot").style.display = "none";
            $("rangeMeterFill").style.display = "none";
          }
        } else {
          $("upsideTarget").textContent = "—";
          $("downsideTarget").textContent = "—";
          $("rangeMeterNote").textContent = "Range unavailable (need VIX + recent daily range data).";
          $("rangeMeterNote").title = "";
          $("rangeMeterSpotDot").style.display = "none";
          $("rangeMeterFill").style.display = "none";
        }

        {
          const fmtRequired = (pts) => (pts === null || pts === undefined) ? "—" : `need ${pts.toFixed(0)} pts`;
          if (evt.ce_premium !== null && evt.ce_premium !== undefined) {
            $("callPremium").textContent = fmtMoney(evt.ce_premium);
            $("callRequiredMove").textContent = fmtRequired(evt.required_move_call);
          } else {
            $("callPremium").textContent = "—";
            $("callRequiredMove").textContent = "—";
          }
          if (evt.pe_premium !== null && evt.pe_premium !== undefined) {
            $("putPremium").textContent = fmtMoney(evt.pe_premium);
            $("putRequiredMove").textContent = fmtRequired(evt.required_move_put);
          } else {
            $("putPremium").textContent = "—";
            $("putRequiredMove").textContent = "—";
          }
          if (evt.ce_premium !== null && evt.ce_premium !== undefined && evt.pe_premium !== null && evt.pe_premium !== undefined) {
            $("netPremium").textContent = fmtMoney(evt.ce_premium + evt.pe_premium);
            $("bothRequiredMove").textContent = fmtRequired(evt.required_move_both);
            $("bothRequiredMove").title = (evt.profit_margin_factor !== null && evt.profit_margin_factor !== undefined)
              ? `x${evt.profit_margin_factor} margin on live premium` : "";
          } else {
            $("netPremium").textContent = "—";
            $("bothRequiredMove").textContent = "—";
            $("bothRequiredMove").title = "";
          }
        }

        {
          const fmtWallChip = (strike, distance, oiRatio, volume) => {
            if (strike === null || strike === undefined) return { line1: "—", line2: "", title: "" };
            const oiPct = (oiRatio === null || oiRatio === undefined) ? null : Math.round((oiRatio - 1) * 100);
            const line1 = `${strike} · ${distance?.toFixed(0) ?? "?"}pts`;
            const line2 = oiPct === null ? "" : `OI ${oiPct >= 0 ? "+" : ""}${oiPct}%`;
            const title = (volume === null || volume === undefined) ? "" : `Volume: ${volume.toLocaleString()}`;
            return { line1, line2, title };
          };
          const res = fmtWallChip(evt.resistance_strike, evt.resistance_distance, evt.resistance_oi_change_ratio, evt.resistance_volume);
          $("resistanceChipLine1").textContent = res.line1;
          $("resistanceChipLine2").textContent = res.line2;
          $("resistanceChipLine2").title = res.title;
          const sup = fmtWallChip(evt.support_strike, evt.support_distance, evt.support_oi_change_ratio, evt.support_volume);
          $("supportChipLine1").textContent = sup.line1;
          $("supportChipLine2").textContent = sup.line2;
          $("supportChipLine2").title = sup.title;
        }

        if (evt.range_too_tight) {
          $("rangeTooTightNote").textContent =
            "Expected move is too small today - skipping trade regardless of bias (time-decay isn't worth it).";
        } else if (evt.direction === "BOTH" && !evt.large_gap) {
          $("rangeTooTightNote").textContent =
            "Direction unclear, but the expected move clears BOTH legs' combined live premium (with margin) - " +
            "straddling instead of skipping.";
        } else if (evt.direction === "NO_TRADE" && evt.required_move_call !== null && evt.required_move_call !== undefined) {
          $("rangeTooTightNote").textContent =
            "Expected move doesn't clear the live premium's breakeven (with margin) for any side - skipping " +
            "even though a directional/coin-flip read exists, since it's unlikely to be profitable today.";
        } else {
          $("rangeTooTightNote").textContent = "";
        }

        if (evt.call_probability_threshold !== null && evt.call_probability_threshold !== undefined) {
          const callPct = Math.round(evt.call_probability_threshold * 100);
          const putPct = Math.round(evt.put_probability_threshold * 100);
          $("decisionRuleInfo").title = `CALL if upside ≥${callPct}% AND move clears live CALL premium, ` +
            `PUT if upside ≤${putPct}% AND move clears live PUT premium, else BOTH if move clears the ` +
            `combined straddle premium, else NO_TRADE`;
        } else {
          $("decisionRuleInfo").title = "";
        }
        break;
      }

      case "live_direction":
        renderLiveDirection(evt);
        break;

      case "live_direction_scheduled":
        showLiveDirectionWaiting();
        $("liveDirectionValue").textContent = "First check at " + evt.next_check_at;
        $("liveDirectionMeta").textContent = "Runs automatically every " + evt.minutes + " min while this trade is open.";
        break;

      case "no_trade":
        hideLiveDirection();
        hideProgress();
        toast("Decision: NO_TRADE — no position taken this run" + (evt.reason ? ". Reason: " + evt.reason : ""), "success");
        break;

      case "analysis_complete":
        hideProgress();
        toast(`Analyze Only complete: ${evt.direction} — no order was placed`, "success");
        break;

      case "positions_entered":
        hideProgress();
        renderPositions(evt.positions);
        showLiveDirectionWaiting();
        toast("Entered: " + evt.positions.map(p => p.tradingsymbol).join(", "), "success");
        break;

      case "pnl_update":
        renderPositions(evt.positions);
        setPnl(evt.total_pnl);
        break;

      case "exit":
      case "leg_exit":
        toast("Exit (" + evt.reason + ")", "success");
        if (evt.positions) { renderPositions([]); hideLiveDirection(); }
        else if (evt.tradingsymbol) {
          // one leg closed on its own (e.g. lotto target / stop): drop just that row
          renderPositions(shownPositions.filter(p => p.tradingsymbol !== evt.tradingsymbol));
          if (shownPositions.length === 0) hideLiveDirection();
        }
        break;

      case "error":
        hideProgress();
        showErrorBanner(evt.message);
        toast("Engine error - see the banner above the chart", "error");
        break;

      case "tick_stale":
        toast(`Live price feed hasn't updated in ${Math.round(evt.seconds_since_last_tick)}s - reconnecting...`, "error");
        break;

      default:
        break;
    }
  }
  // -------------------------------------------------- Multi-trade (up to 3 underlyings at once)
  function syncMultiButtons() {
    document.querySelectorAll(".multi-btn").forEach(b => {
      b.disabled = !loggedIn || running || !window.__CONFIGURED__;
    });
    $("scanPreviewBtn").disabled = running;
    $("scanExecuteBtn").disabled = !loggedIn || running || !window.__CONFIGURED__;
    syncSlotStopButtons();
  }
  // each underlying's own Stop button: live only while the run is going and that underlying is not finished
  function syncSlotStopButtons() {
    Object.keys(multiSlots).forEach(slot => {
      const b = multiSlots[slot].el.querySelector(".multi-stop-btn");
      if (b) b.disabled = !running || multiSlots[slot].done || multiSlots[slot].stopping;
    });
  }

  function multiNames() {
    const names = [];
    document.querySelectorAll(".multi-slot").forEach(row => {
      const on = row.querySelector(".multi-on").checked;
      const name = row.querySelector(".multi-name").value.trim().toUpperCase();
      if (on && name) names.push(name);
    });
    return names;
  }
  function saveMultiPrefs() {
    try {
      const rows = [...document.querySelectorAll(".multi-slot")].map(r =>
        ({ on: r.querySelector(".multi-on").checked, name: r.querySelector(".multi-name").value }));
      localStorage.setItem("multiPrefs", JSON.stringify({ rows, strike: $("multiStrike").value, loss: $("multiTotalLoss").value }));
    } catch (e) { /* storage unavailable - fine */ }
  }
  function loadMultiPrefs() {
    try {
      const p = JSON.parse(localStorage.getItem("multiPrefs") || "null");
      if (!p) return;
      document.querySelectorAll(".multi-slot").forEach((r, i) => {
        if (p.rows && p.rows[i]) { r.querySelector(".multi-on").checked = !!p.rows[i].on; r.querySelector(".multi-name").value = p.rows[i].name || ""; }
      });
      if (p.strike !== undefined) $("multiStrike").value = p.strike;
      if (p.loss !== undefined) $("multiTotalLoss").value = p.loss;
    } catch (e) { /* ignore */ }
  }
  loadMultiPrefs();
  document.querySelectorAll(".multi-slot input, #multiStrike, #multiTotalLoss").forEach(el => el.addEventListener("change", saveMultiPrefs));

  // which section the live cards / total row belong to: Multi-trade or Scan + Pine (3rd option)
  const hostMulti = { cards: $("multiCards"), totalRow: $("multiTotalRow"), totalPnl: $("multiTotalPnl") };
  const hostScan = { cards: $("scanCards"), totalRow: $("scanTotalRow"), totalPnl: $("scanTotalPnl") };
  let host = hostMulti;
  function multiCard(slot) {
    if (multiSlots[slot]) return multiSlots[slot];
    const el = document.createElement("div");
    el.className = "multi-card";
    el.innerHTML = `<div class="multi-card-head"><span class="multi-card-name">${escapeHtml(slot)}</span>
        <span class="multi-card-actions"><span class="value direction-badge" data-r="dir">—</span>
        <button type="button" class="btn btn-danger multi-stop-btn" data-slot="${escapeHtml(slot)}" disabled
          title="Stop only ${escapeHtml(slot)} (squares off its position); the others keep running">Stop</button></span></div>
      <div class="multi-card-ltp" data-r="ltp" style="display:none;"></div>
      <div class="multi-card-big" data-r="big"></div>
      <div class="multi-card-sub" data-r="sub"></div>
      <div class="multi-card-status" data-r="status">Waiting...</div>
      <div class="multi-card-opts" data-r="opts"></div>
      <table class="multi-card-pos" data-r="pos" style="display:none;"></table>
      <div>P&amp;L: <span class="multi-pnl" data-r="pnl">—</span></div>`;
    host.cards.appendChild(el);
    multiSlots[slot] = { el, pnl: null, closed: false, done: false, stopping: false };
    syncSlotStopButtons();
    return multiSlots[slot];
  }
  function mq(slot, r) { return multiCard(slot).el.querySelector(`[data-r="${r}"]`); }
  function setMultiStatus(slot, text, err) {
    const el = mq(slot, "status"); el.textContent = text; el.className = "multi-card-status" + (err ? " err" : "");
  }
  function setMultiPnl(slot, pnl) {
    multiSlots[slot].pnl = pnl;
    const el = mq(slot, "pnl");
    el.textContent = (pnl === null || pnl === undefined) ? "—" : fmtMoney(pnl);
    el.className = "multi-pnl" + (pnl > 0 ? " pos" : (pnl < 0 ? " neg" : ""));
    let total = 0, any = false;
    Object.values(multiSlots).forEach(c => { if (c.pnl !== null && c.pnl !== undefined) { total += c.pnl; any = true; } });
    host.totalRow.style.display = any ? "block" : "none";
    const t = host.totalPnl; t.textContent = fmtMoney(total); t.className = "multi-pnl" + (total > 0 ? " pos" : (total < 0 ? " neg" : ""));
  }
  function renderMultiPositions(slot, positions) {
    const t = mq(slot, "pos");
    t.style.display = positions && positions.length ? "table" : "none";
    t.innerHTML = (positions || []).map(p =>
      `<tr><td>${escapeHtml(p.tradingsymbol)}</td><td>qty ${p.qty}</td><td>in ${fmtOptionPrice(p.entry_price)}</td>` +
      `<td>now ${fmtOptionPrice(p.ltp)}</td><td>${p.pnl === null || p.pnl === undefined ? "" : fmtMoney(p.pnl)}</td></tr>`).join("");
  }
  function renderMultiPick(slot, pick) {
    const box = mq(slot, "opts");
    if (!pick || !pick.options) { box.innerHTML = ""; mq(slot, "big").innerHTML = ""; return; }
    mq(slot, "big").innerHTML = bigOptionHtml(pick);
    box.innerHTML = pick.options.map(o => {
      const names = o.legs.map(l => `${l.strike} ${l.type}`).join(" + ");
      const prem = o.legs.map(l => optPriceSpan(l)).join(" + ");
      return `<div><b>${o.label}</b> ${escapeHtml(names)} @ ${prem} · ${o.lots} lot(s) · ${fmtMoney(o.total_cost)}</div>`;
    }).join("");
  }

  function handleMultiEvent(msg) {
    const slot = msg.slot, evt = msg.event || {};
    if (slot === "*") {
      if (evt.type === "combined_stop") toast(`Combined max loss reached (${fmtMoney(evt.total_pnl)}) - squaring off everything`, "error");
      return;
    }
    multiCard(slot);
    switch (evt.type) {
      case "slot_status":
        setMultiStatus(slot, evt.message || evt.status, evt.status === "error");
        if (evt.status === "error" || evt.status === "stopped") multiDone(slot);
        break;
      case "universe_ready":
        mq(slot, "sub").textContent = `ATM ${evt.atm_strike} · expiry ${evt.nearest_expiry}`;
        if (evt.spot_token !== undefined && evt.spot_token !== null) {
          const l = mq(slot, "ltp"); l.style.display = "block";
          l.innerHTML = `LTP <b class="multi-ltp-px" data-opt-token="${evt.spot_token}">${evt.spot_ltp !== null && evt.spot_ltp !== undefined ? fmtOptionPrice(evt.spot_ltp) : "—"}</b>`;
        }
        break;
      case "progress": setMultiStatus(slot, evt.message || "Analysing..."); break;
      case "decision": {
        setDirectionBadge(mq(slot, "dir"), evt.direction);
        const up = evt.upside_probability !== undefined && evt.upside_probability !== null
          ? ` · up ${Math.round(evt.upside_probability * 100)}%` : "";
        setMultiStatus(slot, `Decision ${evt.direction}${up} · AI ${evt.ai_sentiment || "-"} · trend ${evt.trend_bias || "-"}`);
        renderMultiPick(slot, evt.option_pick);
        break;
      }
      case "analysis_complete": setMultiStatus(slot, `Analysis done: ${evt.direction} (no order placed)`); multiDone(slot); break;
      case "no_trade": setMultiStatus(slot, "NO_TRADE - " + (evt.reason || "filters not met")); multiDone(slot); break;
      case "positions_entered":
        setMultiStatus(slot, "In trade"); renderMultiPositions(slot, evt.positions);
        setMultiPnl(slot, (evt.positions || []).reduce((a, p) => a + (p.pnl || 0), 0)); break;
      case "pnl_update":
        if (!multiSlots[slot].closed) { renderMultiPositions(slot, evt.positions); setMultiPnl(slot, evt.total_pnl); }
        break;
      case "leg_exit": setMultiStatus(slot, `Leg exited: ${evt.tradingsymbol} (${evt.reason})`); break;
      case "pine_signal":
        setDirectionBadge(mq(slot, "dir"), evt.direction);
        mq(slot, "sub").textContent = `Open ${fmtOptionPrice(evt.day_open)} · broke ${fmtOptionPrice(evt.level)} · stock SL ${fmtOptionPrice(evt.stop)} · target ${fmtOptionPrice(evt.target)} · exit ${evt.exit_time}`;
        break;
      case "pine_exit": multiSlots[slot].pineExit = evt.reason; break;
      case "exit": {
        multiSlots[slot].closed = true;
        const total = (evt.positions || []).reduce((a, p) => a + (p.pnl || 0), 0);
        renderMultiPositions(slot, evt.positions); setMultiPnl(slot, total);
        setMultiStatus(slot, (evt.reason === "MANUAL_STOP" && multiSlots[slot].pineExit)
          ? `Exited: Pine ${multiSlots[slot].pineExit}`
          : (evt.reason === "MANUAL_STOP" ? "Stopped by you - position squared off" : `Exited: ${evt.reason}`));
        multiDone(slot);
        break;
      }
      case "error": setMultiStatus(slot, evt.message || "error", true); multiDone(slot); break;
      default: break;
    }
  }
  function multiDone(slot) { multiSlots[slot].done = true; syncSlotStopButtons(); }

  // one underlying's own Stop button
  async function onSlotStopClick(ev) {
    const btn = ev.target.closest(".multi-stop-btn");
    if (!btn) return;
    const slot = btn.dataset.slot, c = multiSlots[slot];
    if (!c || c.done) return;
    const inTrade = c.pnl !== null && c.pnl !== undefined;
    if (inTrade && !confirm(`Stop ${slot} only? Its open position will be squared off now. The other underlyings keep running.`)) return;
    c.stopping = true; syncSlotStopButtons();
    try {
      await postJSON("/api/multi/stop_slot", { slot });
      setMultiStatus(slot, "Stopping...");
      toast(`${slot}: stop sent`, "success");
    } catch (err) {
      c.stopping = false; syncSlotStopButtons();
      toast(String(err.message || err), "error");
    }
  }
  $("multiCards").addEventListener("click", onSlotStopClick);
  $("scanCards").addEventListener("click", onSlotStopClick);
  socket.on("multi_event", handleMultiEvent);

  async function startMulti(execute) {
    const names = multiNames();
    if (!names.length) { toast("Tick at least one box and type an underlying", "error"); return; }
    if (names.length > 3) { toast("Maximum 3 underlyings at a time", "error"); return; }
    const strike = $("multiStrike").value || null;
    const totalLoss = Number($("multiTotalLoss").value) || 0;
    if (execute) {
      const isLive = modeBadge.classList.contains("badge-live");
      if (!confirm(`Trade ${names.join(", ")} TOGETHER (analysis decides CALL/PUT per underlying; NO_TRADE ones are skipped).\n\n` +
          (isLive ? "LIVE mode: REAL orders with REAL money." : "DRY RUN: simulated, no real orders.") +
          `\n\nLots / Stop Loss / Target from Settings apply to EACH underlying, so total risk can be up to ${names.length}x.` +
          (totalLoss > 0 ? `\nCombined max loss: ${fmtMoney(totalLoss)}.` : "\nNo combined max loss set.") +
          "\n\nOK to proceed?")) return;
    }
    Object.keys(multiSlots).forEach(k => delete multiSlots[k]);
    host = hostMulti;
    hostScan.cards.innerHTML = ""; hostScan.totalRow.style.display = "none";
    $("multiCards").innerHTML = ""; $("multiTotalRow").style.display = "none";
    names.forEach(n => multiCard(n));
    saveMultiPrefs();
    document.querySelectorAll(".multi-btn").forEach(b => { b.disabled = true; });
    $("engineErrorBanner").style.display = "none";
    try {
      await postJSON(execute ? "/api/multi/execute" : "/api/multi/analyze",
        { underlyings: names, strike_mode: strike, total_max_loss: totalLoss });
      toast(execute ? "Multi-trade started" : "Multi analysis started", "success");
    } catch (err) {
      toast("Could not start: " + err.message, "error");
      $("multiCards").innerHTML = ""; Object.keys(multiSlots).forEach(k => delete multiSlots[k]);
      refreshControlState();
    }
  }
  $("multiAnalyzeBtn").addEventListener("click", () => startMulti(false));
  $("multiExecuteBtn").addEventListener("click", () => startMulti(true));

  // -------------------------------------------------- Scan + Pine strategy (3rd option)
  const PINE_NUM = ["breakout_buf_pct", "min_ticks_move", "tf_min", "entry_bars", "sl_pct", "rr", "max_gap_pct", "entry_end_minute", "ema_len", "atr_len", "atr_mult"];
  const PINE_BOOL = ["trade_long", "trade_short", "confirm_on_close", "use_gap_filter", "tf_adaptive", "use_trend_filter", "use_trail"];
  function pineSettings() {
    const o = {};
    PINE_NUM.forEach(k => { o[k] = Number($("pine_" + k).value); });
    PINE_BOOL.forEach(k => { o[k] = $("pine_" + k).checked; });
    const t = ($("pine_exit_time").value || "11:30").split(":");
    o.exit_hour = Number(t[0]); o.exit_minute = Number(t[1]);
    return o;
  }
  function scanOwnNames() {
    const out = [];
    [1, 2, 3].forEach(i => {
      const n = $("scanOwn" + i).value.trim().toUpperCase();
      if ($("scanOwnOn" + i).checked && n) out.push(n);
    });
    return out;
  }
  function scanTicked() {
    return [...document.querySelectorAll("#scanPicks .scan-pick-on:checked")].map(c => c.dataset.sym);
  }
  function scanBody() {
    const listMode = $("scanListMode").value, selMode = $("scanSelectMode").value;
    return {
      list_mode: listMode, select_mode: selMode, max_trades: Number($("scanMaxTrades").value) || 1,
      symbols: scanOwnNames(), selected: (listMode === "SCAN" && selMode === "MANUAL") ? scanTicked() : [],
      side: $("scanSide").value, rank_by: $("scanRank").value, source: $("scanSource").value, count: 3,
      strike_mode: $("scanStrike").value || null, total_max_loss: Number($("scanTotalLoss").value) || 0,
      disable_trail: $("scanDisableTrail").checked, pine: pineSettings(),
    };
  }
  const SCAN_FIELDS = ["scanListMode", "scanSelectMode", "scanMaxTrades", "scanSide", "scanRank", "scanSource",
    "scanStrike", "scanTotalLoss", "pine_exit_time", "scanDisableTrail",
    "scanOwn1", "scanOwn2", "scanOwn3", "scanOwnOn1", "scanOwnOn2", "scanOwnOn3"]
    .concat(PINE_NUM.map(k => "pine_" + k), PINE_BOOL.map(k => "pine_" + k));
  function syncScanUi() {
    const own = $("scanListMode").value === "OWN", manual = $("scanSelectMode").value === "MANUAL";
    document.querySelectorAll(".scan-only-ctl").forEach(el => { el.style.display = own ? "none" : ""; });
    document.querySelectorAll(".scan-auto-ctl").forEach(el => { el.style.display = manual ? "none" : ""; });
    $("scanOwnBox").style.display = own ? "flex" : "none";
    $("scanPicks").style.display = own ? "none" : "";
    $("scanModeHelp").textContent = own
      ? (manual ? "Your list: every ticked stock / index below trades when its Pine breakout fires."
                : "Your list: all ticked stocks / indices are watched; only the FIRST stocks to break out (as many as you choose) get a trade, the rest are cancelled.")
      : (manual ? "Press Scan only, tick the stocks you want in the table, then Start. Every ticked stock trades when its Pine breakout fires."
                : "The best 3 of the scan are watched; only the FIRST stocks to break out (as many as you choose) get a trade, the rest are cancelled.");
  }
  function saveScanPrefs() {
    try {
      const p = {};
      SCAN_FIELDS.forEach(id => { const el = $(id); p[id] = el.type === "checkbox" ? el.checked : el.value; });
      p._v = 2;   // v2: Pine force-exit default is 11:30 (older saved 09:30 is ignored once)
      localStorage.setItem("scanPrefs", JSON.stringify(p));
    } catch (e) { /* storage unavailable */ }
  }
  (function loadScanPrefs() {
    try {
      const p = JSON.parse(localStorage.getItem("scanPrefs") || "null");
      if (!p) return;
      SCAN_FIELDS.forEach(id => {
        if (p[id] === undefined) return;
        if (id === "pine_exit_time" && p._v !== 2) return;   // old saved 09:30 -> use the new 11:30 default
        const el = $(id);
        if (el.type === "checkbox") el.checked = !!p[id]; else el.value = p[id];
      });
    } catch (e) { /* ignore */ }
  })();
  SCAN_FIELDS.forEach(id => $(id).addEventListener("change", () => { saveScanPrefs(); syncScanUi(); }));
  syncScanUi();

  function fmtQty(n) { return (n === null || n === undefined) ? "—" : Number(n).toLocaleString("en-IN"); }
  function renderScanPicks(res) {
    const manual = $("scanSelectMode").value === "MANUAL";
    const maxTick = 3;
    const rows = (res.picks || []).map((p, i) => {
      const cls = p.pchange > 0 ? "chg-pos" : (p.pchange < 0 ? "chg-neg" : "");
      const chg = (p.pchange === null || p.pchange === undefined) ? "—" : (p.pchange > 0 ? "+" : "") + p.pchange.toFixed(2) + "%";
      const pr = (p.pressure === null || p.pressure === undefined) ? "—" : p.pressure.toFixed(2);
      const tick = manual ? `<td><input type="checkbox" class="scan-pick-on" data-sym="${escapeHtml(p.symbol)}" ${i < maxTick ? "checked" : ""}></td>` : "";
      return `<tr>${tick}<td>${i + 1}</td><td><b>${escapeHtml(p.symbol)}</b></td><td>${p.ltp ? fmtOptionPrice(p.ltp) : "—"}</td>` +
        `<td class="${cls}">${chg}</td><td>${fmtQty(p.buy_qty)}</td><td>${fmtQty(p.sell_qty)}</td><td>${pr}</td></tr>`;
    }).join("");
    $("scanPicks").innerHTML = `<table><thead><tr>${manual ? "<th>Trade</th>" : ""}<th>#</th><th>Stock</th><th>Price</th><th>% chg</th>` +
      `<th>Buy qty</th><th>Sell qty</th><th>Buy/Sell</th></tr></thead><tbody>${rows}</tbody></table>`;
    $("scanInfo").textContent = `${res.side === "SELLERS" ? "Top SELLERS" : "Top BUYERS"} by ` +
      `${res.rank_by === "PRESSURE" ? "buy/sell quantity" : "% change"} · source: ${res.source} · ` +
      `${res.universe} F&O stocks scanned` + (res.note ? ` · note: ${res.note}` : "");
  }
  async function startScan(execute) {
    const body = scanBody();
    const own = body.list_mode === "OWN", manual = body.select_mode === "MANUAL";
    let names = null;
    let autoNote = "";
    const autoBox = $("scanAutoInfo");
    if (autoBox) autoBox.textContent = "";
    if (!own && body.side === "AUTO") {
      $("scanInfo").textContent = "AUTO: checking the market trend (index, gainers vs losers, gap) ...";
      $("scanExecuteBtn").disabled = true; $("scanPreviewBtn").disabled = true;
      let r = null;
      try {
        const resp = await fetch("/api/scanauto/side", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
        r = await resp.json().catch(() => ({}));
        if (!resp.ok && !r.error) r.error = "request failed: " + resp.status;
      } catch (e) { r = { ok: false, error: e.message }; }
      $("scanInfo").textContent = "";
      if (autoBox) autoBox.textContent = (r.ok ? r.reason : "AUTO: " + r.error) + (r.details ? "\n" + r.details.join("\n") : "");
      if (!r.ok) {
        toast(r.error || "AUTO could not pick a side", "error");
        refreshControlState();
        return;
      }
      body.side = r.side;
      autoNote = `AUTO chose Top ${r.side} (${r.confidence} confidence).\n`;
    }
    if (execute) {
      if (own) names = body.symbols;
      else if (manual) names = body.selected;
      if (own && !names.length) { toast("Tick at least one box and type a stock / index", "error"); return; }
      if (own && names.length > 3) { toast("Maximum 3 at a time", "error"); return; }
      if (!own && manual && !names.length) { toast("Press 'Scan only' first and tick the stocks you want to trade", "error"); return; }
      const isLive = modeBadge.classList.contains("badge-live");
      const pine = body.pine;
      const what = own ? `your list: ${names.join(", ")}`
        : (manual ? `the stocks you ticked: ${names.join(", ")}`
          : `the best 3 of the ${body.side === "SELLERS" ? "top SELLERS" : "top BUYERS"} scan of NSE F&O`);
      const nTrade = manual ? names.length : body.max_trades;
      const how = manual ? "Every one of them trades when its Pine breakout fires."
        : `All are watched; only the FIRST ${nTrade} to break out get a trade, the rest are cancelled.`;
      if (!confirm(autoNote + `Trade ${what} with the Pine strategy.\n${how}\n\n` +
          (isLive ? "LIVE mode: REAL orders with REAL money." : "DRY RUN: simulated, no real orders.") +
          `\n\nAt 9:15 each stock's open is read; a move of ${pine.breakout_buf_pct}% beyond it fires CALL (up) / PUT (down) ` +
          (pine.confirm_on_close ? "after the candle closes" : "INSTANTLY") +
          `. Stock SL ${pine.sl_pct}%, target ${pine.rr}R, forced exit ${$("pine_exit_time").value}.` +
          `\nLots / rupee Stop Loss from Settings apply to EACH stock (up to ${nTrade}x total risk).` +
          (body.total_max_loss > 0 ? `\nCombined max loss: ${fmtMoney(body.total_max_loss)}.` : "\nNo combined max loss set.") +
          "\n\nOK to proceed?")) return;
    }
    saveScanPrefs();
    $("scanExecuteBtn").disabled = true; $("scanPreviewBtn").disabled = true;
    if (!own) $("scanInfo").textContent = manual && execute ? "Starting ..." : "Scanning NSE F&O stocks ...";
    if (execute) {
      Object.keys(multiSlots).forEach(k => delete multiSlots[k]);
      host = hostScan;
      hostMulti.cards.innerHTML = ""; hostMulti.totalRow.style.display = "none";
      hostScan.cards.innerHTML = ""; hostScan.totalRow.style.display = "none";
      $("engineErrorBanner").style.display = "none";
    }
    try {
      const res = await postJSON(execute ? "/api/scan/execute" : "/api/scan/preview", body);
      if (res.picks && res.picks.length) renderScanPicks(res); else if (!own) $("scanInfo").textContent = "";
      if (execute) {
        (res.underlyings || []).forEach(n => multiCard(n));
        const limit = res.max_trades < (res.underlyings || []).length ? ` · first ${res.max_trades} breakout(s) will trade` : "";
        toast(`Pine started: ${(res.underlyings || []).join(", ")} - entries 9:15 to ${res.entry_end}${limit}`, "success");
      } else {
        toast("Scan done (no order placed)", "success");
      }
    } catch (err) {
      if (!own) $("scanInfo").textContent = "";
      toast((execute ? "Could not start: " : "Scan failed: ") + err.message, "error");
      if (execute) { hostScan.cards.innerHTML = ""; Object.keys(multiSlots).forEach(k => delete multiSlots[k]); }
    }
    refreshControlState();
  }
  $("scanPreviewBtn").addEventListener("click", () => startScan(false));
  $("scanExecuteBtn").addEventListener("click", () => startScan(true));

  // -------------------------------------------------- Minimize / maximize (Trades, Performance, Activity)
  // Minimized by default so the analysis below stays visible; the choice is remembered in this browser.
  // The data keeps refreshing while minimized, so it is up to date the moment the box is maximized.
  document.querySelectorAll(".collapse-btn").forEach(btn => {
    const card = $(btn.dataset.target);
    function apply(minimized) {
      card.classList.toggle("is-min", minimized);
      btn.textContent = minimized ? "Maximize ▾" : "Minimize ▴";
      btn.setAttribute("aria-expanded", minimized ? "false" : "true");
    }
    let minimized = true;
    try { minimized = localStorage.getItem("min_" + btn.dataset.target) !== "0"; } catch (e) { /* storage unavailable */ }
    apply(minimized);
    btn.addEventListener("click", () => {
      minimized = !card.classList.contains("is-min");
      apply(minimized);
      try { localStorage.setItem("min_" + btn.dataset.target, minimized ? "1" : "0"); } catch (e) { /* ignore */ }
    });
  });

  // -------------------------------------------------- License card
  function renderLicense(st) {
    const badge = $("licenseBadge"), msg = $("licenseMessage"), card = $("licenseCard");
    $("licenseMachine").textContent = st.machine_id || "—";
    const map = { ACTIVE: ["Active", "ok"], EXPIRING: ["Expiring soon", "warn"], EXPIRED: ["Expired", "bad"],
      NONE: ["Not activated", "bad"], INVALID: ["Invalid key", "bad"], MACHINE: ["Other PC", "bad"],
      NOT_YET: ["Not valid yet", "bad"], CLOCK: ["Clock error", "bad"], NOT_CONFIGURED: ["Not configured", "bad"] };
    const [label, cls] = map[st.state] || [st.state || "?", "bad"];
    badge.textContent = label; badge.className = "license-badge " + cls;
    msg.textContent = st.message || "";
    card.classList.toggle("bad", cls === "bad");
    if (cls === "bad" || st.state === "EXPIRING") $("licenseForm").style.display = "block";
  }
  async function loadLicense() {
    try {
      const st = await (await fetch("/api/license")).json();
      renderLicense(st);
    } catch (e) { /* server busy - try again later */ }
  }
  $("licenseToggle").addEventListener("click", () => {
    const f = $("licenseForm"); f.style.display = f.style.display === "none" ? "block" : "none";
  });
  $("licenseCopyMachine").addEventListener("click", async () => {
    const id = $("licenseMachine").textContent;
    try { await navigator.clipboard.writeText(id); toast("Machine ID copied", "success"); }
    catch (e) { toast("Machine ID: " + id, "info"); }
  });
  $("licenseActivateBtn").addEventListener("click", async () => {
    const key = $("licenseKeyInput").value.trim();
    if (!key) { toast("Paste your license key first", "error"); return; }
    try {
      const st = await postJSON("/api/license/activate", { key });
      $("licenseKeyInput").value = "";
      renderLicense(st);
      $("licenseForm").style.display = "none";
      toast("License activated", "success");
    } catch (err) { toast(err.message, "error"); }
  });
  loadLicense();
  setInterval(loadLicense, 10 * 60 * 1000);

  socket.on("engine_event", dispatchEngineEvent);

  // ---- permanent Trades table + Activity list (read from the server, so they survive pop-ups and restarts)
  const money = v => (v === null || v === undefined) ? "-" : Number(v).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const esc = t => String(t === null || t === undefined ? "" : t).replace(/[&<>]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
  async function loadTrades() {
    try {
      const picked = $("tradesDate").value;
      const r = await (await fetch("/api/trades" + (picked ? "?date=" + picked : ""))).json();
      if (!picked) $("tradesDate").value = r.date;
      $("tradesDateLabel").textContent = "- " + r.date;
      $("tradesCsv").href = "/api/trades.csv?date=" + r.date;
      const s = r.summary;
      $("tradesSummary").innerHTML = s.trades === 0 ? "No trades on this date." :
        `<b>${s.trades}</b> trade(s) - ${s.closed} closed, ${s.open} open - <span class="pnl-pos">${s.wins} win</span> / <span class="pnl-neg">${s.losses} loss</span> - ` +
        `Total P&amp;L: <b class="${s.total_pnl >= 0 ? "pnl-pos" : "pnl-neg"}">Rs ${money(s.total_pnl)}</b>` +
        (s.best !== null ? ` - best ${money(s.best)}, worst ${money(s.worst)}` : "");
      $("tradesBody").innerHTML = r.trades.length === 0 ? '<tr><td colspan="10" class="muted">No trades.</td></tr>' :
        r.trades.map(t => `<tr><td>${t.id}</td><td>${esc(t.entry_time)}</td><td>${esc(t.symbol)}${t.strategy === "LOTTO" ? " (lotto)" : ""}</td>` +
          `<td class="num">${t.qty}</td><td class="num">${money(t.entry_price)}</td><td>${esc(t.exit_time || "OPEN")}</td>` +
          `<td class="num">${money(t.exit_price)}</td><td>${esc(t.exit_reason || "")}</td>` +
          `<td class="num ${t.pnl === null ? "" : (t.pnl >= 0 ? "pnl-pos" : "pnl-neg")}">${t.pnl === null ? "-" : money(t.pnl)}</td><td>${esc(t.mode)}</td></tr>`).join("");
    } catch (e) { /* the table is a convenience; never break the dashboard */ }
  }
  async function loadActivity() {
    try {
      const r = await (await fetch("/api/activity?limit=100")).json();
      $("activityList").innerHTML = r.items.length === 0 ? '<div class="muted small">Nothing yet.</div>' :
        r.items.map(i => `<div class="activity-row ${i.level}"><span class="t">${esc(i.date.slice(5))} ${esc(i.time)}</span><span class="x">${esc(i.text)}</span></div>`).join("");
    } catch (e) { /* ignore */ }
  }
  const fmtN = (v, nd) => (v === null || v === undefined) ? "-" : Number(v).toLocaleString("en-IN", { minimumFractionDigits: nd === undefined ? 2 : nd, maximumFractionDigits: nd === undefined ? 2 : nd });
  const pnlCls = v => v === null || v === undefined ? "" : (v >= 0 ? "pnl-pos" : "pnl-neg");
  function perfTable(title, rows, keyHeader) {
    if (!rows || rows.length === 0) return "";
    return `<div class="small"><b>${title}</b></div><table class="perf-table"><thead><tr><th>${keyHeader}</th><th>Trades</th><th>Win %</th><th>Total P&amp;L</th><th>Avg P&amp;L</th></tr></thead><tbody>` +
      rows.map(r => `<tr><td>${esc(r.key !== undefined ? r.key : r.value)}</td><td>${r.trades}</td><td>${fmtN(r.win_rate, 1)}</td><td class="${pnlCls(r.pnl)}">${fmtN(r.pnl)}</td><td class="${pnlCls(r.avg_pnl)}">${fmtN(r.avg_pnl)}</td></tr>`).join("") + "</tbody></table>";
  }
  function curveSvg(curve) {
    if (!curve || curve.length < 2) return "";
    const ys = curve.map(c => c.pnl), lo = Math.min(0, ...ys), hi = Math.max(0, ...ys), rng = (hi - lo) || 1;
    const pts = ys.map((y, i) => `${(i / (ys.length - 1) * 600).toFixed(1)},${(110 - (y - lo) / rng * 100).toFixed(1)}`).join(" ");
    const zero = (110 - (0 - lo) / rng * 100).toFixed(1);
    return `<svg viewBox="0 0 600 120" style="width:100%;max-height:130px"><line x1="0" y1="${zero}" x2="600" y2="${zero}" stroke="#9ca3af" stroke-dasharray="4"/><polyline fill="none" stroke="#2563eb" stroke-width="2" points="${pts}"/></svg><div class="small muted">Cumulative P&amp;L, trade by trade</div>`;
  }
  async function loadPerformance() {
    try {
      const r = await (await fetch("/api/performance?days=" + $("perfDays").value + "&mode=" + $("perfMode").value)).json();
      const m = r.metrics;
      $("perfNote").textContent = m.trades === 0 ? "No closed trades in this period yet." : m.note;
      const kpi = (k, v, cls) => `<div class="perf-kpi"><div class="k">${k}</div><div class="v ${cls || ""}">${v}</div></div>`;
      $("perfKpis").innerHTML = m.trades === 0 ? "" :
        kpi("Closed trades", m.trades) + kpi("Win rate", fmtN(m.win_rate, 1) + " %") +
        kpi("Win rate needed to break even", m.breakeven_win_rate === null ? "-" : fmtN(m.breakeven_win_rate, 1) + " %") +
        kpi("Profit factor", m.profit_factor === null ? (m.wins ? "no losses yet" : "-") : fmtN(m.profit_factor)) +
        kpi("Expectancy / trade (Rs)", fmtN(m.expectancy), pnlCls(m.expectancy)) + kpi("Total P&L (Rs)", fmtN(m.total_pnl), pnlCls(m.total_pnl)) +
        kpi("Avg win / avg loss (Rs)", fmtN(m.avg_win) + " / " + fmtN(m.avg_loss)) + kpi("Max drawdown (Rs)", fmtN(m.max_drawdown), "pnl-neg") +
        kpi("Longest losing streak", m.longest_loss_streak) + kpi("Trades per day", fmtN(m.avg_trades_per_day, 1));
      $("perfCurve").innerHTML = curveSvg(m.curve);
      const b = r.breakdowns;
      $("perfBreakdowns").innerHTML = perfTable("CALL vs PUT", b.direction, "Direction") + perfTable("How trades ended", b.exit_reason, "Exit reason") +
        perfTable("By entry hour", b.entry_hour, "Hour") + perfTable("Normal vs Lotto", b.strategy, "Strategy");
      const sg = r.signals;
      $("perfSignals").innerHTML = sg.rows.length === 0 ? "No trades with saved analysis yet (manual entries and old trades have none)." :
        `<div class="muted">${sg.trades_with_signals} trade(s) carry a saved analysis. Small groups prove nothing.</div>` +
        perfTable("Signal at entry -> result", sg.rows.map(x => ({ ...x, key: x.signal + " = " + x.value })), "Signal");
    } catch (e) { /* convenience only */ }
  }
  $("perfDays").addEventListener("change", loadPerformance);
  $("perfMode").addEventListener("change", loadPerformance);
  loadPerformance();
  let refreshTimer = null;
  function scheduleRefresh() {
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(() => { loadTrades(); loadActivity(); loadPerformance(); }, 700);
  }
  $("tradesDate").addEventListener("change", loadTrades);
  loadTrades(); loadActivity();
  setInterval(loadTrades, 20000);

  socket.on("engine_event", evt => {
    if (["positions_entered", "exit", "leg_exit", "no_trade", "error", "decision"].includes(evt.type)) scheduleRefresh();
  });

  // Replays the last "universe_ready"/"decision" this server has seen
  // (persisted server-side in app.py's STATE, not just relayed once over
  // the socket) so a page refresh - including while a position is still
  // open and the engine is mid-run - shows the same analysis as before,
  // instead of resetting to blank. Safe to call unconditionally: it's a
  // read of in-memory cached data, no Kite/login needed.
  async function loadLastAnalysis() {
    try {
      const resp = await fetch("/api/last_analysis");
      const data = await resp.json();
      if (data.universe) dispatchEngineEvent(data.universe);
      if (data.decision) dispatchEngineEvent(data.decision);
    } catch (err) {
      // transient network hiccup - live events (if a run is active) will still arrive
    }
  }
  loadLastAnalysis();

  refreshControlState();

  // Sync state on load/refresh (e.g. if Execute was already running before
  // the page was reloaded), and keep polling for the restart-needed flag -
  // editing a .py file never hot-reloads the running server process, so we
  // proactively detect that (comparing the code's own last-modified time
  // against when this server process started) and make it impossible to
  // miss instead of leaving stale-backend confusion to guesswork.
  function applyStatus(data) {
    loggedIn = !!data.logged_in;
    running = !!data.running;
    refreshControlState();

    const banner = $("restartNeededBanner");
    if (data.restart_needed) {
      banner.style.display = "block";
      banner.textContent = `⚠ The code on disk changed after this server started (code updated ` +
        `${data.code_last_modified}, server started ${data.server_started_at}). Close this terminal ` +
        `window completely and run python app.py again - refreshing this page alone does not reload the backend.`;
    } else {
      banner.style.display = "none";
    }
  }

  fetch("/api/status").then(r => r.json()).then(applyStatus).catch(() => {});
  setInterval(() => {
    fetch("/api/status").then(r => r.json()).then(applyStatus).catch(() => {});
  }, 15000);
})();
