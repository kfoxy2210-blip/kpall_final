import math, os, random, sys, threading, time
from datetime import datetime, timedelta, timezone
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pine_orb2 as P

IST = P.IST
DAY = datetime(2026, 10, 27, tzinfo=IST)

def at(sec_from_midnight):
    return DAY + timedelta(seconds=sec_from_midnight)

# ------------------------------------------------------------ A. window / exit maths == the Pine formulas
def pine_entry_end(tf, bars, adaptive, manual_min):
    start = 9*60+15
    adapt = start + int(math.floor(max(tf, bars*tf) + 0.5))
    return adapt if adaptive else 9*60 + manual_min
def pine_exit(tf, bars, adaptive, manual_min, eh, em):
    ee = pine_entry_end(tf, bars, adaptive, manual_min)
    user = eh*60+em
    return max(user, ee + int(math.ceil(tf))) if adaptive else user
def test_formulas():
    n = 0
    for tf in (1, 3, 5, 10, 15):
        for bars in (1, 3, 5, 8):
            for adaptive in (True, False):
                for mm in (16, 20, 29):
                    for (eh, em) in ((9, 30), (9, 45), (10, 5)):
                        p = P.PineParams(tf_min=tf, entry_bars=bars, tf_adaptive=adaptive, entry_end_minute=mm, exit_hour=eh, exit_minute=em)
                        assert p.entry_end_mod == pine_entry_end(tf, bars, adaptive, mm), (tf, bars, adaptive, mm)
                        assert p.exit_mod == pine_exit(tf, bars, adaptive, mm, eh, em)
                        n += 1
    print("A ok:", n, "combinations")

# ------------------------------------------------------------ B. reference Pine simulation (candle based) vs Python on ticks
def make_day(seed, tf=1, minutes=40, start_px=1000.0, vol=0.0009):
    rnd = random.Random(seed)
    px, out = start_px, []
    for i in range(minutes // tf):
        o = px
        steps = [o]
        for _ in range(tf * 3):
            steps.append(steps[-1] * (1 + rnd.gauss(0, vol)))
        c = steps[-1]
        h, l = max(steps), min(steps)
        out.append((i, o, h, l, c, steps))
        px = c
    return out

def ticks_for(bar, tf):
    i, o, h, l, c, _ = bar
    base = 555*60 + i*tf*60
    span = tf*60
    first, second = (h, l) if c >= o else (l, h)
    pts = [(0, o), (span*0.25, first), (span*0.55, second), (span*0.96, c)]
    return [(at(base + t), px) for t, px in pts]

def reference(bars, p, prev_close=None):
    """Pine-faithful, candle based. Returns dict(entry_bar, dir, price, stop, target, exit_reason, exit_bar)"""
    tf = p.tf_min
    day_open = bars[0][1]
    eff = max(day_open*p.breakout_buf_pct/100, p.min_ticks_move*p.mintick)
    up, dn = day_open+eff, day_open-eff
    ee, ex = p.entry_end_mod, p.exit_mod
    pos = None
    for (i, o, h, l, c, _s) in bars:
        bar_open = 555 + i*tf
        bar_close = bar_open + tf
        if pos is None:
            if p.tf_adaptive:
                inwin = 555 <= bar_open <= ee
            else:
                inwin = int(bar_open//60) == 9 and int(bar_open % 60) >= 15 and int(bar_open % 60) <= p.entry_end_minute
            if inwin and p.trade_long and c > up:
                pos = dict(dir="CALL", price=c, stop=c*(1-p.sl_pct/100), entry_bar=i)
            elif inwin and p.trade_short and c < dn:
                pos = dict(dir="PUT", price=c, stop=c*(1+p.sl_pct/100), entry_bar=i)
            if pos:
                risk = abs(pos["price"]-pos["stop"])
                pos["target"] = pos["price"] + risk*p.rr if pos["dir"] == "CALL" else pos["price"] - risk*p.rr
                pos["risk"] = risk
            continue
        if "exit_reason" in pos:
            break
        # --- after entry: this bar is a later bar
        if bar_open >= ex:                      # time exit fills at this bar's open
            pos["exit_reason"], pos["exit_bar"], pos["exit_px"] = "TIME_EXIT", i, o
            break
        if pos["dir"] == "CALL":
            hit_stop, hit_tgt = l <= pos["stop"], h >= pos["target"]
        else:
            hit_stop, hit_tgt = h >= pos["stop"], l <= pos["target"]
        if hit_stop or hit_tgt:
            # intrabar order = the same order the tick generator uses: first extreme then second
            first_is_high = c >= o
            if hit_stop and hit_tgt:
                if pos["dir"] == "CALL":
                    stop_first = not first_is_high           # low comes first when c<o
                else:
                    stop_first = first_is_high
                reason = "STOP_LOSS" if stop_first else "TARGET"
            else:
                reason = "STOP_LOSS" if hit_stop else "TARGET"
            pos["exit_reason"], pos["exit_bar"] = reason, i
            break
    return pos

def run_python(bars, p, prev_close=None):
    orb = P.PineOrb(p)
    orb.set_day_open(bars[0][1], prev_close)
    sig, exit_info = None, None
    tf = p.tf_min
    for bar in bars:
        for (now, px) in ticks_for(bar, tf):
            if sig is None:
                sig = orb.on_price(now, px)
                if sig is not None:
                    # the signal fires on the first tick of the NEXT bar; check_exit starts from this very tick
                    r = orb.check_exit(now, px)
                    if r:
                        exit_info = (r, bar[0])
                        return sig, exit_info
            else:
                r = orb.check_exit(now, px)
                if r:
                    exit_info = (r, bar[0])
                    return sig, exit_info
    # day over without time exit
    return sig, exit_info

def test_vs_reference(trials=300):
    agree = same_exit = entered = 0
    for seed in range(trials):
        for tf in (1, 5):
            p = P.PineParams(tf_min=tf, confirm_on_close=True, breakout_buf_pct=0.08, sl_pct=0.25, rr=1.5,
                             entry_bars=5, tf_adaptive=True, exit_hour=9, exit_minute=30)
            mins = 75 if tf == 5 else 45
            bars = make_day(seed*7+tf, tf=tf, minutes=mins)
            ref = reference(bars, p)
            sig, ex = run_python(bars, p)
            if ref is None:
                assert sig is None, ("python entered but Pine did not", seed, tf)
                agree += 1
                continue
            entered += 1
            assert sig is not None, ("Pine entered but python did not", seed, tf)
            assert sig.direction == ref["dir"]
            assert abs(sig.price - ref["price"]) < 1e-9
            assert abs(sig.stop - ref["stop"]) < 1e-6 and abs(sig.target - ref["target"]) < 1e-6
            agree += 1
            if "exit_reason" in ref and ex:
                assert ex[0] == ref["exit_reason"], ("exit reason", seed, tf, ex, ref["exit_reason"])
                same_exit += 1
    print("B ok: entries/no-entries identical in", agree, "runs; entered", entered, "; exits identical", same_exit)

# ------------------------------------------------------------ C. other Pine features
def test_window_closed_grace():
    p = P.PineParams(tf_min=1, entry_bars=5)
    orb = P.PineOrb(p)
    assert not orb.window_closed_for_good(at(9*3600+20*60+30))
    assert not orb.window_closed_for_good(at(9*3600+21*60+0.5))     # last candle just closed -> still evaluated
    assert orb.window_closed_for_good(at(9*3600+21*60+1.2))
    assert orb.entry_window_end_text() == "09:21" and orb.exit_time_text() == "09:30"
    print("C1 ok (window end", orb.entry_window_end_text(), "exit", orb.exit_time_text(), ")")

def test_gap_filter_and_one_trade():
    p = P.PineParams(use_gap_filter=True, max_gap_pct=1.0)
    orb = P.PineOrb(p); orb.set_day_open(1000, 960)           # 4.17% gap -> blocked
    assert not orb.gap_ok()
    assert orb.on_price(at(9*3600+15*60+1), 1010) is None
    p2 = P.PineParams(confirm_on_close=False)
    o2 = P.PineOrb(p2); o2.set_day_open(1000, 999)
    s = o2.on_price(at(9*3600+16*60), 1003)
    assert s and s.direction == "CALL"
    assert o2.on_price(at(9*3600+17*60), 1010) is None        # one trade per day
    print("C2 ok")

def test_short_and_levels():
    p = P.PineParams(confirm_on_close=False, breakout_buf_pct=0.15, min_ticks_move=1)
    o = P.PineOrb(p); o.set_day_open(100.0, 100.0)
    up, dn = o.levels()
    assert abs(up-100.15) < 1e-9 and abs(dn-99.85) < 1e-9
    s = o.on_price(at(9*3600+16*60), 99.8)
    assert s and s.direction == "PUT" and abs(s.stop - 99.8*1.003) < 1e-9
    # min-ticks floor on a low priced stock
    o2 = P.PineOrb(p); o2.set_day_open(10.0, 10.0)
    up2, dn2 = o2.levels()
    assert abs(up2-10.05) < 1e-9          # 0.15% = 0.015 < 1 tick (0.05)
    print("C3 ok")

def test_ema_atr_exact():
    # EMA / ATR against straightforward reference values
    closes = [100, 101, 102, 101, 103, 104, 103, 105, 106, 105]
    e = P.ema_series(closes, 5)
    k = 2/6
    ref = closes[0]
    for c in closes[1:]:
        ref = c*k + ref*(1-k)
    assert abs(e[-1]-ref) < 1e-12
    candles = [(i, c-0.5, c+1.0, c-1.0, c) for i, c in enumerate(closes)]
    atr, last = P.atr_state(candles, 3)
    # manual Wilder RMA seeded with SMA(3)
    trs, prev = [], None
    for (_t, o, h, l, c) in candles:
        trs.append(h-l if prev is None else max(h-l, abs(h-prev), abs(l-prev))); prev = c
    a = sum(trs[:3])/3
    for tr in trs[3:]:
        a = (a*2 + tr)/3
    assert abs(atr-a) < 1e-12 and last == closes[-1]
    print("C4 ok")

class FakeKite:
    def __init__(self, candles): self.c = candles; self.calls = 0
    def get_intraday_history(self, token, f, t, interval):
        self.calls += 1
        return [{"date": d.replace(tzinfo=IST), "open": o, "high": h, "low": l, "close": c, "volume": 1} for (d, o, h, l, c) in self.c if f <= d <= t]
class FakeFeed:
    def __init__(self, kite): self.kite = kite; self.token = 1

def test_trend_filter_and_trail():
    # history: 3 days of rising 5-min candles -> EMA far BELOW price -> uptrend
    base = datetime(2026, 10, 26, 9, 15)
    hist = []
    px = 900.0
    for d in range(3):
        for i in range(75):
            t = base - timedelta(days=2-d) + timedelta(minutes=5*i)
            o = px; px = px*1.0003; hist.append((t, o, px*1.0004, o*0.9997, px))
    kite = FakeKite(hist)
    P._TL.feed = FakeFeed(kite)
    P._HIST.clear()
    p = P.PineParams(tf_min=5, confirm_on_close=False, use_trend_filter=True, ema_len=50, breakout_buf_pct=0.1)
    o = P.PineOrb(p); o.set_day_open(float(px)*1.0, px)
    assert o._ind_ready, o.notes
    up, dn = o.levels()
    # price breaks DOWN while the trend is UP -> PUT must be vetoed by the EMA filter ... (close < ema is False)
    s = o.on_price(at(9*3600+17*60), dn-0.5)
    assert s is None, "downward break against the EMA must be blocked"
    s = o.on_price(at(9*3600+18*60), up+0.5)
    assert s is not None and s.direction == "CALL"
    # trailing: needs a >=1R run, then stop follows ATR
    p2 = P.PineParams(tf_min=5, confirm_on_close=False, use_trail=True, atr_len=14, atr_mult=1.0, sl_pct=0.3, rr=3.0, breakout_buf_pct=0.1)
    o2 = P.PineOrb(p2); o2.set_day_open(float(px), px)
    up2, _ = o2.levels()
    s2 = o2.on_price(at(9*3600+16*60), up2+0.5)
    assert s2 and s2.direction == "CALL"
    stop0 = s2.stop
    assert o2.check_exit(at(9*3600+17*60), s2.price + s2.risk*0.5) is None
    assert abs(s2.stop - stop0) < 1e-12, "no trail before 1R"
    assert o2.check_exit(at(9*3600+19*60), s2.price + s2.risk*1.4) is None
    assert s2.stop > stop0, "stop must trail up after 1R"
    trailed = s2.stop
    assert o2.check_exit(at(9*3600+19*60+10), s2.price + s2.risk*1.0) is None
    assert s2.stop >= trailed, "stop never moves backwards"
    assert o2.check_exit(at(9*3600+20*60), s2.stop - 0.01) == "STOP_LOSS"
    # no history -> trend filter fails SAFE (no trade), trail falls back to fixed stop
    P._TL.feed = None
    P._HIST.clear()
    p3 = P.PineParams(tf_min=5, confirm_on_close=False, use_trend_filter=True)
    o3 = P.PineOrb(p3); o3.set_day_open(1000.0, 1000.0)
    assert o3.on_price(at(9*3600+16*60), 1010.0) is None
    print("C5 ok (trend veto, trail after 1R, safe fallback)")

def test_official_candle_for_marginal_close():
    # last tick is 1 tick ABOVE the level, official candle closed just BELOW -> must NOT enter
    p = P.PineParams(tf_min=1, confirm_on_close=True, breakout_buf_pct=0.15)
    start = datetime(2026, 10, 27, 9, 15)
    hist = []
    o = P.PineOrb(p)
    o.set_day_open(1000.0, 1000.0)
    up, _ = o.levels()
    official = [(start, 1000.0, up + 0.3, 999.5, up - 0.05)]       # official close below the trigger
    kite = FakeKite(official)
    P._TL.feed = FakeFeed(kite); o._feed = P._TL.feed
    P._HIST.clear()
    orig_sleep = P.time.sleep
    o2 = P.PineOrb(p); o2.set_day_open(1000.0, 1000.0); o2._feed = P._TL.feed
    P.time.sleep = lambda s: None
    try:
        o2.on_price(at(9*3600+15*60+10), up + 0.05)               # last tick of bar 0: marginally above
        sig = o2.on_price(at(9*3600+16*60+0.2), up + 0.02)
    finally:
        P.time.sleep = orig_sleep
    assert sig is None and kite.calls >= 1, "marginal tick close was overruled by the official candle close"
    # clear breakout needs NO network call
    kite2 = FakeKite(official); P._TL.feed = FakeFeed(kite2)
    o3 = P.PineOrb(p); o3.set_day_open(1000.0, 1000.0); o3._feed = P._TL.feed
    o3.on_price(at(9*3600+15*60+10), up + 5)
    sig3 = o3.on_price(at(9*3600+16*60+0.2), up + 5)
    assert sig3 and sig3.direction == "CALL" and kite2.calls == 0
    print("C6 ok (official candle only when marginal, clear breakout = zero network calls)")

class RateLimitedKite:
    """Behaves like Kite's historical API: more than 3 requests inside one second -> 'Too many requests'."""
    def __init__(self, candles, fail_first=0):
        self.c = candles; self.stamps = []; self.lock = threading.Lock(); self.calls = 0; self.fail_first = fail_first
    def get_intraday_history(self, token, f, t, interval):
        with self.lock:
            self.calls += 1
            now = time.time()
            self.stamps = [s for s in self.stamps if now - s < 1.0]
            if self.calls <= self.fail_first or len(self.stamps) >= 3:
                raise RuntimeError("Too many requests")
            self.stamps.append(now)
        return [{"date": d.replace(tzinfo=IST), "open": o, "high": h, "low": l, "close": c, "volume": 1} for (d, o, h, l, c) in self.c if f <= d <= t]

def _history(days=3):
    base = datetime.now().replace(hour=9, minute=15, second=0, microsecond=0)
    hist, px = [], 900.0
    for d in range(days, 0, -1):
        for i in range(75):
            t = base - timedelta(days=d) + timedelta(minutes=5*i)
            o = px; px = px*1.0003; hist.append((t, o, px*1.0004, o*0.9997, px))
    return hist, px

def test_many_stocks_at_once_do_not_hit_rate_limit():
    hist, _ = _history()
    # without the pacing, 12 stocks asking together are refused (this is the old behaviour)
    old_gap, old_tries = P.API_MIN_GAP, P.API_TRIES
    P._HIST.clear(); P.API_MIN_GAP, P.API_TRIES = 0.0, 1
    k = RateLimitedKite(hist); errs = []
    def one(i):
        try: P.load_history(k, 1000 + i, "5minute", force=True)
        except Exception as e: errs.append(e)
    ths = [threading.Thread(target=one, args=(i,)) for i in range(12)]
    [t.start() for t in ths]; [t.join() for t in ths]
    assert errs, "the test must reproduce the rate limit without pacing"
    # with pacing every stock gets its history
    P._HIST.clear(); P.API_MIN_GAP, P.API_TRIES = old_gap, old_tries
    k = RateLimitedKite(hist); errs = []
    ths = [threading.Thread(target=one, args=(i,)) for i in range(12)]
    [t.start() for t in ths]; [t.join() for t in ths]
    assert not errs, errs
    assert all(P.load_history(k, 1000 + i, "5minute") for i in range(12)) and k.calls == 12, k.calls
    print("C7 ok (12 stocks at once: old way failed for some, paced way failed for none)")

def test_failed_history_is_retried_later():
    hist, px = _history()
    P._HIST.clear()
    old = P.API_MIN_GAP; P.API_MIN_GAP = 0.02
    try:
        k = RateLimitedKite(hist, fail_first=3)          # all 3 tries of the first attempt fail
        P._TL.feed = FakeFeed(k)
        p = P.PineParams(tf_min=5, confirm_on_close=False, use_trend_filter=True, ema_len=50)
        o = P.PineOrb(p); o.set_day_open(float(px), px)
        assert not o._ind_ready, "first attempt must fail in this test"
        o._ind_try_at = 0                                 # 20 s later
        o._maybe_retry_indicators()
        t0 = time.time()
        while not o._ind_ready and time.time() - t0 < 5:
            time.sleep(0.05)
        assert o._ind_ready and o._ema is not None, o.notes
    finally:
        P.API_MIN_GAP = old
    print("C8 ok (history that failed once is loaded by the background retry)")

def test_trend_filter_tries_once_more_before_refusing():
    hist, px = _history()
    P._HIST.clear()
    old = P.API_MIN_GAP; P.API_MIN_GAP = 0.02
    try:
        k = RateLimitedKite(hist, fail_first=3)
        P._TL.feed = FakeFeed(k)
        p = P.PineParams(tf_min=5, confirm_on_close=False, use_trend_filter=True, ema_len=50, breakout_buf_pct=0.1)
        o = P.PineOrb(p); o.set_day_open(float(px), px)
        assert not o._ind_ready
        o._ind_try_at = 0
        up, _ = o.levels()
        s = o.on_price(at(9*3600+16*60), up + 0.5)         # uptrend history + upward break
        assert s is not None and s.direction == "CALL", o.notes
    finally:
        P.API_MIN_GAP = old
    print("C9 ok (a trade is not lost just because the first history call failed)")

if __name__ == "__main__":
    test_formulas(); test_vs_reference(); test_window_closed_grace(); test_gap_filter_and_one_trade()
    test_short_and_levels(); test_ema_atr_exact(); test_trend_filter_and_trail(); test_official_candle_for_marginal_close()
    test_many_stocks_at_once_do_not_hit_rate_limit(); test_failed_history_is_retried_later(); test_trend_filter_tries_once_more_before_refusing()
    print("ALL TESTS PASSED")
