import sys

# KP's Pine
BUILT_WITH = (3, 11)
if sys.version_info[:2] != BUILT_WITH:
    raise SystemExit('Python 3.11 needed')

import appcore
appcore.PORT = 5052

try:
    import scan_mode
    scan_mode.register(appcore)
except Exception as _exc:
    print("[scan_mode] add-on not loaded: %s" % _exc)

try:
    import pine_orb2
    pine_orb2.install(scan_mode)
except Exception as _exc:
    print("[pine_orb2] not loaded, standard Pine strategy in use: %s" % _exc)

try:
    import autosl
    autosl.register(appcore)
except Exception as _exc:
    print("[autosl] add-on not loaded: %s" % _exc)

try:
    import kp_journal
    kp_journal.register(appcore)
except Exception as _exc:
    print("[kp_journal] add-on not loaded: %s" % _exc)

try:
    import scanauto
    scanauto.register(appcore)
except Exception as _exc:
    print("[scanauto] add-on not loaded: %s" % _exc)

try:
    import pine_guard
    pine_guard.register(appcore)
except Exception as _exc:
    print("[pine_guard] add-on not loaded: %s" % _exc)

try:
    import fut_mode
    fut_mode.register(appcore)
except Exception as _exc:
    print("[fut_mode] add-on not loaded: %s" % _exc)

try:
    import profit_lock
    profit_lock.register(appcore)
except Exception as _exc:
    print("[profit_lock] add-on not loaded: %s" % _exc)

try:
    import ltp_watch
    ltp_watch.register(appcore)
except Exception as _exc:
    print("[ltp_watch] add-on not loaded: %s" % _exc)


if __name__ == "__main__":
    appcore.main()
