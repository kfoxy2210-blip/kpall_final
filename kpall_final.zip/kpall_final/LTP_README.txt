LIVE LTP (sabhi 4 apps): topbar ke neeche hamesha dikhne wali rangeen strip.
- Algo: Settings wala script (underlying)  | Multi: teeno script ke naam | Pine: Scan wale apne stocks | Auto: Auto SL ka Script.
- Script badlo to LTP apne aap usi ka dikhne lagta hai. '+' dabakar koi bhi aur script (NIFTY, SENSEX, RELIANCE ...) jod sakte ho (x se hatao).
- Trade open ho ya na ho, app khulte hi chalta rehta hai (Zerodha Login ke baad apne aap shuru).
- Backend: ltp_watch.py (apna alag Kite websocket + REST fallback), trading engine ko chhua nahi.

## Profit Shield + trade journal safety net (new)

- **Profit shield*- (Control card box, same switch in Multi / Scan+Pine / Auto SL; OFF by default): a new trade may lose at most
  N% (default 80, editable 1-100) of today's closed profit. Example: today +Rs 10,000 -> the next trade is squared off at a
  Rs 8,000 loss. The limit is frozen when the trade starts; Stop Loss / Profit lock / other exits still work. If today's
  closed P&L is zero or negative the shield does not act. Files: `profit_shield.py`, `static/profit_shield.js`.
- **Journal safety net*- (`journal_guard.py`): Auto SL exits are written to the journal when the Auto module does not do it
  itself; every 30 s a row that is still OPEN while Zerodha already shows the symbol flat is closed with Zerodha's price;
  `trade_journal.backup.json` is kept and restored if the journal ever comes back empty.
