# KP's apps - 4 mobile (Android) apps

| App | Folder | App ID | Dashboard port | Add-on |
|---|---|---|---|---|
| KP's Algo  | KPs_Algo  | com.kp.algo  | 5050 | - (Normal, Manual Entry) |
| KP's Multi | KPs_Multi | com.kp.multi | 5051 | - (3 underlyings ek saath) |
| KP's Pine  | KPs_Pine  | com.kp.pine  | 5052 | scan_mode (Scan + Pine) |
| KP's Auto  | KPs_Auto  | com.kp.auto  | 5053 | autosl (Auto SL / Target) |

Chaaro phone me alag-alag app ki tarah install hote hain (alag App ID), har ek ka apna settings,
license, trade journal aur Zerodha token. Icon ka rang alag hai (Algo neela, Multi purple, Pine hara, Auto orange).

## Build (sample AlgoApps jaisa hi)
1. Naya GitHub repo banao -> `kpall_final.zip` upload karo.
2. `.github/workflows/build.yml` banao -> is zip me di gayi `kpall_final.yml` ka text paste karo -> Commit.
   (Agar tumhara purana build.yml hai to usme sirf 4 folders ke naam / matrix badal lo: KPs_Algo, KPs_Multi, KPs_Pine, KPs_Auto; Python 3.11.)
3. Actions me run -> 4 builds hare hone chahiye.
4. Releases me `KPs_Algo.apk`, `KPs_Multi.apk`, `KPs_Pine.apk`, `KPs_Auto.apk` -> phone me install.

## Dhyan rakhne wali baatein
* **License**: har app ka Machine ID alag hoga (License card me). Chaaro ke liye seller se alag key lo.
* **Zerodha login**: redirect URL `http://127.0.0.1:5000/` sabke liye same hai, isliye ek time par ek hi app me login karo.
* Chaaro ek saath chalane par ek hi Kite API key ki limits (3 websocket, rate limit) share hoti hain - har app ki Settings me alag API key dena safer hai.
* Sabhi apps same Zerodha account trade karte hain - margin aur risk jodkar dekho. `dry_run` ON rakho jab tak achhe se test na ho jaye.
* Signing key (`algoai.keystore`) chaaro me same hai, isliye naya build purane ke upar install hota hai aur settings bachi rehti hain.
* Python 3.11 zaroori hai (protected .pyc files 3.11 ke liye bani hain) - `build.gradle` me already `version = "3.11"` hai.
