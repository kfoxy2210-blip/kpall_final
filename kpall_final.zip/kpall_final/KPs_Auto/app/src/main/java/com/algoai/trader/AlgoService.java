package com.algoai.trader;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.AssetManager;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;

import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * Foreground service: starts the Python trading engine + dashboard server and keeps the
 * phone's CPU awake so SL / target / force-exit still run while the screen is off.
 */
public class AlgoService extends Service {
    static final String CHANNEL = "algo_engine";
    static final String ACTION_STOP = "com.algoai.trader.STOP";
    static final int NOTIF_ID = 1;
    static final int PORT = 5053;

    static volatile boolean pythonStarted = false;
    static volatile String lastError = null;

    private PowerManager.WakeLock wakeLock;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Bridge.appContext = getApplicationContext();
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            shutdown();
            return START_NOT_STICKY;
        }
        createChannel();
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIF_ID, n);
        }
        acquireWakeLock();
        startPythonOnce();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        releaseWakeLock();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ notification

    private void createChannel() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel ch = new NotificationChannel(
                CHANNEL, "Trading engine", NotificationManager.IMPORTANCE_LOW);
        ch.setDescription("Shown while the trading engine is running in the background");
        nm.createNotificationChannel(ch);
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Intent stop = new Intent(this, AlgoService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Action stopAction = new Notification.Action.Builder(
                Icon.createWithResource(this, R.drawable.ic_notify), "Stop engine", stopPi).build();

        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_notify)
                .setContentTitle(getString(R.string.app_name) + " is running")
                .setContentText("Tap to open the dashboard. Square off open trades before stopping.")
                .setOngoing(true)
                .setContentIntent(openPi)
                .addAction(stopAction)
                .build();
    }

    // ------------------------------------------------------------------ wake lock

    private void acquireWakeLock() {
        try {
            if (wakeLock == null) {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "algotrader:engine");
                wakeLock.setReferenceCounted(false);
            }
            // 10 h covers a full market day; opening the app re-arms it.
            wakeLock.acquire(10L * 60L * 60L * 1000L);
        } catch (Exception ignored) {
        }
    }

    private void releaseWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Exception ignored) {
        }
    }

    // ------------------------------------------------------------------ stop

    private void shutdown() {
        releaseWakeLock();
        stopForeground(true);
        stopSelf();
        // The Python server runs inside this process: ending the process ends it cleanly.
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override public void run() { Process.killProcess(Process.myPid()); }
        }, 400);
    }

    // ------------------------------------------------------------------ python

    private synchronized void startPythonOnce() {
        if (pythonStarted) return;
        pythonStarted = true;
        lastError = null;
        final Context ctx = getApplicationContext();
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                try {
                    File dir = new File(ctx.getFilesDir(), "algo_ai");
                    new File(dir, "android_error.txt").delete();
                    syncAssets(ctx, dir);
                    if (!Python.isStarted()) {
                        Python.start(new AndroidPlatform(ctx));
                    }
                    // Blocks for as long as the dashboard server runs.
                    Python.getInstance().getModule("android_entry")
                            .callAttr("start", dir.getAbsolutePath(), PORT);
                } catch (Throwable e) {
                    StringWriter sw = new StringWriter();
                    e.printStackTrace(new PrintWriter(sw));
                    lastError = sw.toString();
                }
                pythonStarted = false;   // allows a retry the next time the app is opened
            }
        }, "algo-python");
        t.start();
    }

    /** Copies the bundled engine code to private storage (user data files are never touched). */
    private static void syncAssets(Context ctx, File dir) throws Exception {
        long stamp = ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0).lastUpdateTime;
        File marker = new File(dir, ".apk_stamp");
        if (marker.exists() && new File(dir, "app.py").exists()) {
            String old = new String(java.nio.file.Files.readAllBytes(marker.toPath())).trim();
            if (old.equals(String.valueOf(stamp))) return;
        }
        cleanOldCode(dir);
        copyAssetDir(ctx.getAssets(), "algo_ai", dir);
        java.nio.file.Files.write(marker.toPath(), String.valueOf(stamp).getBytes());
    }

    /**
     * Removes the previous version's code (but never your .json / .txt data files). Needed because
     * Python prefers a leftover .py over a new .pyc and would silently run the OLD program.
     */
    private static void cleanOldCode(File dir) {
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            String n = f.getName();
            if (f.isDirectory()) {
                if (n.equals("static") || n.equals("templates") || n.equals("__pycache__")) deleteTree(f);
            } else if (n.endsWith(".py") || n.endsWith(".pyc")) {
                f.delete();
            }
        }
    }

    private static void deleteTree(File f) {
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteTree(k);
        f.delete();
    }

    private static void copyAssetDir(AssetManager am, String assetPath, File target) throws Exception {
        String[] children = am.list(assetPath);
        if (children != null && children.length > 0) {
            if (!target.exists() && !target.mkdirs()) throw new Exception("cannot create " + target);
            for (String child : children) {
                copyAssetDir(am, assetPath + "/" + child, new File(target, child));
            }
        } else {
            File parent = target.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
            InputStream in = am.open(assetPath);
            try {
                OutputStream out = new FileOutputStream(target);
                try {
                    byte[] buf = new byte[16384];
                    int r;
                    while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
                } finally {
                    out.close();
                }
            } finally {
                in.close();
            }
        }
    }
}
