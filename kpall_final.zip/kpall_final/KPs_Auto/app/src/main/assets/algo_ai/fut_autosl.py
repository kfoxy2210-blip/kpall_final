"""Auto SL / Target for FUTURES and SOLD OPTIONS (companion of fut_mode.py).

The original Auto SL guard only knows long options. When the Trade instrument box is not "Option + Buy",
the Auto SL "Execute" button is routed here:

  * direction CALL / PUT / AUTO comes from the same Auto SL logic (AUTO = signal vote, unchanged)
  * FUTURE: CALL = BUY future, PUT = SELL future.  OPTION SELL: CALL = sell ATM/ITM PE, PUT = sell CE
  * SL / target / breakeven / trailing: the original ATR levels and PositionState are reused. A SELL leg is
    watched on the mirrored price (2 x entry - price), so the same long-side maths applies.
  * Futures use percent limits suited to a futures price (0.15%..1.2%) instead of the option-premium
    10%..30%, so the stop is not thousands of points away.
Positions show in the normal Auto SL panel. Orders: MARKET / MIS, dry_run respected.
"""
import datetime as _dt
import threading
import time

import fut_mode as fm

_S = {"lock": threading.RLock(), "legs": {}, "closed": [], "thread": None, "stop": threading.Event(),
      "appcore": None, "error": None}
STORE = fm.OpenStore(fm.os.path.join(fm.BASE_DIR, "fut_autosl_open.json"))
FUT_PCT = {"min_sl_pct": 0.15, "max_sl_pct": 1.2, "fallback_sl_pct": 0.4}


def levels_params(kind, params):
    p = dict(params)
    if kind == "FUT":
        p.update(FUT_PCT)
    return p


def shown_levels(leg):
    st = leg["state"]
    if leg["side"] == "BUY":
        return st.sl, st.target
    e = leg["entry_price"]
    return round(2 * e - st.sl, 2), round(2 * e - st.target, 2)


def mirrored(leg, px):
    return px if leg["side"] == "BUY" else 2 * leg["entry_price"] - px


def guard_once(appcore, A):
    client = appcore.STATE.get("kite_client")
    if client is None:
        return
    with _S["lock"]:
        items = list(_S["legs"].items())
    for sym, L in items:
        px = fm.live_price(client, L)
        if not px:
            continue
        L["ltp"] = px
        L["pnl"] = fm.pnl_of(L["side"], L["entry_price"], px, L["qty"])
        reason = None
        with A._LOCK:
            manual = sym in A.G.get("exit_now", set())
            if manual:
                A.G["exit_now"].discard(sym)
        if manual:
            reason = "MANUAL_EXIT"
        elif A._force_exit_due(appcore):
            reason = "FORCE_EXIT_TIME"
        elif _profit_lock_hit(client, L):
            reason = "PROFIT_LOCK"
            L["status"] = "EXIT"
        elif _profit_shield_hit(L):
            reason = "PROFIT_SHIELD"
            L["status"] = "EXIT"
        else:
            hit = A.core.step(L["state"], mirrored(L, px), A.G["params"])
            if hit:
                reason = hit[0]
                L["status"] = "EXIT"
        if reason:
            close(appcore, client, L, reason)
        else:
            L["stage"] = L["state"].stage


def _profit_shield_hit(L):
    try:
        import profit_shield
        return profit_shield.check_leg(L, A_log())
    except Exception:
        return False


def _profit_lock_hit(client, L):
    try:
        import profit_lock
        return profit_lock.check_margin_leg(client, L, A_log())
    except Exception:
        return False


def close(appcore, client, L, reason):
    ok, why = fm.close_leg(client, L, A_log(), reason)
    L["ltp"] = L.get("exit_price") or L.get("ltp")
    L["pnl"] = fm.pnl_of(L["side"], L["entry_price"], L["ltp"], L["qty"])
    if ok or L.get("confirmed") is False:
        fm.journal_row(dict(L, source="AUTOSL"), "DRY" if fm.is_dry(client) else "LIVE", why)
        with _S["lock"]:
            _S["closed"].append({"symbol": L["tradingsymbol"], "side": L["side"], "qty": L["qty"],
                                 "entry": L["entry_price"], "exit": L.get("exit_price"), "reason": why,
                                 "pnl": L["pnl"], "mode": "DRY" if fm.is_dry(client) else "LIVE",
                                 "time": _dt.datetime.now().strftime("%H:%M:%S")})
    if ok:
        with _S["lock"]:
            _S["legs"].pop(L["tradingsymbol"], None)
        STORE.remove(L["tradingsymbol"])


def A_log():
    import autosl
    return autosl._log


def loop(appcore, A):
    while not _S["stop"].is_set():
        try:
            guard_once(appcore, A)
            _S["error"] = None
        except Exception as exc:
            _S["error"] = str(exc)
            A._log("fut guard error: %s" % exc)
        if not _S["legs"]:
            break
        _S["stop"].wait(A.POLL_SECONDS)
    _S["thread"] = None


def ensure_thread(appcore, A):
    with _S["lock"]:
        if _S["thread"] and _S["thread"].is_alive():
            return
        _S["stop"] = threading.Event()
        t = threading.Thread(target=loop, args=(appcore, A), daemon=True, name="autosl-fut-guard")
        _S["thread"] = t
        t.start()


def enter(appcore, body):
    import autosl as A
    core = A.core
    body = body or {}
    cfg = fm.load_cfg()
    name = str(body.get("underlying", "")).strip().upper()
    direction = str(body.get("direction", "AUTO")).strip().upper()
    strike_mode = str(body.get("strike_mode", "ATM")).strip().upper()
    try:
        lots = int(body.get("lots", 1))
    except (TypeError, ValueError):
        lots = 0
    a = A._begin_analysis(name or "?", direction, lots, strike_mode)
    A._log("Execute pressed (%s): %s" % (cfg["instrument"] + (" " + cfg["option_side"] if cfg["instrument"] == "OPTION" else ""), a.get("request")))
    if not name:
        return A._fail(a, "type a script name, e.g. NIFTY")
    if direction not in ("AUTO", "CALL", "PUT"):
        return A._fail(a, "direction must be AUTO, CALL or PUT")
    if strike_mode not in ("ATM", "ITM1"):
        return A._fail(a, "strike_mode must be ATM or ITM1")
    if lots < 1 or lots > 100:
        return A._fail(a, "lots must be 1..100")
    try:
        appcore.license_manager.require_active()
    except appcore.license_manager.LicenseError as exc:
        return A._fail(a, str(exc))
    name, (spot_ex, spot_sym, deriv) = A._underlying_info(name)
    st = appcore.STATE
    client = st.get("kite_client")
    if not st.get("logged_in") or client is None:
        A._step(a, "Zerodha login", "not logged in", False)
        return A._fail(a, "please Login first (top of the page)")
    A._step(a, "Zerodha login", "OK")
    s = A._settings(appcore)
    live = A._live_enabled(appcore)
    A._step(a, "Mode", "LIVE - real orders" if live else "DRY RUN - simulated, no real order")
    now_t = A._now().time()
    w0, w1 = A._hhmm(s.get("entry_window_start"), "09:30"), A._hhmm(s.get("entry_window_end"), "14:30")
    if not (w0 <= now_t <= w1) and live:
        return A._fail(a, "outside entry window %s-%s (Settings)" % (w0.strftime("%H:%M"), w1.strftime("%H:%M")))
    if any(A._belongs(l["tradingsymbol"], name) for l in _S["legs"].values()) or \
            any(A._belongs(v.get("symbol", ""), name) for v in A.G.get("virtual", {}).values()):
        return A._fail(a, "%s already has an open trade here" % name)
    skey = "%s:%s" % (spot_ex, spot_sym)
    try:
        spot = float(A._quotes(client, [skey]).get(skey, {}).get("last_price"))
    except Exception as exc:
        A._step(a, "Live price", "unavailable (%s)" % exc, False)
        return A._fail(a, "no live price for %s - check the script name / Kite connection" % skey)
    A._step(a, "Spot", "%.2f" % spot)
    try:
        rows = [r for r in A._instruments(client, deriv) if r.get("name") == name]
    except Exception as exc:
        return A._fail(a, "could not load %s instruments: %s" % (deriv, exc))
    if direction == "AUTO":
        res = A.auto_signal(client, spot_ex, spot_sym, deriv, rows, spot, A.G["params"])
        A._step(a, "AUTO score", "%+d (need %d) -> %s. %s" % (res.get("score", 0), A.G["params"]["auto_min_score"],
                                                              res.get("direction") or "NO TRADE", res.get("reason", "")),
                res.get("direction") is not None)
        if res.get("direction") is None:
            return A._fail(a, "NO TRADE - %s (choose CALL or PUT yourself to test anyway)" % res.get("reason", ""))
        direction = res["direction"]
    plan = fm.plan_for(direction, cfg)
    if plan is None:
        return A._fail(a, "%s has no order in this mode (Future side = %s)" % (direction, cfg["future_side"]))
    kind, side, opt_type = plan
    A._step(a, "Direction", "%s -> %s %s" % (direction, side, "future" if kind == "FUT" else opt_type))
    try:
        if kind == "FUT":
            instr = client.get_futures_instrument(name, deriv, _dt.date.today())
        else:
            instr = core.pick_contract(rows, spot, "CALL" if opt_type == "CE" else "PUT", strike_mode,
                                       A._now().date())
            if instr is None:
                return A._fail(a, "no option contracts found for %s on %s" % (name, deriv))
        leg = fm.make_leg(kind, side, instr, deriv, lots, {"underlying": name})
    except Exception as exc:
        return A._fail(a, "could not pick the contract: %s" % exc)
    A._step(a, "Contract", "%s | lot size %d | qty %d" % (leg["tradingsymbol"], leg["lot_size"], leg["qty"]))
    key = "%s:%s" % (leg["exchange"], leg["tradingsymbol"])
    try:
        q = A._quotes(client, [key]).get(key, {})
        ltp = float(q.get("last_price"))
    except Exception as exc:
        return A._fail(a, "no live price for %s" % leg["tradingsymbol"])
    leg["ltp"] = ltp
    A._step(a, "Price (LTP)", "%.2f" % ltp)
    if kind == "OPT":
        try:
            bid = float(q["depth"]["buy"][0]["price"])
            ask = float(q["depth"]["sell"][0]["price"])
            if bid > 0 and ask > 0:
                spr = (ask - bid) / ((ask + bid) / 2.0) * 100.0
                A._step(a, "Spread gate (max %.0f%%)" % A.MAX_SPREAD_PCT, "bid %.2f / ask %.2f = %.2f%%" % (bid, ask, spr),
                        spr <= A.MAX_SPREAD_PCT)
                if spr > A.MAX_SPREAD_PCT:
                    return A._fail(a, "spread too wide on %s (%.2f%%)" % (leg["tradingsymbol"], spr))
        except Exception:
            A._step(a, "Spread gate", "no depth data - skipped")
    params = levels_params(kind, A.G["params"])
    candles = A._candles(client, leg["exchange"], leg["tradingsymbol"], A._now() - _dt.timedelta(hours=72), A._now())
    if not fm.open_leg(client, leg, s, A._log):
        return A._fail(a, "%s %s failed or not confirmed - check Zerodha positions" % (side, leg["tradingsymbol"]))
    lv = core.compute_levels(leg["entry_price"], candles, params)
    leg["state"] = core.PositionState(leg["entry_price"], lv)
    leg["state"].ps_skip = True
    leg["state"].pl_skip = True      # Profit lock for these legs is margin based (see _profit_lock_hit)
    leg["status"], leg["stage"], leg["why"], leg["source"] = "WATCHING", "INITIAL", lv.get("source", ""), "AUTOSL"
    leg["params"] = params
    sl, tg = shown_levels(leg)
    A._step(a, "Auto SL / Target", "SL %.2f | Target %.2f | %s | R:R 1:%.1f" % (sl, tg, lv.get("source", ""), params["rr"]))
    A._step(a, "Risk / reward", "loss if SL hits about Rs %.0f | gain if target hits about Rs %.0f"
            % (abs(leg["entry_price"] - sl) * leg["qty"], abs(tg - leg["entry_price"]) * leg["qty"]))
    try:
        import trade_journal
        fm.journal_open(leg, fm._ORIG.get("record_entry") or trade_journal.record_entry, fm.is_dry(client), "AUTOSL", False, None)
    except Exception as exc:
        A._log("[journal] entry not recorded: %s" % exc)
    with _S["lock"]:
        _S["legs"][leg["tradingsymbol"]] = leg
    STORE.add(leg)
    ensure_thread(appcore, A)
    msg = "EXECUTED: %s %s x%d at %.2f%s" % (side, leg["tradingsymbol"], leg["qty"], leg["entry_price"],
                                             "" if live else " (SIMULATED)")
    A._log(msg)
    with A._LOCK:
        a["result"], a["ok"] = msg, True
    return {"ok": True, "message": msg, "symbol": leg["tradingsymbol"]}


def resume_saved(appcore, A):
    """Pick up this add-on's Auto SL legs after a restart (called from the Arm button / guard)."""
    client = appcore.STATE.get("kite_client")
    if client is None:
        return 0
    n = 0
    for saved in STORE.all():
        sym = saved["tradingsymbol"]
        if sym in _S["legs"]:
            continue
        if not fm.is_dry(client):
            net = fm.net_qty(client, saved)
            if not net or (net > 0) != (saved["side"] == "BUY"):
                STORE.remove(sym)
                continue
            saved["qty"] = abs(net)
        params = saved.get("params") or A.G["params"]
        try:
            candles = A._candles(client, saved["exchange"], sym, A._now() - _dt.timedelta(hours=72), A._now())
            lv = A.core.compute_levels(saved["entry_price"], candles, params)
            saved["state"] = A.core.PositionState(saved["entry_price"], lv)
            saved["state"].pl_skip = True
            saved["state"].ps_skip = True
        except Exception:
            continue
        saved.update(status="WATCHING", stage="INITIAL", why="resumed after restart")
        with _S["lock"]:
            _S["legs"][sym] = saved
        n += 1
    if n:
        ensure_thread(appcore, A)
    return n


def snapshot_rows():
    rows, open_pnl = [], 0.0
    with _S["lock"]:
        legs = list(_S["legs"].values())
        closed = list(_S["closed"])
    for L in legs:
        sl, tg = shown_levels(L)
        pnl = fm.pnl_of(L["side"], L["entry_price"], L.get("ltp"), L["qty"])
        open_pnl += pnl
        rows.append({"symbol": L["tradingsymbol"], "side": L["label"], "qty": L["qty"], "entry": L["entry_price"],
                     "ltp": L.get("ltp"), "sl": sl, "target": tg, "stage": L.get("stage", "INITIAL"),
                     "status": L.get("status", "WATCHING"), "levels_from": L.get("why", ""), "pnl": round(pnl, 2),
                     "simulated": fm.is_dry(_S["appcore"].STATE.get("kite_client")) if _S["appcore"] and
                     _S["appcore"].STATE.get("kite_client") else True, "why": L.get("why", "")})
    return rows, round(open_pnl, 2), closed


def register(appcore):
    import autosl as A
    _S["appcore"] = appcore
    app = appcore.app
    orig_enter = app.view_functions["autosl_enter"]
    orig_arm = app.view_functions["autosl_arm"]
    orig_disarm = app.view_functions["autosl_disarm"]
    orig_snapshot = A.snapshot
    from flask import jsonify, request

    def autosl_enter():
        if fm.is_passthrough(fm.load_cfg()):
            return orig_enter()
        body = request.get_json(silent=True) or {}
        if body.get("params"):
            try:
                with A._LOCK:
                    A.G["params"] = A.core.clean_params(dict(A.G["params"], **body["params"]))
                    A._save_params(appcore)
            except ValueError as exc:
                return jsonify({"ok": False, "error": str(exc)}), 400
        res = enter(appcore, body)
        return jsonify(res), (200 if res.get("ok") else 400)
    app.view_functions["autosl_enter"] = autosl_enter

    def autosl_arm():
        resume_saved(appcore, A)
        return orig_arm()
    app.view_functions["autosl_arm"] = autosl_arm

    def autosl_disarm():
        _S["stop"].set()
        return orig_disarm()
    app.view_functions["autosl_disarm"] = autosl_disarm

    def snapshot(appcore_arg):
        snap = orig_snapshot(appcore_arg)
        rows, open_pnl, closed = snapshot_rows()
        if rows or closed:
            snap["positions"] = list(snap.get("positions", [])) + rows
            snap["closed"] = list(snap.get("closed", [])) + closed
            snap["open_pnl"] = round(snap.get("open_pnl", 0) + open_pnl, 2)
            snap["closed_pnl"] = round(snap.get("closed_pnl", 0) + sum(c["pnl"] for c in closed), 2)
            snap["total_pnl"] = round(snap["open_pnl"] + snap["closed_pnl"], 2)
        return snap
    A.snapshot = snapshot
    return True
