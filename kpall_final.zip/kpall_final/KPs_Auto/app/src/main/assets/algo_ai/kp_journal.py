"""KP add-on: show Auto SL / Target trades in the Trades, Performance and Activity cards.

Why: the Auto SL / Target add-on keeps its trades in its own list, so the dashboard's "Trades" table,
"Performance" card and "Activity" list (which are built from trade_journal.json) stayed empty in the Auto app.

What this does (journal only - NO trading logic is touched):
  * wraps autosl._record_closed: the ORIGINAL runs first, unchanged; afterwards the closed trade is also
    written to trade_journal (record_entry + record_exit, exactly like the main engine does);
  * a small watcher thread notices a newly opened Auto SL position and writes its journal entry (OPEN) so
    "Trades" shows it right away.
Every step is wrapped in try/except: a journal problem can never affect the Auto SL guard or any order.
"""
import threading
import time

_STATE = {"done": False}


def _ctype(symbol):
    s = str(symbol or "").upper()
    return "CE" if s.endswith("CE") else ("PE" if s.endswith("PE") else "CE")


def register(appcore):
    if _STATE["done"]:
        return
    try:
        import autosl
    except Exception as exc:                                   # noqa: BLE001
        print("[kp_journal] Auto SL not loaded, nothing to bridge: %s" % exc)
        return
    tj = getattr(appcore, "trade_journal", None)
    if tj is None:
        try:
            import trade_journal as tj                          # noqa: F811
        except Exception as exc:                                # noqa: BLE001
            print("[kp_journal] trade_journal not available: %s" % exc)
            return
    if not (hasattr(autosl, "_record_closed") and hasattr(autosl, "snapshot")
            and hasattr(tj, "record_entry") and hasattr(tj, "record_exit")):
        print("[kp_journal] unexpected Auto SL / journal version - bridge not installed")
        return
    _STATE["done"] = True

    lock = threading.Lock()
    opened = set()        # symbols already written to the journal as OPEN
    just_closed = {}      # symbol -> time of close (the watcher must not re-open them)

    def position(sym, qty, entry):
        return {"tradingsymbol": sym, "id": sym, "type": _ctype(sym),
                "qty": int(qty or 0), "entry_price": float(entry or 0.0)}

    def open_entry(sym, qty, entry, dry):
        if not sym:
            return
        with lock:
            if sym in opened:
                return
            opened.add(sym)
        try:
            tj.record_entry(position(sym, qty, entry), bool(dry), "AUTO_SL", False, None)
            tj.add_activity("entered", "Auto SL/Target entered: %s x%s @ %s%s"
                            % (sym, qty, entry, " (dry run)" if dry else ""), "good")
        except Exception as exc:                                # noqa: BLE001
            print("[kp_journal] could not record the entry: %s" % exc)

    original_closed = autosl._record_closed

    def wrapped_closed(sym, qty, entry, exit_px, reason, mode):
        result = original_closed(sym, qty, entry, exit_px, reason, mode)    # original first, untouched
        try:
            dry = str(mode).upper() != "LIVE"
            open_entry(sym, qty, entry, dry)
            confirmed = "UNCONFIRMED" not in str(reason).upper()
            tj.record_exit(position(sym, qty, entry), float(exit_px), str(reason), int(qty or 0), confirmed, dry)
            pnl = (float(exit_px) - float(entry)) * int(qty or 0)
            tj.add_activity("exit", "Auto SL/Target exit (%s): %s  P&L %.2f%s"
                            % (reason, sym, pnl, " (dry run)" if dry else ""), "good" if pnl >= 0 else "bad")
        except Exception as exc:                                # noqa: BLE001
            print("[kp_journal] could not record the exit: %s" % exc)
        finally:
            with lock:
                opened.discard(sym)
                just_closed[sym] = time.time()
        return result

    autosl._record_closed = wrapped_closed

    def watcher():
        while True:
            time.sleep(2.0)
            try:
                snap = autosl.snapshot(appcore)
                now = time.time()
                for p in (snap.get("positions") or []):
                    if str(p.get("status", "")).startswith("EXIT"):
                        continue
                    sym = p.get("symbol")
                    with lock:
                        if now - just_closed.get(sym, 0) < 60:
                            continue
                    open_entry(sym, p.get("qty"), p.get("entry"), p.get("simulated"))
            except Exception:                                   # noqa: BLE001 - never disturb the engine
                pass

    threading.Thread(target=watcher, daemon=True, name="kp-journal-watch").start()
    print("[kp_journal] Auto SL trades will now also appear in Trades / Performance / Activity")
