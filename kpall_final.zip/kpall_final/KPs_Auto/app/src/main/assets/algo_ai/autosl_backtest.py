# Launcher only - the logic is in autosl_backtest_impl.pyc.   Usage: python autosl_backtest.py NIFTY 60
import sys
import autosl_backtest_impl as _impl
sys.exit(_impl.main(sys.argv))
