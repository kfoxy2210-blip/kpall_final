# KP's Multi

Multi-trade - NIFTY + SENSEX + more together - Android app (Chaquopy + WebView), dashboard port 5051.

Engine = latest KP's Algo AI build (Futures + Options, Profit lock, Auto SL, Pine guard).
Look = colourful per-app theme (static/kp_ui.css) + bottom navigation (static/kp_nav.js).
Build: see ../HOW_TO_BUILD.md
