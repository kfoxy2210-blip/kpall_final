"""
Android entry point (called from AlgoService through Chaquopy).

Runs the protected build (appcore.pyc) exactly as `python app.py` would on a PC, with only
these environment adjustments - the program's own files and licensing are not touched:
  * working folder = the app's private folder (settings.json, token.json, journal live there)
  * "open the browser" is redirected to the in-app WebView
  * Flask-SocketIO's dev-server guard is satisfied (Android has no interactive terminal)
  * clocks are pinned to IST because the engine uses naive local time for market hours
"""
import os
import sys
import time
import traceback


def _pin_ist():
    """The engine uses naive local time for market hours, so the clock MUST be IST."""
    for name in ("Asia/Kolkata", "IST-5:30", "Asia/Calcutta"):
        os.environ["TZ"] = name
        try:
            time.tzset()
        except Exception:                # noqa: BLE001
            continue
        if time.localtime().tm_gmtoff == 19800:
            break
    print("[android_entry] clock: %s (UTC%+d min) TZ=%s" % (
        time.strftime("%H:%M:%S"), time.localtime().tm_gmtoff // 60, os.environ.get("TZ")))


def _patch_browser():
    """webbrowser.open(url) -> show the page inside the app's WebView (Zerodha login etc.)."""
    import webbrowser
    try:
        from java import jclass          # only exists inside Chaquopy
        bridge = jclass("com.algoai.trader.Bridge")

        def _open(url, new=0, autoraise=True):
            bridge.openUrl(str(url))
            return True
    except Exception:                    # noqa: BLE001 - running outside Android (tests / PC)
        def _open(url, new=0, autoraise=True):
            print("[android_entry] open this URL:", url)
            return True
    webbrowser.open = _open
    webbrowser.open_new = _open
    webbrowser.open_new_tab = _open


def _patch_socketio():
    """Flask-SocketIO refuses its built-in server when stdin is not a terminal (always the case
    on Android) unless allow_unsafe_werkzeug=True. The server only listens on 127.0.0.1."""
    import flask_socketio
    original = flask_socketio.SocketIO.run

    def run(self, app, host=None, port=None, **kwargs):
        kwargs.setdefault("allow_unsafe_werkzeug", True)
        return original(self, app, host=host, port=port, **kwargs)

    flask_socketio.SocketIO.run = run


def _patch_tick_emit(interval=1.0):
    """The dashboard page runs a full-page DOM query for EVERY live tick, and right before an entry
    ~80 option contracts stream several ticks per second each. A PC browser copes; a phone WebView
    freezes. So ticks are coalesced: at most one (latest) tick per instrument per `interval` second,
    sent from a helper thread. The engine itself still sees every tick - only the screen feed is thinned."""
    import threading
    import flask_socketio
    original = flask_socketio.SocketIO.emit
    latest, lock = {}, threading.Lock()
    state = {"sio": None, "thread": None}

    def flusher():
        while True:
            time.sleep(interval)
            with lock:
                batch = list(latest.values())
                latest.clear()
            sio = state["sio"]
            for args, kwargs in batch:
                try:
                    original(sio, "tick", *args, **kwargs)
                except Exception:        # noqa: BLE001 - a UI hiccup must never touch the engine
                    pass

    def emit(self, event, *args, **kwargs):
        if event == "tick" and len(args) == 1 and isinstance(args[0], dict):
            with lock:
                latest[args[0].get("instrument_token")] = (args, kwargs)
                state["sio"] = self
                if state["thread"] is None:
                    t = threading.Thread(target=flusher, daemon=True, name="tick-flusher")
                    state["thread"] = t
                    t.start()
            return None
        return original(self, event, *args, **kwargs)

    flask_socketio.SocketIO.emit = emit


def _stable_device_id(app_dir):
    """Give the license module a Machine ID that stays the same on this phone.

    The protected build derives its Machine ID from the host's network-adapter number
    (uuid.getnode()) when no OS machine id exists. Android hides the real adapter number from
    apps, so Python invents a NEW random one at every start - which changes the Machine ID each
    time the app is opened. Here a random device number is generated ONCE, saved in the app's
    private storage (device_id.dat) and reused. The license check itself is not touched: the
    seller still has to issue a key for the Machine ID that is shown in the dashboard.
    The number survives app updates; it is lost only on uninstall / "Clear data"."""
    import secrets
    import uuid
    path = os.path.join(app_dir, "device_id.dat")
    value = None
    try:
        with open(path) as f:
            value = int(f.read().strip(), 16)
        if value <= 0 or value >> 48:
            value = None
    except Exception:                    # noqa: BLE001
        value = None
    if value is None:
        value = secrets.randbits(48) | (1 << 40)      # multicast bit, like Python's own random fallback
        try:
            with open(path, "w") as f:
                f.write("%012x" % value)
        except Exception:                # noqa: BLE001
            pass
    uuid.getnode = lambda: value


def start(app_dir, port=5051):
    """Blocks for as long as the dashboard server runs. Run it in a background thread."""
    _pin_ist()
    os.chdir(app_dir)
    if app_dir not in sys.path:
        sys.path.insert(0, app_dir)
    os.environ["HOST"] = "127.0.0.1"
    sys.argv = ["app.py"]
    _patch_browser()
    _stable_device_id(app_dir)
    try:
        _patch_socketio()
        _patch_tick_emit()
        import appcore                   # algo_ai/appcore.pyc (compiled, Python 3.11)
        # Own dashboard port per product (same value the PC launcher app.py sets).
        appcore.PORT = int(port)
        try:
            import fut_mode
            fut_mode.register(appcore)
        except Exception as exc:     # noqa: BLE001
            print("[fut_mode] add-on not loaded: %s" % exc)
        try:
            import profit_lock
            profit_lock.register(appcore)
        except Exception as exc:     # noqa: BLE001
            print("[profit_lock] add-on not loaded: %s" % exc)
        try:
            import profit_shield
            profit_shield.register(appcore)
        except Exception as exc:     # noqa: BLE001
            print("[profit_shield] add-on not loaded: %s" % exc)
        try:
            import journal_guard
            journal_guard.register(appcore)
        except Exception as exc:     # noqa: BLE001
            print("[journal_guard] add-on not loaded: %s" % exc)
        try:
            import ltp_watch
            ltp_watch.register(appcore)
        except Exception as exc:     # noqa: BLE001
            print("[ltp_watch] add-on not loaded: %s" % exc)
        appcore.main()
    except BaseException:                # noqa: BLE001 - SystemExit too, so the UI can show why
        traceback.print_exc()
        try:                             # the UI shows this file if the engine cannot start
            with open(os.path.join(app_dir, "android_error.txt"), "w") as f:
                f.write(traceback.format_exc())
        except Exception:                # noqa: BLE001
            pass
        raise
