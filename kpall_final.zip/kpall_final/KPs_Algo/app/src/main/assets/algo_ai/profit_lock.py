"""Profit Lock add-on: optional "book the trade at +12% of the invested amount".

Dashboard selection box (Control card + Multi-trade + Scan/Pine + Auto SL, all the same switch):

  Profit lock :  OFF (default - everything works exactly as before)  |  ON - 12% of invested amount

When it is ON, every trade is squared off automatically as soon as its profit reaches 12% of the amount
that trade uses:

  * Option BUY  (CE / PE, straddle)  -> invested = entry price x quantity (the premium paid)
  * Future / Option SELL (fut_mode)  -> invested = the margin Zerodha blocks for it (order_margins)

Where it applies (the compiled engine is not edited - the same wrapping style as fut_mode.py):

  * Normal Execute / Manual entry, Multi-trade, Scan + Pine   - engine.monitor_and_exit is the common exit
    loop of all three. compute_positions_pnl (called every tick by that loop) is wrapped: when the profit
    reaches the limit, the trade is squared off through the engine's own _square_off_one / square_off_all,
    the usual 'leg_exit' / 'exit' events are sent to the dashboard and the monitor ends cleanly.
        - Settings "P&L mode" decides what a "trade" is: COMBINED = all legs of that run together
          (a straddle's CE+PE together); otherwise each leg on its own.
  * Auto SL / Target                                          - autosl.core.step is wrapped (only inside the
    autosl module, the backtest is untouched): long options exit at entry x 1.12. Futures / sold options in
    Auto SL are checked by fut_autosl.py through check_margin_leg() below.

Expiry-day Lotto positions keep their own target (x3) and are not touched. Stop Loss, trailing, time exit,
force exit and the Stop button keep working as before - whichever comes first closes the trade.
"""
import json
import os
import threading
import time

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CFG_PATH = os.path.join(BASE_DIR, "profit_lock.json")
DEFAULT_PCT = 12.0
DEFAULT_CFG = {"enabled": False, "pct": DEFAULT_PCT}
REASON = "PROFIT_LOCK"

_CFG_LOCK = threading.Lock()
_CFG_CACHE = {"mtime": None, "path": None, "cfg": dict(DEFAULT_CFG)}
_ORIG = {}                 # original callables, filled by register()
_CTX = {}                  # id(positions list) -> {"log", "on_event", "settings", "settings_path"}
_CTX_LOCK = threading.Lock()


class ProfitLockDone(Exception):
    """Raised inside the wrapped compute_positions_pnl once every position is closed, to end the monitor."""


# ----------------------------------------------------------------------------- config
def normalize_cfg(raw):
    raw = raw if isinstance(raw, dict) else {}
    out = dict(DEFAULT_CFG)
    out["enabled"] = bool(raw.get("enabled", False))
    try:
        pct = float(raw.get("pct", DEFAULT_PCT))
        if 0 < pct <= 500:
            out["pct"] = round(pct, 2)
    except (TypeError, ValueError):
        pass
    return out


def load_cfg(path=None):
    """Cheap enough to call every tick: the file is re-read only when its modification time changes."""
    path = path or CFG_PATH
    try:
        mtime = os.path.getmtime(path)
    except OSError:
        return dict(DEFAULT_CFG)
    with _CFG_LOCK:
        if _CFG_CACHE["path"] == path and _CFG_CACHE["mtime"] == mtime:
            return dict(_CFG_CACHE["cfg"])
        try:
            with open(path, "r", encoding="utf-8") as fh:
                cfg = normalize_cfg(json.load(fh))
        except (OSError, ValueError):
            cfg = dict(DEFAULT_CFG)
        _CFG_CACHE.update(path=path, mtime=mtime, cfg=cfg)
        return dict(cfg)


def save_cfg(cfg, path=None):
    path = path or CFG_PATH
    cfg = normalize_cfg(cfg)
    with _CFG_LOCK:
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(cfg, fh, indent=2)
        os.replace(tmp, path)
        _CFG_CACHE["mtime"] = None      # force a re-read next time
    return cfg


def is_active():
    return bool(load_cfg()["enabled"])


# ----------------------------------------------------------------------------- maths
def is_mine(p):
    """Legs created by fut_mode.py (futures / sold options) carry kind = FUT / OPT."""
    return isinstance(p, dict) and p.get("kind") in ("FUT", "OPT")


def is_long_option(p):
    """The original engine's legs (no 'kind') and fut_mode's bought options are plain long premium."""
    return isinstance(p, dict) and not is_mine(p)


def target_amount(invested, pct):
    return round(float(invested) * float(pct) / 100.0, 2)


def reached(pnl, invested, pct):
    """True when pnl >= pct% of invested. Never true for a missing / non-positive invested amount."""
    try:
        invested, pnl = float(invested), float(pnl)
    except (TypeError, ValueError):
        return False
    if invested <= 0:
        return False
    return pnl >= target_amount(invested, pct) - 1e-9


def margin_of(kite_client, leg, log=None):
    """Margin Zerodha needs for this leg (cached on the leg). None when it cannot be read."""
    cached = leg.get("_pl_margin")
    if cached:
        return cached
    if time.time() - leg.get("_pl_margin_try", 0) < 30:      # do not hammer the API after a failure
        return None
    leg["_pl_margin_try"] = time.time()
    try:
        res = kite_client.kite.order_margins([{
            "exchange": leg["exchange"], "tradingsymbol": leg["tradingsymbol"],
            "transaction_type": leg["side"], "variety": "regular", "product": "MIS",
            "order_type": "MARKET", "quantity": leg["qty"]}])
        total = float(res[0].get("total"))
        if total > 0:
            leg["_pl_margin"] = total
            return total
    except Exception as exc:
        if log and not leg.get("_pl_margin_warned"):
            leg["_pl_margin_warned"] = True
            log("[profit-lock] could not read the margin of %s (%s) - profit lock skipped for this leg"
                % (leg.get("tradingsymbol"), exc))
    return None


def invested_of(kite_client, leg, log=None):
    """Amount this leg uses: premium paid for a bought option, blocked margin for a future / sold option."""
    if is_long_option(leg):
        try:
            amount = float(leg.get("entry_price")) * int(leg.get("qty"))
        except (TypeError, ValueError):
            return None
        return amount if amount > 0 else None
    return margin_of(kite_client, leg, log)


def check_margin_leg(kite_client, leg, log=None):
    """For fut_autosl.py: True when this future / sold-option leg has reached the profit limit."""
    cfg = load_cfg()
    if not cfg["enabled"]:
        return False
    inv = invested_of(kite_client, leg, log)
    return reached(leg.get("pnl"), inv, cfg["pct"])


# ----------------------------------------------------------------------------- engine wrappers
def _live_pnl_mode(ctx):
    """'COMBINED' (the Settings default) or anything else = per leg. Re-reads settings.json when it changes."""
    mode = (ctx.get("settings") or {}).get("pnl_mode", "COMBINED")
    path = ctx.get("settings_path")
    if path:
        try:
            with open(path, "r", encoding="utf-8") as fh:
                mode = json.load(fh).get("pnl_mode", mode)
        except (OSError, ValueError):
            pass
    return str(mode or "COMBINED").upper()


def _emit(on_event, payload):
    try:
        _ORIG["engine"]._emit(on_event, payload)
    except Exception:
        pass


def _snapshot(positions):
    try:
        return _ORIG["engine"]._positions_snapshot(positions)
    except Exception:
        return []


def evaluate_positions(kite_client, positions, ctx, cfg):
    """Look at the (already priced) positions. Returns ('ALL', None) / ('LEGS', [legs]) / None."""
    live = [p for p in positions if not p.get("lotto")]
    if not live:
        return None
    log = ctx.get("log") or print
    if _live_pnl_mode(ctx) == "COMBINED":
        # one trade = everything this run holds; every leg must be measurable, else we cannot say
        total_inv, total_pnl = 0.0, 0.0
        for p in positions:
            if p.get("lotto"):
                return None          # a lotto leg in the mix: leave the whole run to the normal logic
            inv = invested_of(kite_client, p, log)
            if inv is None:
                return None
            total_inv += inv
            total_pnl += float(p.get("pnl") or 0.0)
        if reached(total_pnl, total_inv, cfg["pct"]):
            return "ALL", (total_pnl, total_inv)
        return None
    hits = []
    for p in live:
        inv = invested_of(kite_client, p, log)
        if inv is not None and reached(p.get("pnl"), inv, cfg["pct"]):
            hits.append((p, inv))
    return ("LEGS", hits) if hits else None


def wrapped_compute_positions_pnl(kite_client, positions):
    result = _ORIG["compute_positions_pnl"](kite_client, positions)
    cfg = load_cfg()
    if not cfg["enabled"] or not positions:
        return result
    with _CTX_LOCK:
        ctx = _CTX.get(id(positions))
    if ctx is None:          # not called by the exit loop (e.g. a re-analysis) - never exit from there
        return result
    log = ctx.get("log") or print
    verdict = evaluate_positions(kite_client, positions, ctx, cfg)
    if verdict is None:
        return result
    eng = _ORIG["engine"]
    kind, data = verdict
    if kind == "ALL":
        pnl, inv = data
        log("[profit-lock] PROFIT LOCK hit: pnl Rs %.2f >= %.4g%% of invested Rs %.2f (target Rs %.2f) - squaring off"
            % (pnl, cfg["pct"], inv, target_amount(inv, cfg["pct"])))
        snapshot = _snapshot(positions)
        eng.square_off_all(kite_client, positions, log, reason=REASON)
        _emit(ctx.get("on_event"), {"type": "exit", "reason": REASON, "positions": snapshot})
        raise ProfitLockDone()
    for p, inv in data:
        log("[profit-lock] PROFIT LOCK hit on %s: pnl Rs %.2f >= %.4g%% of invested Rs %.2f (target Rs %.2f) - "
            "squaring off" % (p.get("tradingsymbol"), float(p.get("pnl") or 0.0), cfg["pct"], inv,
                              target_amount(inv, cfg["pct"])))
        eng._square_off_one(kite_client, p, log, reason=REASON)
        _emit(ctx.get("on_event"), {"type": "leg_exit", "reason": REASON,
                                    "tradingsymbol": p.get("tradingsymbol"), "pnl": p.get("pnl")})
        try:
            positions.remove(p)
        except ValueError:
            pass
    if not positions:
        raise ProfitLockDone()
    return result


def wrapped_monitor_and_exit(kite_client, positions, settings, stop_event, log, on_event, settings_path, *a, **k):
    key = id(positions)
    with _CTX_LOCK:
        _CTX[key] = {"log": log, "on_event": on_event, "settings": settings, "settings_path": settings_path}
    try:
        return _ORIG["monitor_and_exit"](kite_client, positions, settings, stop_event, log, on_event,
                                         settings_path, *a, **k)
    except ProfitLockDone:
        return None
    finally:
        with _CTX_LOCK:
            _CTX.pop(key, None)


# ----------------------------------------------------------------------------- Auto SL (long options)
class _CoreProxy(object):
    """Stands in for autosl_core inside the autosl module only. Everything is passed straight through
    except step(): long-option states exit at entry x (1 + pct/100) while Profit lock is ON."""

    def __init__(self, real):
        object.__setattr__(self, "_real", real)

    def __getattr__(self, name):
        return getattr(object.__getattribute__(self, "_real"), name)

    def step(self, state, ltp, params):
        real = object.__getattribute__(self, "_real")
        cfg = load_cfg()
        if cfg["enabled"] and not getattr(state, "pl_skip", False):
            try:
                entry, px = float(state.entry), float(ltp)
                if entry > 0 and px >= entry * (1.0 + cfg["pct"] / 100.0) - 1e-9:
                    real.step(state, ltp, params)            # keep peak / stage bookkeeping current
                    return (REASON, px)
            except (TypeError, ValueError, AttributeError):
                pass
        return real.step(state, ltp, params)


def hook_autosl():
    try:
        import autosl
    except Exception:
        return False
    if isinstance(getattr(autosl, "core", None), _CoreProxy):
        return True
    autosl.core = _CoreProxy(autosl.core)
    return True


# ----------------------------------------------------------------------------- wiring
def patch_engine(eng):
    _ORIG["engine"] = eng
    _ORIG["compute_positions_pnl"] = eng.compute_positions_pnl
    _ORIG["monitor_and_exit"] = eng.monitor_and_exit
    eng.compute_positions_pnl = wrapped_compute_positions_pnl
    eng.monitor_and_exit = wrapped_monitor_and_exit


def register(appcore):
    patch_engine(appcore.engine)
    auto = hook_autosl()

    from flask import jsonify, request

    @appcore.app.route("/api/profit_lock", methods=["GET"])
    def get_profit_lock():
        return jsonify(dict(load_cfg(), ok=True))

    @appcore.app.route("/api/profit_lock", methods=["POST"])
    def set_profit_lock():
        body = request.get_json(silent=True) or {}
        merged = dict(load_cfg())
        if "enabled" in body:
            merged["enabled"] = str(body["enabled"]).lower() in ("1", "true", "on", "yes")
        if "pct" in body:
            try:
                pct = float(body["pct"])
            except (TypeError, ValueError):
                return jsonify({"ok": False, "error": "percent must be a number"}), 400
            if not 0 < pct <= 500:
                return jsonify({"ok": False, "error": "percent must be above 0"}), 400
            merged["pct"] = pct
        try:
            saved = save_cfg(merged)
        except OSError as exc:
            return jsonify({"ok": False, "error": "could not save: %s" % exc}), 500
        print("[profit-lock] %s (%.4g%% of invested amount)" % ("ON" if saved["enabled"] else "OFF", saved["pct"]))
        return jsonify(dict(saved, ok=True))

    print("[profit-lock] add-on loaded: optional %.4g%% profit book for Execute, Multi, Scan+Pine%s"
          % (load_cfg()["pct"], ", Auto SL" if auto else ""))
