"""Trade journal safety net - every trade (Normal, Multi, Scan+Pine, Auto, option or future) must reach
"Today's trades" and "Performance", and stay saved.

What it does (the compiled engine is not edited - same wrapping style as the other add-ons):

  1. Auto SL exits that the Auto module did not journal itself are written to the trade journal
     (only when the loaded autosl has no journaling of its own, so nothing is ever written twice).
  2. Reconcile with Zerodha: every 30 s, a journal row of TODAY that is still OPEN while Zerodha already shows the
     symbol FLAT (seen on two checks in a row) is closed with Zerodha's average sell / buy price. This catches a
     trade that was closed outside the app's own exit path (Zerodha app, a fallback sell, a crash / restart).
     Only LIVE trades can be reconciled - a DRY RUN trade never reaches Zerodha.
  3. A copy of the journal is kept next to it (trade_journal.backup.json, refreshed at most once a minute while
     it changes) and restored if the main file is ever found empty or unreadable.
"""
import datetime as _dt
import json
import os
import shutil
import threading
import time

POLL_SECONDS = 30
GRACE_SECONDS = 45          # a row younger than this is left to the normal exit path
_STATE = {"thread": None, "fixed": 0, "last": None, "error": None, "seen_flat": {}, "backup_at": 0.0}
_LOCK = threading.Lock()


def _tj():
    import trade_journal
    return trade_journal


def _today():
    return _dt.datetime.now().strftime("%Y-%m-%d")


# ----------------------------------------------------------------------------- 1. Auto SL exits
def _opt_type(symbol):
    s = str(symbol or "")
    return "PE" if s.endswith("PE") else "CE"


def _already_journaled(tj, sym, exit_px, qty):
    """True when an identical exit was written a moment ago by another bridge (e.g. kp_journal) - never twice."""
    now = _dt.datetime.now()
    for t in reversed(tj.trades_for(_today())):
        if t.get("symbol") != sym or t.get("status") not in ("CLOSED", "EXIT_UNCONFIRMED"):
            continue
        try:
            when = _dt.datetime.strptime("%s %s" % (t.get("date"), t.get("exit_time")), "%Y-%m-%d %H:%M:%S")
        except (TypeError, ValueError):
            return False
        same_px = exit_px is not None and t.get("exit_price") is not None and abs(float(t["exit_price"]) - float(exit_px)) < 1e-6
        return same_px and int(t.get("qty") or 0) == int(qty or 0) and (now - when).total_seconds() < 20
    return False


def journal_auto_exit(sym, qty, entry, exit_px, reason, mode):
    tj = _tj()
    if _already_journaled(tj, sym, exit_px, qty):
        return
    pos = {"tradingsymbol": sym, "type": _opt_type(sym), "qty": int(qty or 0), "entry_price": entry}
    dry = str(mode).upper() == "DRY"
    has_open = any(t.get("symbol") == sym and t.get("status") == "OPEN" for t in tj.trades_for(_today()))
    if not has_open:
        tj.record_entry(pos, dry, "AUTO SL", False, None)
    tj.record_exit(pos, exit_px, reason, int(qty or 0), True, dry)


def hook_autosl():
    try:
        import autosl
    except Exception:
        return False
    if hasattr(autosl, "_journal") or getattr(autosl._record_closed, "_jg", False):
        return False                    # this Auto module already journals its trades
    if getattr(autosl._record_closed, "__module__", "autosl") != "autosl":
        return False                    # another bridge (kp_journal) already wraps it
    orig = autosl._record_closed

    def record_closed(sym, qty, entry, exit_px, reason, mode, *a, **k):
        res = orig(sym, qty, entry, exit_px, reason, mode, *a, **k)
        try:
            journal_auto_exit(sym, qty, entry, exit_px, reason, mode)
        except Exception as exc:
            try:
                autosl._log("[journal-guard] trade journal not updated for %s: %s" % (sym, exc))
            except Exception:
                pass
        return res

    record_closed._jg = True
    autosl._record_closed = record_closed
    return True


# ----------------------------------------------------------------------------- 2. reconcile with Zerodha
def _day_positions(kite_client):
    kite = getattr(kite_client, "kite", None)
    if kite is None:
        return None
    return {str(p.get("tradingsymbol")): p for p in ((kite.positions() or {}).get("day") or [])}


def reconcile_once(kite_client, log=print):
    """Returns how many OPEN rows were closed."""
    tj = _tj()
    rows = [t for t in tj.trades_for(_today()) if t.get("status") == "OPEN"]
    if not rows:
        _STATE["seen_flat"].clear()
        return 0
    day = _day_positions(kite_client)
    if not day:
        return 0
    fixed = 0
    now = time.time()
    for r in rows:
        sym = r.get("symbol")
        p = day.get(sym)
        if p is None or int(p.get("quantity") or 0) != 0:
            _STATE["seen_flat"].pop(sym, None)
            continue
        if _age_seconds(r) < GRACE_SECONDS:
            continue
        first = _STATE["seen_flat"].setdefault(sym, now)
        if now - first < POLL_SECONDS * 0.9:        # needs a second look, one poll later
            continue
        short = str(r.get("side") or "").upper() == "SELL"
        px = float(p.get("buy_price" if short else "sell_price") or 0)
        if px <= 0:
            continue
        qty = int(r.get("qty") or 0)
        entry = r.get("entry_price")
        pos = {"tradingsymbol": sym, "type": r.get("type"), "qty": qty, "entry_price": entry}
        tj.record_exit(pos, px, "RECONCILED_WITH_ZERODHA", qty, True, str(r.get("mode")).upper() == "DRY")
        if short and entry is not None:
            _patch_last(sym, pnl=round((float(entry) - px) * qty, 2))
        _patch_last(sym, note="closed outside the app's exit path - exit price taken from Zerodha")
        _STATE["seen_flat"].pop(sym, None)
        fixed += 1
        log("[journal-guard] %s was closed in Zerodha but still OPEN in the journal - recorded exit at %.2f" % (sym, px))
    if fixed:
        _STATE["fixed"] += fixed
    return fixed


def _age_seconds(row):
    try:
        t = _dt.datetime.strptime("%s %s" % (row.get("date"), row.get("entry_time")), "%Y-%m-%d %H:%M:%S")
        return max(0.0, (_dt.datetime.now() - t).total_seconds())
    except (TypeError, ValueError):
        return 10 ** 6


def _patch_last(symbol, **fields):
    tj = _tj()
    with tj._lock:
        trades = tj._load(tj.TRADES_PATH)
        for t in reversed(trades):
            if t.get("symbol") == symbol:
                t.update(fields)
                tj._save(tj.TRADES_PATH, trades[-tj.MAX_TRADES:])
                return True
    return False


# ----------------------------------------------------------------------------- 3. backup / restore
def backup_path():
    return os.path.join(os.path.dirname(_tj().TRADES_PATH), "trade_journal.backup.json")


def backup_or_restore(now=None):
    """Keeps a copy of a healthy journal; restores it if the main file has lost its rows."""
    tj = _tj()
    main, bak = tj.TRADES_PATH, backup_path()
    now = now or time.time()
    try:
        rows = tj._load(main)
    except Exception:
        rows = []
    if rows:
        if now - _STATE["backup_at"] >= 60:
            try:
                shutil.copyfile(main, bak + ".tmp")
                os.replace(bak + ".tmp", bak)
                _STATE["backup_at"] = now
            except OSError:
                pass
        return "backed_up"
    try:
        with open(bak, "r", encoding="utf-8") as fh:
            saved = json.load(fh)
    except (OSError, ValueError):
        return "nothing"
    if isinstance(saved, list) and saved:
        with tj._lock:
            if not tj._load(main):
                tj._save(main, saved)
        return "restored"
    return "nothing"


# ----------------------------------------------------------------------------- wiring
def _loop(appcore):
    while True:
        time.sleep(POLL_SECONDS)
        try:
            backup_or_restore()
            client = appcore.STATE.get("kite_client")
            if client is not None and appcore.STATE.get("logged_in", True):
                reconcile_once(client, _log_fn(appcore))
            _STATE["last"] = _dt.datetime.now().strftime("%H:%M:%S")
            _STATE["error"] = None
        except Exception as exc:
            _STATE["error"] = str(exc)


def _log_fn(appcore):
    try:
        import autosl
        return autosl._log
    except Exception:
        return print


def register(appcore):
    try:
        print("[journal-guard] restore check: %s" % backup_or_restore())
    except Exception as exc:
        print("[journal-guard] start check failed: %s" % exc)
    hooked = hook_autosl()
    if _STATE["thread"] is None:
        t = threading.Thread(target=_loop, args=(appcore,), daemon=True, name="journal-guard")
        _STATE["thread"] = t
        t.start()
    print("[journal-guard] loaded: Zerodha reconcile + journal backup%s" % (" + Auto SL journaling" if hooked else ""))
