import sys

# KP's Algo
BUILT_WITH = (3, 11)
if sys.version_info[:2] != BUILT_WITH:
    raise SystemExit('Python 3.11 needed')

import appcore
appcore.PORT = 5050

try:
    import fut_mode
    fut_mode.register(appcore)
except Exception as _exc:
    print("[fut_mode] add-on not loaded: %s" % _exc)

try:
    import profit_lock
    profit_lock.register(appcore)
except Exception as _exc:
    print("[profit_lock] add-on not loaded: %s" % _exc)

try:
    import ltp_watch
    ltp_watch.register(appcore)
except Exception as _exc:
    print("[ltp_watch] add-on not loaded: %s" % _exc)


if __name__ == "__main__":
    appcore.main()
