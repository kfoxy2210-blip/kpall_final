"""Instrument selector add-on: FUTURES buy/sell and OPTION buy/sell - for every segment.

Dashboard (Control card) selection boxes:

  Trade instrument :  OPTION  |  FUTURE
  Option side      :  BUY     |  SELL          (only used when instrument = OPTION)
  Futures side     :  BUY + SELL (auto) | BUY only | SELL only   (only when FUTURE)

How the analysis decision is turned into an order:

  OPTION + BUY   -> original engine, nothing changed (CALL = buy CE, PUT = buy PE, BOTH = straddle)
  FUTURE         -> CALL = BUY future, PUT = SELL future, BOTH / NO_TRADE = no order
  OPTION + SELL  -> CALL = SELL ATM PE, PUT = SELL ATM CE, BOTH / NO_TRADE = no order
                    (option WRITING: margin heavy, loss can be large - the rupee Stop Loss must be ON)

Where it applies (the analysis itself is always the original, untouched code):

  * Execute / Manual entry / Analyze        - engine.run, engine.manual_run
  * Multi-trade (3 underlyings)             - multi_engine uses engine.enter_positions + monitor_and_exit
  * Scan + Pine strategy                    - same multi-engine path
  * Pine guard                              - Pine stock SL / target / time still close the trade (option-price
                                              levels are switched off for futures / sold options)
  * Auto SL / Target                        - fut_autosl.py (own ATR-based SL / target / breakeven / trail guard)

The compiled engine is not edited. Instead the few low-level engine functions that assume "long option"
(enter_positions, compute_positions_pnl, _square_off_one, reconcile_open_positions, position_alignment)
are wrapped: legs created by this add-on carry a 'side' ('BUY'/'SELL') and are priced / closed with the
right sign; every other position goes straight to the original function. With Option + BUY selected the
wrappers just call the originals.

Exits for FUTURE / OPTION-SELL use the Settings you already have: Stop Loss (max_loss), Target, trailing
profit-lock, time exit, force exit time and the Stop button. Everything follows dry_run (simulated by
default). Orders go through KiteClient.place_market_order (MIS, MARKET).
"""
import csv
import datetime as _dt
import json
import os
import threading
import time

INSTRUMENTS = ("OPTION", "FUTURE")
OPTION_SIDES = ("BUY", "SELL")
FUTURE_SIDES = ("BOTH", "BUY", "SELL")
DEFAULT_CFG = {"instrument": "OPTION", "option_side": "BUY", "future_side": "BOTH"}

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CFG_PATH = os.path.join(BASE_DIR, "instrument_mode.json")
OPEN_PATH = os.path.join(BASE_DIR, "fut_open_position.json")
TRADES_CSV = os.path.join(BASE_DIR, "fut_trades.csv")

_CFG_LOCK = threading.Lock()
_ORIG = {}   # original engine callables / modules, filled by register()


# ----------------------------------------------------------------------------- config
def normalize_cfg(raw):
    raw = raw if isinstance(raw, dict) else {}
    out = dict(DEFAULT_CFG)
    ins = str(raw.get("instrument", "")).upper()
    if ins in INSTRUMENTS:
        out["instrument"] = ins
    side = str(raw.get("option_side", "")).upper()
    if side in OPTION_SIDES:
        out["option_side"] = side
    fside = str(raw.get("future_side", "")).upper()
    if fside in FUTURE_SIDES:
        out["future_side"] = fside
    return out


def load_cfg(path=None):
    path = path or CFG_PATH
    with _CFG_LOCK:
        try:
            with open(path, "r", encoding="utf-8") as fh:
                return normalize_cfg(json.load(fh))
        except (OSError, ValueError):
            return dict(DEFAULT_CFG)


def save_cfg(cfg, path=None):
    path = path or CFG_PATH
    cfg = normalize_cfg(cfg)
    with _CFG_LOCK:
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(cfg, fh, indent=2)
        os.replace(tmp, path)
    return cfg


def is_passthrough(cfg):
    """True = original engine handles it (Option + Buy)."""
    return cfg["instrument"] == "OPTION" and cfg["option_side"] == "BUY"


def plan_for(direction, cfg):
    """Return (kind, side, opt_type) or None when no order should be placed.

    kind: 'FUT' | 'OPT';  side: 'BUY' | 'SELL';  opt_type: 'CE' | 'PE' | None
    """
    d = str(direction or "").upper()
    if cfg["instrument"] == "FUTURE":
        if d == "CALL":
            side = "BUY"
        elif d == "PUT":
            side = "SELL"
        else:
            return None
        if cfg["future_side"] not in ("BOTH", side):
            return None
        return ("FUT", side, None)
    if cfg["instrument"] == "OPTION" and cfg["option_side"] == "SELL":
        if d == "CALL":      # bullish -> sell the PUT
            return ("OPT", "SELL", "PE")
        if d == "PUT":       # bearish -> sell the CALL
            return ("OPT", "SELL", "CE")
        return None
    return None


def pnl_of(side, entry, ltp, qty):
    if entry is None or ltp is None:
        return 0.0
    mult = 1.0 if side == "BUY" else -1.0
    return round((float(ltp) - float(entry)) * int(qty) * mult, 2)


def is_mine(p):
    """True for a position dict created by this add-on (the original engine's have no 'kind')."""
    return isinstance(p, dict) and p.get("kind") in ("FUT", "OPT")


# ----------------------------------------------------------------------------- open-position store
class OpenStore(object):
    """Today's open legs of this add-on (survives a restart so they can be watched again)."""

    def __init__(self, path):
        self.path = path
        self.lock = threading.Lock()

    def _read(self):
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if data.get("date") != _dt.date.today().isoformat():
                return []
            return list(data.get("legs") or [])
        except (OSError, ValueError):
            return []

    def _write(self, legs):
        try:
            if not legs:
                if os.path.exists(self.path):
                    os.remove(self.path)
                return
            with open(self.path, "w", encoding="utf-8") as fh:
                json.dump({"date": _dt.date.today().isoformat(), "legs": legs}, fh, indent=2, default=str)
        except OSError:
            pass

    def all(self):
        with self.lock:
            return self._read()

    def add(self, leg):
        clean = {k: v for k, v in leg.items() if not str(k).startswith("_") and k != "state"}
        with self.lock:
            legs = [l for l in self._read() if l.get("tradingsymbol") != clean.get("tradingsymbol")]
            legs.append(clean)
            self._write(legs)

    def remove(self, symbol):
        with self.lock:
            self._write([l for l in self._read() if l.get("tradingsymbol") != symbol])


ENGINE_STORE = OpenStore(OPEN_PATH)


def journal_row(leg, mode_label, reason):
    new = not os.path.exists(TRADES_CSV)
    try:
        with open(TRADES_CSV, "a", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            if new:
                w.writerow(["date", "mode", "source", "symbol", "kind", "side", "qty", "entry_time", "entry_price",
                            "exit_time", "exit_price", "exit_reason", "pnl"])
            w.writerow([_dt.date.today().isoformat(), mode_label, leg.get("source", "ENGINE"), leg["tradingsymbol"],
                        leg["kind"], leg["side"], leg["qty"], leg.get("entry_time"), leg.get("entry_price"),
                        _dt.datetime.now().strftime("%H:%M:%S"), leg.get("exit_price"), reason,
                        pnl_of(leg["side"], leg.get("entry_price"), leg.get("exit_price"), leg["qty"])])
    except OSError:
        pass
    try:
        journal_close(leg, mode_label, reason)      # also into the main journal -> Today's trades + Performance
    except Exception as exc:
        print("[fut_mode] main trade journal not updated: %s" % exc)


def _jr_type(leg):
    """Journal 'type' (CE / PE) used by Performance for the direction split: bullish legs = CE, bearish = PE."""
    t = _LABEL_TO_ENGINE_TYPE.get(leg.get("label"))
    return t or ("CE" if leg.get("side") == "BUY" else "PE")


def _patch_last_row(symbol, **fields):
    import trade_journal as tj
    with tj._lock:
        trades = tj._load(tj.TRADES_PATH)
        for t in reversed(trades):
            if t.get("symbol") == symbol:
                t.update(fields)
                tj._save(tj.TRADES_PATH, trades[-tj.MAX_TRADES:])
                return True
    return False


def journal_open(position, orig, *a, **k):
    """Main journal OPEN row for a future / sold-option leg (the original record_entry, with the CE/PE type)."""
    res = orig(dict(position, type=_jr_type(position)), *a, **k)
    _patch_last_row(position["tradingsymbol"], side=position.get("side"), kind=position.get("kind"),
                    note=str(position.get("label") or ""))
    return res


def journal_close(leg, mode_label, reason):
    """Close that row with the SIGNED P&L (the journal's own formula is long-only)."""
    import trade_journal as tj
    qty = int(leg.get("qty") or 0)
    pos = {"tradingsymbol": leg["tradingsymbol"], "type": _jr_type(leg), "qty": qty,
           "entry_price": leg.get("entry_price")}
    tj.record_exit(pos, leg.get("exit_price"), reason, qty, leg.get("confirmed") is not False, mode_label == "DRY")
    pnl = pnl_of(leg["side"], leg.get("entry_price"), leg.get("exit_price"), qty) if leg.get("exit_price") else None
    _patch_last_row(leg["tradingsymbol"], pnl=pnl, side=leg.get("side"), kind=leg.get("kind"),
                    note=str(leg.get("label") or ""))


# ----------------------------------------------------------------------------- broker helpers
def live_price(kite_client, leg):
    """Websocket tick first, REST quote as fallback (rate limited to one call per 1.5 s per leg)."""
    try:
        tick = kite_client.get_tick(leg["token"]) if leg.get("token") else None
        px = (tick or {}).get("last_price")
        if px:
            leg["_last_tick_at"] = time.time()
            return float(px)
    except Exception:
        pass
    if time.time() - leg.get("_last_rest_at", 0) < 1.5:
        return leg.get("ltp")
    leg["_last_rest_at"] = time.time()
    try:
        key = "%s:%s" % (leg["exchange"], leg["tradingsymbol"])
        q = kite_client.get_quote([key]) or {}
        px = (q.get(key) or {}).get("last_price")
        if px:
            leg["_last_tick_at"] = time.time()
            return float(px)
    except Exception:
        pass
    return leg.get("ltp")


def net_qty(kite_client, leg):
    """Signed net MIS quantity Zerodha shows for this contract. None when it cannot be read."""
    try:
        for p in (kite_client.kite.positions() or {}).get("net", []):
            if p.get("tradingsymbol") == leg["tradingsymbol"] and p.get("exchange") == leg["exchange"] \
                    and p.get("product") == "MIS":
                return int(p.get("quantity") or 0)
        return 0
    except Exception:
        return None


def is_dry(kite_client, settings=None):
    s = getattr(kite_client, "settings", None)
    if isinstance(s, dict) and "dry_run" in s:
        return bool(s.get("dry_run"))
    return bool((settings or {}).get("dry_run", True))


def margin_ok(kite_client, leg, settings, log):
    """Live only. Blocks when Zerodha says the order needs more margin than is available."""
    if is_dry(kite_client, settings):
        return True
    try:
        req = kite_client.kite.order_margins([{
            "exchange": leg["exchange"], "tradingsymbol": leg["tradingsymbol"],
            "transaction_type": leg["side"], "variety": "regular", "product": "MIS",
            "order_type": "MARKET", "quantity": leg["qty"]}])
        need = float(req[0].get("total"))
        cash = kite_client.get_available_cash()
        if cash is not None and need > float(cash):
            log("[fut_mode] ENTRY BLOCKED: margin needed Rs %s but only Rs %s available - reduce lots or add funds"
                % (format(need, ",.0f"), format(float(cash), ",.0f")))
            return False
        log("[fut_mode] margin check OK: need ~Rs %s, available Rs %s"
            % (format(need, ",.0f"), format(float(cash), ",.0f") if cash is not None else "unknown"))
    except Exception as exc:
        log("[fut_mode] WARNING: could not pre-check margin (%s) - continuing, Zerodha will reject if short" % exc)
    return True


def place_and_confirm(kite_client, leg, side, qty):
    """MARKET order + wait for the real fill. Returns (ok, avg_price, filled_qty, message)."""
    res = kite_client.place_market_order(leg["tradingsymbol"], leg["exchange"], side, qty)
    fill = kite_client.wait_for_order_fill(res, timeout=20, poll_interval=1) or {}
    if fill.get("status") != "COMPLETE":
        try:
            kite_client.cancel_order_quietly((res or {}).get("order_id"))
        except Exception:
            pass
        return False, None, int(fill.get("filled_quantity") or 0), fill.get("message") or fill.get("status")
    return True, float(fill.get("average_price") or 0) or None, int(fill.get("filled_quantity") or qty), ""


def open_leg(kite_client, leg, settings, log):
    """Place the entry order for a leg. Fills entry_price / entry_time. True when the position is open."""
    if not margin_ok(kite_client, leg, settings, log):
        return False
    ok, avg, filled, msg = place_and_confirm(kite_client, leg, leg["side"], leg["qty"])
    if not ok:
        log("[fut_mode] ENTRY FAILED for %s: %s (filled %s)" % (leg["tradingsymbol"], msg, filled))
        if filled:
            log("[fut_mode] !!! partial fill of %s - CHECK ZERODHA POSITIONS !!!" % filled)
        return False
    price = avg or leg.get("ltp") or live_price(kite_client, leg)
    leg["entry_price"] = float(price) if price else None
    leg["qty"] = filled or leg["qty"]
    leg["entry_time"] = _dt.datetime.now().strftime("%H:%M:%S")
    leg["ltp"] = leg.get("ltp") or leg["entry_price"]
    leg["pnl"] = 0.0
    log("[fut_mode] ENTERED %s %s qty=%s @ %s" % (leg["side"], leg["tradingsymbol"], leg["qty"], leg["entry_price"]))
    return leg["entry_price"] is not None


def close_leg(kite_client, leg, log, reason, settings=None):
    """Close one leg with the OPPOSITE side, after checking Zerodha really shows it open (live)."""
    qty = leg["qty"]
    close_side = "SELL" if leg["side"] == "BUY" else "BUY"
    if not is_dry(kite_client, settings):
        net = net_qty(kite_client, leg)
        if net is not None:
            if net == 0:
                log("[fut_mode] %s: Zerodha shows no open quantity - looks like it was already closed outside this "
                    "app - NOT placing %s (would open a reverse position) [reason=%s]"
                    % (leg["tradingsymbol"], close_side, reason))
                leg["exit_price"], leg["confirmed"] = leg.get("ltp"), True
                return True, "EXITED_OUTSIDE_APP"
            if (net > 0) != (leg["side"] == "BUY"):
                log("[fut_mode] !!! %s: Zerodha shows net qty %s, the OPPOSITE of this %s leg - refusing to trade, "
                    "CHECK POSITIONS MANUALLY" % (leg["tradingsymbol"], net, leg["side"]))
                return False, reason
            if abs(net) != qty:
                log("[fut_mode] %s: expected qty %s but Zerodha shows %s - squaring off the real %s"
                    % (leg["tradingsymbol"], qty, abs(net), abs(net)))
                qty = abs(net)
    for attempt in (1, 2):
        ok, avg, _filled, msg = place_and_confirm(kite_client, leg, close_side, qty)
        if ok:
            leg["exit_price"] = avg or leg.get("ltp")
            leg["confirmed"] = True
            log("[fut_mode] squared off %s qty=%s entry=%s exit=%s pnl=%s reason=%s"
                % (leg["tradingsymbol"], qty, leg["entry_price"], leg["exit_price"],
                   pnl_of(leg["side"], leg["entry_price"], leg["exit_price"], qty), reason))
            return True, reason
        log("[fut_mode] !!! %s of %s not completed (attempt %s): %s" % (close_side, leg["tradingsymbol"], attempt, msg))
    log("[fut_mode] !!!!!! COULD NOT CONFIRM EXIT of %s - CHECK ZERODHA POSITIONS AND SQUARE OFF MANUALLY !!!!!!"
        % leg["tradingsymbol"])
    leg["exit_price"], leg["confirmed"] = leg.get("ltp"), False
    return False, "EXIT_UNCONFIRMED"


# ----------------------------------------------------------------------------- leg builders
def _lots(settings):
    try:
        return max(1, int(settings.get("lots", 1) or 1))
    except (TypeError, ValueError):
        return 1


def make_leg(kind, side, instr, exchange, lots, extra=None):
    lot_size = int(instr.get("lot_size") or 0)
    if lot_size <= 0:
        raise ValueError("lot size unknown for %s" % instr.get("tradingsymbol"))
    sym = instr["tradingsymbol"]
    if kind == "FUT":
        label = "FUT " + side
    else:
        label = "%s %s" % ("PE" if sym.endswith("PE") else "CE", side)
    leg = {"token": instr.get("instrument_token"), "tradingsymbol": sym, "exchange": instr.get("exchange") or exchange,
           "type": label, "qty": lots * lot_size, "entry_price": None, "ltp": None, "pnl": 0.0, "peak_pnl": 0.0,
           "side": side, "kind": kind, "label": label, "lots": lots, "lot_size": lot_size,
           "expiry": str(instr.get("expiry"))}
    leg.update(extra or {})
    return leg


def build_future_leg(kite_client, universe, settings, side):
    name = str((universe or {}).get("name") or settings.get("index") or "NIFTY")
    dx = (universe or {}).get("deriv_exchange") or "NFO"
    instr = kite_client.get_futures_instrument(name, dx, _dt.date.today())
    return make_leg("FUT", side, instr, dx, _lots(settings), {"underlying": name})


def build_sold_option_leg(universe, settings, opt_type, live_spot=None):
    by_strike = universe["instruments_by_strike"]
    spot = live_spot if live_spot else universe.get("atm_strike")
    strike = min(sorted(by_strike), key=lambda s: abs(s - float(spot)))
    instr = by_strike[strike][opt_type]
    name = str(universe.get("name") or settings.get("index") or "NIFTY")
    return make_leg("OPT", "SELL", instr, universe.get("deriv_exchange") or "NFO", _lots(settings),
                    {"strike": strike, "underlying": name})


# ----------------------------------------------------------------------------- engine wrappers
def wrapped_enter_positions(kite_client, universe, direction, settings, log):
    eng, orig = _ORIG["engine"], _ORIG["enter_positions"]
    cfg = load_cfg()
    if is_passthrough(cfg):
        return orig(kite_client, universe, direction, settings, log)
    lm = _ORIG["license_manager"]
    try:
        lm.require_active()
    except lm.LicenseError as exc:
        log("[fut_mode] ENTRY BLOCKED: %s" % exc)
        return []
    if eng.is_lotto(settings, log):
        log("[fut_mode] Strategy = Expiry-day lotto only works with Option + Buy. Switch Strategy to Normal or the "
            "Trade instrument to Option / Buy.")
        return []
    plan = plan_for(direction, cfg)
    if plan is None:
        log("[fut_mode] NO ORDER - decision %s has no order in this mode (%s)."
            % (direction, "future, side=" + cfg["future_side"] if cfg["instrument"] == "FUTURE" else "option sell"))
        return []
    kind, side, opt_type = plan
    if kind == "OPT" and not settings.get("sl_enabled", True):
        log("[fut_mode] ENTRY BLOCKED: Option SELL needs the rupee Stop Loss ON (Settings) - a sold option has "
            "no built-in limit on loss.")
        return []
    if not settings.get("sl_enabled", True):
        log("[fut_mode] WARNING: Stop Loss is OFF in Settings - this futures trade has no rupee stop.")
    try:
        if kind == "FUT":
            leg = build_future_leg(kite_client, universe, settings, side)
        else:
            spot = None
            try:
                spot = float(eng._live_spot_for_entry(kite_client, universe))
            except Exception:
                spot = None
            leg = build_sold_option_leg(universe, settings, opt_type, spot)
    except Exception as exc:
        log("[fut_mode] ENTRY BLOCKED: could not pick the contract (%s)" % exc)
        return []
    leg["ltp"] = live_price(kite_client, leg)
    log("[fut_mode] %s decision -> %s %s (%d lot x %d = qty %d)%s"
        % (direction, side, leg["tradingsymbol"], leg["lots"], leg["lot_size"], leg["qty"],
           "  [SOLD OPTION]" if kind == "OPT" else ""))
    if not open_leg(kite_client, leg, settings, log):
        return []
    leg["source"] = "ENGINE"
    ENGINE_STORE.add(leg)
    return [leg]


def wrapped_compute_positions_pnl(kite_client, positions):
    orig = _ORIG["compute_positions_pnl"]
    for p in positions:
        if is_mine(p):
            px = live_price(kite_client, p)
            p["ltp"] = px if px else (p.get("ltp") or p.get("entry_price"))
            p["pnl"] = pnl_of(p["side"], p.get("entry_price"), p["ltp"], p["qty"])
        else:
            orig(kite_client, [p])
    return positions


def wrapped_square_off_one(kite_client, p, log, reason=None, **kw):
    orig = _ORIG["_square_off_one"]
    if not is_mine(p):
        return orig(kite_client, p, log, reason=reason, **kw)
    ok, why = close_leg(kite_client, p, log, reason)
    p["ltp"] = p.get("exit_price") or p.get("ltp")
    p["pnl"] = pnl_of(p["side"], p.get("entry_price"), p["ltp"], p["qty"])
    if ok or p.get("confirmed") is False:
        journal_row(p, "DRY" if is_dry(kite_client) else "LIVE", why)
    if ok:
        ENGINE_STORE.remove(p["tradingsymbol"])
    return None


def wrapped_reconcile(kite_client, settings, log):
    """Original reconcile finds long options; add this add-on's legs still open from today."""
    base = list(_ORIG["reconcile_open_positions"](kite_client, settings, log) or [])
    saved = ENGINE_STORE.all()
    out = []
    for leg in saved:
        if any(b.get("tradingsymbol") == leg.get("tradingsymbol") for b in base):
            continue
        if not is_dry(kite_client, settings):
            net = net_qty(kite_client, leg)
            if net is not None:
                if net == 0:
                    log("[fut_mode] saved leg %s is no longer open at Zerodha - dropping it" % leg["tradingsymbol"])
                    ENGINE_STORE.remove(leg["tradingsymbol"])
                    continue
                if (net > 0) != (leg["side"] == "BUY"):
                    log("[fut_mode] !!! saved leg %s does not match Zerodha's position (%s) - NOT resuming it, "
                        "CHECK ZERODHA" % (leg["tradingsymbol"], net))
                    continue
                leg["qty"] = abs(net)
        leg.setdefault("ltp", leg.get("entry_price"))
        leg["pnl"] = 0.0
        leg["peak_pnl"] = 0.0
        out.append(leg)
        log("[fut_mode] RECONCILED %s %s qty=%s entry=%s - recovered after restart, resuming monitoring"
            % (leg["side"], leg["tradingsymbol"], leg["qty"], leg.get("entry_price")))
    return base + out


_LABEL_TO_ENGINE_TYPE = {"FUT BUY": "CE", "FUT SELL": "PE", "PE SELL": "CE", "CE SELL": "PE"}


def wrapped_position_alignment(held_types, direction):
    """Bullish legs (long future / sold PE) count as CE, bearish ones (short future / sold CE) as PE."""
    mapped = [_LABEL_TO_ENGINE_TYPE.get(t, t) for t in list(held_types or [])]
    return _ORIG["position_alignment"](mapped, direction)


def wrapped_record_entry(position, *a, **k):
    if is_mine(position):
        try:             # OPEN row in the main journal (closed later with the signed P&L); fut_trades.csv stays too
            return journal_open(position, _ORIG["record_entry"], *a, **k)
        except Exception as exc:
            print("[fut_mode] main trade journal entry not recorded: %s" % exc)
            return None
    return _ORIG["record_entry"](position, *a, **k)


def hook_pine_guard():
    """Pine guard turns Pine stock levels into OPTION price levels (long premium logic). For futures and sold
    options those are wrong, so switch them off: the Pine STOCK stop / target / time still decide."""
    try:
        import pine_guard
    except Exception:
        return False
    orig = getattr(pine_guard, "_register_position", None)
    if orig is None:
        return False

    def register_position(positions, settings):
        result = orig(positions, settings)
        try:
            mine = {p.get("tradingsymbol") for p in (positions or []) if is_mine(p)}
            if mine:
                with pine_guard._LOCK:
                    for rec in pine_guard.G.get("slots", {}).values():
                        if rec.get("symbol") in mine:
                            rec["levels"] = None
        except Exception as exc:
            print("[fut_mode] pine-guard hook: %s" % exc)
        return result

    pine_guard._register_position = register_position
    return True


# ----------------------------------------------------------------------------- lotto times
def validate_lotto_times(start, end, force):
    """Returns (clean dict, None) or (None, error message). Same rule as the engine: start < end < force <= 15:39."""
    vals = {}
    for key, raw in (("lotto_entry_start", start), ("lotto_entry_end", end), ("lotto_force_exit_time", force)):
        t = _parse_hhmm(raw)
        if t is None:
            return None, "%s must be a time like 14:30" % key.replace("_", " ")
        vals[key] = t
    if not (vals["lotto_entry_start"] < vals["lotto_entry_end"] < vals["lotto_force_exit_time"]):
        return None, "Entry from must be before entry to, and entry to must be before force exit"
    if vals["lotto_force_exit_time"] > _dt.time(15, 39):
        return None, "Force exit must be 15:39 or earlier (F&O market closes 15:40)"
    if vals["lotto_entry_start"] < _dt.time(9, 15):
        return None, "Entry from cannot be before the 09:15 market open"
    return {k: v.strftime("%H:%M") for k, v in vals.items()}, None


def _parse_hhmm(text):
    try:
        h, m = str(text).strip().split(":")[:2]
        return _dt.time(int(h), int(m))
    except Exception:
        return None


def register_lotto_times(appcore):
    """Own small endpoint so the lotto times save on their own button, with a clear message."""
    from flask import jsonify, request

    def settings_path():
        return getattr(appcore, "SETTINGS_PATH", os.path.join(BASE_DIR, "settings.json"))

    @appcore.app.route("/api/lotto_times", methods=["GET"])
    def get_lotto_times():
        try:
            with open(settings_path(), "r", encoding="utf-8") as fh:
                s = json.load(fh)
        except (OSError, ValueError):
            s = {}
        return jsonify({"ok": True, "lotto_entry_start": s.get("lotto_entry_start", "14:30"),
                        "lotto_entry_end": s.get("lotto_entry_end", "15:05"),
                        "lotto_force_exit_time": s.get("lotto_force_exit_time", "15:35")})

    @appcore.app.route("/api/lotto_times", methods=["POST"])
    def set_lotto_times():
        body = request.get_json(silent=True) or {}
        clean, err = validate_lotto_times(body.get("lotto_entry_start"), body.get("lotto_entry_end"),
                                          body.get("lotto_force_exit_time"))
        if err:
            return jsonify({"ok": False, "error": err}), 400
        path = settings_path()
        try:
            with open(path, "r", encoding="utf-8") as fh:
                s = json.load(fh)
        except (OSError, ValueError):
            s = {}
        s.update(clean)
        tmp = path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(s, fh, indent=2)
            os.replace(tmp, path)
        except OSError as exc:
            return jsonify({"ok": False, "error": "could not write settings.json: %s" % exc}), 500
        return jsonify(dict(clean, ok=True, message="Saved: entry %s - %s, force exit %s (from the next Execute)"
                            % (clean["lotto_entry_start"], clean["lotto_entry_end"], clean["lotto_force_exit_time"])))


# ----------------------------------------------------------------------------- live LTP of the traded item
_LTP_CACHE = {"t": 0.0, "key": None, "data": None}
_LTP_LOCK = threading.Lock()


def _deriv_info(name):
    """(clean name, spot exchange, spot symbol, derivative exchange) - same map Auto SL uses."""
    try:
        import autosl
        nm, (sx, ss, dx) = autosl._underlying_info(name)
        return nm, sx, ss, dx
    except Exception:
        nm = str(name).strip().upper()
        return nm, "NSE", nm, ("BFO" if nm in ("SENSEX", "BANKEX") else "NFO")


def traded_items(client, names, cfg):
    """What each underlying is traded as right now:
    FUTURE -> the nearest future;  OPTION (buy or sell) -> the ATM CE and PE (the signal picks one)."""
    today = _dt.date.today()
    infos = [_deriv_info(n) for n in names]
    spot_keys = ["%s:%s" % (sx, ss) for _n, sx, ss, _d in infos]
    spots = client.get_quote(spot_keys) or {}
    plan, keys = [], []
    for (nm, sx, ss, dx), sk in zip(infos, spot_keys):
        spot = (spots.get(sk) or {}).get("last_price")
        entry = {"name": nm, "spot": spot, "contracts": [], "error": None}
        try:
            if cfg["instrument"] == "FUTURE":
                f = client.get_futures_instrument(nm, dx, today)
                entry["contracts"].append(("FUT", f["tradingsymbol"], f.get("exchange") or dx, f.get("expiry")))
            else:
                rows = [r for r in client.get_instruments(dx) if r.get("name") == nm
                        and r.get("instrument_type") in ("CE", "PE") and r.get("expiry") and r["expiry"] >= today]
                if not rows:
                    raise ValueError("no option contracts found")
                exp = min(r["expiry"] for r in rows)
                rows = [r for r in rows if r["expiry"] == exp]
                if spot:
                    atm = min({float(r["strike"]) for r in rows}, key=lambda k: abs(k - float(spot)))
                    for t in ("CE", "PE"):
                        r = next((x for x in rows if x["instrument_type"] == t and float(x["strike"]) == atm), None)
                        if r:
                            entry["contracts"].append((t, r["tradingsymbol"], r.get("exchange") or dx, exp))
        except Exception as exc:
            entry["error"] = str(exc)
        for c in entry["contracts"]:
            keys.append("%s:%s" % (c[2], c[1]))
        plan.append(entry)
    quotes = client.get_quote(keys) if keys else {}
    out = []
    for e in plan:
        cons = []
        for kind, sym, ex, exp in e["contracts"]:
            q = quotes.get("%s:%s" % (ex, sym)) or {}
            ohlc = q.get("ohlc") or {}
            close = ohlc.get("close")
            ltp = q.get("last_price")
            chg = round((ltp - close) / close * 100.0, 2) if ltp and close else None
            cons.append({"kind": kind, "symbol": sym, "ltp": ltp, "change_pct": chg, "expiry": str(exp)})
        out.append({"name": e["name"], "spot": e["spot"], "contracts": cons, "error": e["error"]})
    return out


def register_ltp(appcore):
    from flask import jsonify, request

    @appcore.app.route("/api/traded_ltp", methods=["GET"])
    def traded_ltp():
        names = [n.strip().upper() for n in str(request.args.get("names", "")).split(",") if n.strip()][:6]
        if not names:
            return jsonify({"ok": True, "items": []})
        client = appcore.STATE.get("kite_client")
        if not appcore.STATE.get("logged_in") or client is None:
            return jsonify({"ok": False, "error": "login first"})
        cfg = load_cfg()
        key = (tuple(names), cfg["instrument"])
        with _LTP_LOCK:     # one Kite call set per second at most, shared by all open dashboards
            if _LTP_CACHE["key"] == key and time.time() - _LTP_CACHE["t"] < 1.0:
                return jsonify(_LTP_CACHE["data"])
            try:
                data = {"ok": True, "instrument": cfg["instrument"], "option_side": cfg["option_side"],
                        "items": traded_items(client, names, cfg)}
            except Exception as exc:
                data = {"ok": False, "error": str(exc)}
            _LTP_CACHE.update(t=time.time(), key=key, data=data)
            return jsonify(data)


# ----------------------------------------------------------------------------- wiring
def patch_engine(eng, trade_journal=None):
    for name in ("enter_positions", "compute_positions_pnl", "_square_off_one", "reconcile_open_positions",
                 "position_alignment"):
        _ORIG[name] = getattr(eng, name)
    eng.enter_positions = wrapped_enter_positions
    eng.compute_positions_pnl = wrapped_compute_positions_pnl
    eng._square_off_one = wrapped_square_off_one
    eng.reconcile_open_positions = wrapped_reconcile
    eng.position_alignment = wrapped_position_alignment
    if trade_journal is not None:
        _ORIG["record_entry"] = trade_journal.record_entry
        trade_journal.record_entry = wrapped_record_entry


def register(appcore):
    eng = appcore.engine
    _ORIG["engine"] = eng
    _ORIG["license_manager"] = appcore.license_manager
    patch_engine(eng, getattr(appcore, "trade_journal", None))
    pine = hook_pine_guard()

    from flask import jsonify, request

    @appcore.app.route("/api/instrument_mode", methods=["GET"])
    def get_instrument_mode():
        return jsonify(dict(load_cfg(), ok=True))

    @appcore.app.route("/api/instrument_mode", methods=["POST"])
    def set_instrument_mode():
        with appcore.STATE_LOCK:
            running = bool(appcore.STATE.get("running"))
        if running:
            return jsonify({"ok": False, "error": "Stop the running engine first - the instrument can only be "
                                                  "changed while idle."}), 409
        body = request.get_json(silent=True) or {}
        merged = dict(load_cfg())
        for key in ("instrument", "option_side", "future_side"):
            if key in body:
                merged[key] = body[key]
        if not (str(merged["instrument"]).upper() in INSTRUMENTS
                and str(merged["option_side"]).upper() in OPTION_SIDES
                and str(merged["future_side"]).upper() in FUTURE_SIDES):
            return jsonify({"ok": False, "error": "invalid instrument / side value"}), 400
        return jsonify(dict(save_cfg(merged), ok=True))

    register_lotto_times(appcore)
    register_ltp(appcore)

    autosl_hooked = False
    try:
        import fut_autosl
        autosl_hooked = fut_autosl.register(appcore)
    except Exception as exc:
        print("[fut_mode] Auto SL hook not loaded: %s" % exc)

    print("[fut_mode] add-on loaded: Option/Future + Buy/Sell for Execute, Multi, Scan+Pine%s%s"
          % (", Pine guard" if pine else "", ", Auto SL" if autosl_hooked else ""))
