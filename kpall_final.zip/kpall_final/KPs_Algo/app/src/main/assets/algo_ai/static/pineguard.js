// Pine guard panel (Scan + Pine box). Self-contained; does not touch dashboard.js.
(function () {
  const $ = (id) => document.getElementById(id);
  if (!$("pineGuardBox")) return;
  const esc = (s) => String(s === null || s === undefined ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const num = (x) => (x === null || x === undefined || isNaN(x)) ? "-" : Number(x).toFixed(2);
  let filled = false;
  async function call(url, body) {
    const opt = body === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) };
    const r = await fetch(url, opt);
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || ("request failed: " + r.status));
    return d;
  }
  function render(s) {
    if (!filled && s.cfg) {
      filled = true;
      $("pg_enabled").checked = !!s.cfg.enabled; $("pg_premium").checked = !!s.cfg.premium_levels; $("pg_fallback").checked = !!s.cfg.fallback_sell;
    }
    const has = s.slots.length > 0;
    $("pineGuardBox").style.display = has ? "" : "none";
    if (!has) return;
    $("pgStatus").textContent = s.cfg.enabled ? "Pine guard is ON." : "Pine guard is OFF (the engine's own Pine exit still works).";
    $("pgRows").innerHTML = s.slots.map((r) => {
      const cls = r.status === "watching" ? "" : (r.status === "exiting" ? "neg" : "pos");
      return '<div class="multi-card"><div class="multi-card-head"><span class="multi-card-name">' + esc(r.slot) + " " + esc(r.direction) +
        ' <span class="small">' + esc(r.symbol) + " x" + esc(r.qty) + "</span></span>" +
        '<span class="multi-card-actions"><b class="' + cls + '">' + esc(r.status.toUpperCase()) + "</b></span></div>" +
        '<div class="multi-card-sub">Stock: entry ' + num(r.stock_entry) + " | now " + num(r.stock_ltp) + " | <b>SL " + num(r.stock_sl) + "</b> | <b>Target " + num(r.stock_target) + "</b>" +
        (r.exit_time ? " | time exit " + esc(r.exit_time) : "") + "</div>" +
        '<div class="multi-card-sub">Option: entry ' + num(r.entry) + " | now " + num(r.opt_ltp) + " | <b>SL " + num(r.opt_sl) + "</b> | <b>Target " + num(r.opt_target) +
        "</b> (delta " + num(r.delta) + ")</div>" +
        (r.reason ? '<div class="multi-card-status">' + esc(r.reason) + (r.fallback ? " - closed by the guard's fallback sell" : "") + "</div>" : "") + "</div>";
    }).join("");
    $("pgLog").textContent = (s.log || []).join("\n");
  }
  async function refresh() { try { render(await call("/api/pineguard/state")); } catch (e) { /* add-on not running: box stays hidden */ } }
  ["pg_enabled", "pg_premium", "pg_fallback"].forEach((id) => $(id).addEventListener("change", async () => {
    try {
      render(await call("/api/pineguard/config", { enabled: $("pg_enabled").checked, premium_levels: $("pg_premium").checked, fallback_sell: $("pg_fallback").checked }));
    } catch (e) { /* ignore */ }
  }));
  refresh();
  setInterval(refresh, 2000);
})();
