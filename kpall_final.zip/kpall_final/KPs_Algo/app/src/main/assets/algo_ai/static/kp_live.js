// KP's apps - live trade line (name + LTP + P&L + Exit) and auto-minimising Analysis box.
// Purely additive: it only LISTENS to the same socket events the dashboard already gets, and its Exit
// button uses the app's own existing stop / exit calls. No engine or order logic is changed here.
(function () {
  var $ = function (id) { return document.getElementById(id); };
  var topbar = document.querySelector(".topbar");

  // ------------------------------------------------------------------ helpers
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function num(v, d) { return (v === null || v === undefined || isNaN(v)) ? "—" : Number(v).toLocaleString("en-IN", { minimumFractionDigits: d, maximumFractionDigits: d }); }
  function money(v) { return (v === null || v === undefined || isNaN(v)) ? "—" : (v > 0 ? "+" : "") + num(v, 2); }
  function sum(a, f) { var t = 0, any = false; (a || []).forEach(function (x) { var v = f(x); if (v !== null && v !== undefined && !isNaN(v)) { t += v; any = true; } }); return any ? t : null; }

  // ------------------------------------------------------------------ LIVE TRADE bar
  var bar = document.createElement("div");
  bar.className = "kp-live"; bar.id = "kpLive"; bar.style.display = "none";
  bar.innerHTML = '<span class="kp-live-tag"><span class="kp-live-dot"></span>LIVE TRADE</span><span class="kp-live-chips"></span>';
  var stack = document.getElementById("kpStack");          // created by ltp_watch.js (sticky container under the top bar)
  if (stack) stack.appendChild(bar);
  else if (topbar) topbar.insertAdjacentElement("afterend", bar);
  else document.body.insertBefore(bar, document.body.firstChild);
  var chipsBox = bar.querySelector(".kp-live-chips");
  function setTop() { if (!stack) bar.style.top = (topbar ? topbar.offsetHeight : 0) + "px"; }
  setTop(); window.addEventListener("resize", setTop); setTimeout(setTop, 600);

  var items = {};    // key -> { name, ltp (number|string), pnl, exit: fn|null }
  var chips = {};    // key -> { el, nameEl, ltpEl, pnlEl, btn, lastLtp }
  var timer = null;
  function schedule() { if (!timer) timer = setTimeout(function () { timer = null; render(); }, 250); }

  function render() {
    var keys = Object.keys(items);
    Object.keys(chips).forEach(function (k) { if (!items[k]) { chips[k].el.remove(); delete chips[k]; } });
    keys.forEach(function (k) {
      var it = items[k], c = chips[k];
      if (!c) {
        var el = document.createElement("span");
        el.className = "kp-chip";
        el.innerHTML = '<b class="kp-n"></b><span class="kp-l">LTP <i></i></span><span class="kp-p">P&amp;L <i></i></span>' +
          (it.exit ? '<button type="button" class="kp-exit">Exit</button>' : "");
        chipsBox.appendChild(el);
        c = chips[k] = { el: el, nameEl: el.querySelector(".kp-n"), ltpEl: el.querySelector(".kp-l i"), pnlEl: el.querySelector(".kp-p i"), btn: el.querySelector(".kp-exit"), lastLtp: null };
        if (c.btn) c.btn.addEventListener("click", function () { var cur = items[k]; if (cur && cur.exit) cur.exit(c.btn); });
      }
      c.nameEl.textContent = it.name;
      var ltpTxt = (typeof it.ltp === "number") ? num(it.ltp, 2) : (it.ltp || "—");
      c.ltpEl.textContent = ltpTxt;
      if (typeof it.ltp === "number" && c.lastLtp !== null && it.ltp !== c.lastLtp) {
        c.ltpEl.className = it.ltp > c.lastLtp ? "up" : "down";
      }
      c.lastLtp = (typeof it.ltp === "number") ? it.ltp : null;
      c.pnlEl.textContent = money(it.pnl);
      c.pnlEl.className = it.pnl > 0 ? "pos" : (it.pnl < 0 ? "neg" : "");
      if (c.btn && c.btn.disabled && !it.exiting) { c.btn.disabled = false; c.btn.textContent = "Exit"; }
    });
    bar.style.display = keys.length ? "flex" : "none";
    setTop();
  }
  function dropPrefix(p) { Object.keys(items).forEach(function (k) { if (k.indexOf(p) === 0) delete items[k]; }); }

  // ---- Exit actions: reuse the app's own buttons / endpoints
  function exitControl(btn) {
    if (!confirm("Exit the open position(s) now?")) return;
    var s = $("stopBtn"); if (s) { s.click(); if (btn) { btn.disabled = true; btn.textContent = "Exiting..."; } }
  }
  function exitSlot(slot) {
    return function (btn) {
      var b = Array.prototype.filter.call(document.querySelectorAll(".multi-stop-btn"), function (x) { return x.dataset.slot === slot; })[0];
      if (b) { b.click(); }   // its own handler asks for confirmation
    };
  }
  function exitAsl(sym) {
    return function (btn) {
      if (!confirm("Exit " + sym + " now?")) return;
      if (btn) { btn.disabled = true; btn.textContent = "Exiting..."; }
      fetch("/api/autosl/exit", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ symbol: sym }) }).catch(function () {});
    };
  }

  // ---- Control (Normal mode) positions
  function setControl(positions, total) {
    dropPrefix("C:");
    if (!positions || !positions.length) { schedule(); return; }
    var tot = (total !== null && total !== undefined) ? total : sum(positions, function (p) { return p.pnl; });
    function label(p) { return p.tradingsymbol + (p.type ? " (" + p.type + ")" : ""); }
    if (positions.length === 1) {
      var p = positions[0];
      items["C:" + p.tradingsymbol] = { name: label(p), ltp: p.ltp, pnl: (p.pnl !== undefined && p.pnl !== null) ? p.pnl : tot, exit: exitControl };
    } else {
      positions.forEach(function (p) { items["C:" + p.tradingsymbol] = { name: label(p), ltp: p.ltp, pnl: p.pnl, exit: null }; });
      items["C:ALL"] = { name: "TOTAL", ltp: "", pnl: tot, exit: exitControl };
    }
    schedule();
  }

  // ---- Multi / Scan+Pine slots
  var slotPos = {}, slotClosed = {};
  function setSlot(slot, positions, total) {
    if (!positions || !positions.length) { delete items["S:" + slot]; schedule(); return; }
    slotPos[slot] = positions;
    var ltp = positions.length === 1 ? positions[0].ltp : positions.map(function (p) { return num(p.ltp, 2); }).join(" / ");
    var pnl = (total !== null && total !== undefined) ? total : sum(positions, function (p) { return p.pnl; });
    items["S:" + slot] = { name: slot + " · " + positions.map(function (p) { return p.tradingsymbol; }).join(" + "), ltp: ltp, pnl: pnl, exit: exitSlot(slot) };
    schedule();
  }

  // ------------------------------------------------------------------ Analysis box: one line when a trade is running
  var grid = document.querySelector(".dashboard-grid");
  var anBar = null, anTouched = false, anAuto = false;
  function setMin(min) {
    if (!anBar) return;
    grid.classList.toggle("kp-an-min", min);
    anBar.classList.toggle("min", min);
    anBar.querySelector("small").textContent = min ? "tap to show details" : "tap to minimise";
    anBar.querySelector(".chev").textContent = min ? "▸" : "▾";
    if (!min) setTimeout(function () { window.dispatchEvent(new Event("resize")); }, 60);   // let the chart re-measure
  }
  if (grid && getComputedStyle(grid).display !== "none") {
    anBar = document.createElement("button");
    anBar.type = "button"; anBar.className = "kp-anbar"; anBar.id = "kpAnBar";
    anBar.innerHTML = '<span class="ic">📊</span><b>Analysis</b><small>tap to minimise</small><span class="chev">▾</span>';
    grid.parentNode.insertBefore(anBar, grid);
    anBar.addEventListener("click", function () { anTouched = true; setMin(!grid.classList.contains("kp-an-min")); });
    ["executeBtn", "analyzeBtn"].forEach(function (id) {
      var b = $(id); if (b) b.addEventListener("click", function () { anTouched = false; anAuto = false; setMin(false); });
    });
  }
  function autoMinimise() { if (anBar && !anTouched && !anAuto) { anAuto = true; setMin(true); } }
  // fallback that does not depend on the socket: the moment the dashboard itself lists an open position, fold Analysis
  var posList = $("positionsList");
  if (posList && typeof MutationObserver === "function") {
    new MutationObserver(function () {
      if (posList.querySelector(".position-row")) autoMinimise(); else anAuto = false;
    }).observe(posList, { childList: true, subtree: true });
  }

  // after an Auto SL trade opens / closes, make Trades + Performance reload at once (they otherwise refresh every 20 s)
  var refreshT = null;
  function refreshJournalCards() {
    if (refreshT) return;
    refreshT = setTimeout(function () {
      refreshT = null;
      ["tradesDate", "perfDays"].forEach(function (id) { var e = $(id); if (e) e.dispatchEvent(new Event("change")); });
    }, 1800);
  }

  // ------------------------------------------------------------------ socket (same broadcast events dashboard.js receives)
  if (typeof io === "function") {
    var sock = io();
    sock.on("engine_event", function (evt) {
      if (!evt) return;
      switch (evt.type) {
        case "positions_entered": setControl(evt.positions, null); autoMinimise(); break;
        case "pnl_update": setControl(evt.positions, evt.total_pnl); if (evt.positions && evt.positions.length) autoMinimise(); break;
        case "leg_exit":
          if (evt.tradingsymbol) { delete items["C:" + evt.tradingsymbol]; if (!Object.keys(items).some(function (k) { return k.indexOf("C:") === 0 && k !== "C:ALL"; })) dropPrefix("C:"); schedule(); }
          break;
        case "exit": case "no_trade": case "error": case "analysis_complete": dropPrefix("C:"); anAuto = false; schedule(); break;
        default: break;
      }
    });
    sock.on("engine_status", function (d) { if (d && !d.running) { dropPrefix("C:"); schedule(); } });
    sock.on("multi_event", function (msg) {
      var slot = msg && msg.slot, evt = (msg && msg.event) || {};
      if (!slot || slot === "*") return;
      switch (evt.type) {
        case "positions_entered": slotClosed[slot] = false; setSlot(slot, evt.positions, null); break;
        case "pnl_update": if (!slotClosed[slot]) setSlot(slot, evt.positions, evt.total_pnl); break;
        case "leg_exit":
          if (slotPos[slot] && evt.tradingsymbol) {
            var left = slotPos[slot].filter(function (p) { return p.tradingsymbol !== evt.tradingsymbol; });
            slotPos[slot] = left; if (left.length) setSlot(slot, left, null); else { delete items["S:" + slot]; schedule(); }
          }
          break;
        case "exit": case "no_trade": case "analysis_complete": slotClosed[slot] = true; delete items["S:" + slot]; schedule(); break;
        case "slot_status": if (evt.status === "error" || evt.status === "stopped") { slotClosed[slot] = true; delete items["S:" + slot]; schedule(); } break;
        default: break;
      }
    });
  }

  // ------------------------------------------------------------------ Auto SL / Target positions (polled like autosl.js does)
  var aslFails = 0, aslSeen = {};
  function pollAsl() {
    fetch("/api/autosl/state").then(function (r) { return r.json().then(function (d) { return { ok: r.ok, d: d }; }); }).then(function (x) {
      if (!x.ok || (x.d && x.d.ok === false) || !x.d || !x.d.positions) { if (++aslFails >= 2) return; return; }
      aslFails = 0;
      var seen = {};
      x.d.positions.forEach(function (p) {
        if (String(p.status).indexOf("EXIT") === 0) return;
        var k = "A:" + p.symbol; seen[k] = true;
        items[k] = { name: p.symbol + (p.side ? " (" + p.side + ")" : ""), ltp: p.ltp, pnl: p.pnl, exit: exitAsl(p.symbol) };
      });
      var changed = false;
      Object.keys(items).forEach(function (k) { if (k.indexOf("A:") === 0 && !seen[k]) { delete items[k]; changed = true; } });
      Object.keys(seen).forEach(function (k) { if (!aslSeen[k]) changed = true; });
      aslSeen = seen;
      if (changed) refreshJournalCards();
      schedule();
    }).catch(function () { aslFails++; });
  }
  setInterval(function () { if (aslFails < 2) pollAsl(); }, 2000);
  setTimeout(pollAsl, 1500);
})();
