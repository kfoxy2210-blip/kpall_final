// KP's Algo AI - live LTP of the item you trade (future, or ATM CE / PE) under Control, Multi-trade and Auto SL.
(function () {
  const $ = (id) => document.getElementById(id);
  const strips = [];   // { el, names() }

  function add(host, where, namesFn, title) {
    if (!host) return;
    const el = document.createElement("div");
    el.className = "ltp-strip";
    el.innerHTML = '<span class="ltp-title">' + title + '</span><span class="ltp-body muted small">login to see live prices</span>';
    where === "after" ? host.insertAdjacentElement("afterend", el) : host.insertAdjacentElement("afterbegin", el);
    strips.push({ el, namesFn });
  }

  const fmt = (v) => (v === null || v === undefined) ? "—" : Number(v).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const prev = {};

  function chip(c, name) {
    const k = name + c.symbol, was = prev[k];
    prev[k] = c.ltp;
    const dir = (was === undefined || c.ltp === was) ? "" : (c.ltp > was ? " up" : " down");
    const ch = c.change_pct === null || c.change_pct === undefined ? "" :
      '<small class="' + (c.change_pct >= 0 ? "pos" : "neg") + '">' + (c.change_pct >= 0 ? "+" : "") + c.change_pct + "%</small>";
    return '<span class="ltp-chip k-' + c.kind + dir + '"><b>' + c.symbol + '</b><span class="ltp-px">₹' + fmt(c.ltp) + "</span>" + ch + "</span>";
  }

  async function poll() {
    const all = [...new Set(strips.flatMap((s) => s.namesFn()))].filter(Boolean);
    if (!all.length) return;
    try {
      const r = await (await fetch("/api/traded_ltp?names=" + encodeURIComponent(all.join(",")))).json();
      strips.forEach((s) => {
        const body = s.el.querySelector(".ltp-body");
        if (!r.ok) { body.className = "ltp-body muted small"; body.textContent = r.error || "no data"; return; }
        const want = s.namesFn();
        const items = r.items.filter((i) => want.includes(i.name));
        body.className = "ltp-body";
        body.innerHTML = items.map((i) => i.error
          ? '<span class="ltp-chip bad">' + i.name + ": " + i.error + "</span>"
          : '<span class="ltp-group"><span class="ltp-name">' + i.name + (i.spot ? ' <small>spot ' + fmt(i.spot) + "</small>" : "") + "</span>" +
            i.contracts.map((c) => chip(c, i.name)).join("") + "</span>").join("") || "—";
      });
    } catch (e) { /* keep the last values */ }
  }

  const val = (id) => ($(id) ? $(id).value.trim().toUpperCase() : "");
  add($("instrumentBox"), "after", () => [val("index") || "NIFTY"], "Live price - Control");
  const ms = document.querySelector("#multiDetails .multi-slots");
  add(ms, "after", () => Array.from(document.querySelectorAll("#multiDetails .multi-slot")).filter((l) => l.querySelector(".multi-on").checked)
    .map((l) => l.querySelector(".multi-name").value.trim().toUpperCase()), "Live price - Multi-trade");
  const asl = $("asl_underlying");
  add(asl && asl.closest(".multi-controls"), "after", () => [val("asl_underlying") || "NIFTY"], "Live price - Auto SL");

  setInterval(poll, 2500);
  setTimeout(poll, 1200);
})();
