"""Tests for profit_shield.py - fake engine, no network."""
import os, sys, tempfile, types, unittest
import profit_shield as ps


class T(unittest.TestCase):
    def setUp(self):
        ps.CFG_PATH = os.path.join(tempfile.mkdtemp(), "ps.json")
        self.profit = 10000.0
        ps.realised_today = lambda force=False: self.profit
        self.events, self.logs, self.calls = [], [], []
        calls = self.calls
        eng = types.SimpleNamespace(
            _emit=lambda cb, p: self.events.append(p),
            _positions_snapshot=lambda pp: [dict(p) for p in pp],
            square_off_all=lambda k, pp, log, reason=None: (calls.append(("all", reason)), pp.clear()),
            _square_off_one=lambda k, p, log, reason=None: calls.append((p["tradingsymbol"], reason)))
        ps._ORIG.update(engine=eng, compute_positions_pnl=lambda k, pp: pp)
        self.ctx = {"log": self.logs.append, "on_event": None, "settings": {"pnl_mode": "COMBINED"}}

    def tick(self, positions, mode="COMBINED"):
        self.ctx["settings"]["pnl_mode"] = mode
        ps._CTX[id(positions)] = self.ctx
        try:
            ps.wrapped_compute_positions_pnl(None, positions)
            return False
        except ps.ShieldDone:
            return True
        finally:
            ps._CTX.pop(id(positions), None)

    def leg(self, sym, pnl):
        return {"tradingsymbol": sym, "pnl": pnl}

    def test_math(self):
        self.assertEqual(ps.allowed_loss(10000, 80), 8000.0)
        self.assertIsNone(ps.allowed_loss(0, 80))
        self.assertIsNone(ps.allowed_loss(-500, 80))
        self.assertTrue(ps.breached(-8000, 8000))
        self.assertFalse(ps.breached(-7999.9, 8000))
        self.assertFalse(ps.breached(500, 8000))
        self.assertFalse(ps.breached(-9999, None))

    def test_off_by_default(self):
        self.assertFalse(ps.is_active())
        self.assertFalse(self.tick([self.leg("A", -50000)]))
        self.assertEqual(self.calls, [])

    def test_combined_cut_at_80_percent(self):
        ps.save_cfg({"enabled": True, "pct": 80})
        self.assertFalse(self.tick([self.leg("CE", -3000), self.leg("PE", -4900)]))   # -7900
        self.assertTrue(self.tick([self.leg("CE", -3000), self.leg("PE", -5000)]))    # -8000
        self.assertEqual(self.calls, [("all", ps.REASON)])
        self.assertEqual(self.events[-1]["reason"], ps.REASON)

    def test_allowance_frozen_at_start(self):
        ps.save_cfg({"enabled": True, "pct": 80})
        pos = [self.leg("A", -100)]
        self.assertFalse(self.tick(pos))           # freezes 8000
        self.profit = 100000.0                     # other trade books more profit later
        pos[0]["pnl"] = -8000
        self.assertTrue(self.tick(pos))            # still cut at the frozen 8000

    def test_no_profit_no_cut(self):
        ps.save_cfg({"enabled": True})
        self.profit = 0.0
        self.assertFalse(self.tick([self.leg("A", -99999)]))
        self.assertEqual(self.calls, [])

    def test_per_leg_mode(self):
        ps.save_cfg({"enabled": True, "pct": 50})   # allow 5000
        pos = [self.leg("CE", -5000), self.leg("PE", 200)]
        self.assertFalse(self.tick(pos, mode="PER_LEG"))
        self.assertEqual(self.calls, [("CE", ps.REASON)])
        self.assertEqual([p["tradingsymbol"] for p in pos], ["PE"])

    def test_lotto_left_alone(self):
        ps.save_cfg({"enabled": True})
        p = self.leg("L", -99999); p["lotto"] = True
        self.assertFalse(self.tick([p]))

    def test_cfg_validation(self):
        self.assertEqual(ps.normalize_cfg({"enabled": 1, "pct": 150})["pct"], 80.0)
        self.assertEqual(ps.normalize_cfg({"pct": 60})["pct"], 60.0)
        self.assertFalse(ps.normalize_cfg(None)["enabled"])

    def test_auto_proxy(self):
        ps.save_cfg({"enabled": True, "pct": 80})
        st = types.SimpleNamespace(entry=100.0)
        real = types.SimpleNamespace(step=lambda s, l, p: None)
        ps._auto_qty = lambda s: 100
        px = ps._ShieldProxy(real)
        self.assertIsNone(px.step(st, 95, {}))                    # -500
        self.assertEqual(px.step(st, 20, {}), (ps.REASON, 20.0))  # -8000
        self.assertIsNone(px.step(types.SimpleNamespace(entry=100.0, ps_skip=True), 1, {}))

    def test_fut_leg(self):
        ps.save_cfg({"enabled": True, "pct": 80})
        L = {"tradingsymbol": "NIFTYFUT", "pnl": -100}
        self.assertFalse(ps.check_leg(L))
        L["pnl"] = -8001
        self.assertTrue(ps.check_leg(L))


if __name__ == "__main__":
    unittest.main()
