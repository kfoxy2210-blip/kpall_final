// KP's Algo AI - Profit shield (OFF / ON): a new trade may lose at most N% of today's closed profit.
// One box in Control + a copy in Multi-trade, Scan + Pine and Auto SL. All edit ONE shared setting (/api/profit_shield).
(function () {
  const main = document.getElementById("profitShieldBox");
  if (!main) return;
  const boxes = [];
  let current = { enabled: false, pct: 80 };

  function html(title) {
    return (title ? '<div class="pl-title">🛡️ ' + title + ' - profit shield <span class="muted small">(same switch as Control)</span></div>' : '<div class="pl-title">🛡️ Profit shield - protect today\'s profit</div>') +
      '<label class="pl-field">Profit shield<select data-ps>' +
      '<option value="off">OFF - works as before</option>' +
      '<option value="on">ON - new trade may lose only a share of today\'s profit</option></select></label>' +
      '<label class="pl-field">Max loss (% of today\'s profit)<input type="number" data-pct min="1" max="100" step="1" value="80"></label>' +
      '<div class="pl-hint"></div><div class="ps-status"></div>';
  }
  function wire(root) {
    const sel = root.querySelector("select[data-ps]");
    const pct = root.querySelector("input[data-pct]");
    sel.addEventListener("change", () => save({ enabled: sel.value === "on" }));
    pct.addEventListener("change", () => save({ pct: parseFloat(pct.value) }));
    boxes.push({ root: root, sel: sel, pct: pct, hint: root.querySelector(".pl-hint"), st: root.querySelector(".ps-status") });
  }
  function money(v) { return "Rs " + Number(v).toLocaleString("en-IN", { maximumFractionDigits: 0 }); }
  function render(c) {
    current = c;
    boxes.forEach((b) => {
      b.sel.value = c.enabled ? "on" : "off";
      if (document.activeElement !== b.pct) b.pct.value = c.pct;
      b.root.classList.toggle("pl-on", !!c.enabled);
      b.hint.textContent = c.enabled
        ? "ON: when a new trade starts (Normal, Multi, Pine or Auto) it is squared off automatically if its loss reaches " + c.pct + "% of today's closed profit. Stop Loss / other exits still work."
        : "OFF: trades exit only by your Settings (Stop Loss, Target, Trailing, Time exit) / Auto SL - exactly as before.";
      const dp = Number(c.day_profit || 0);
      b.st.textContent = "Today's closed P&L: " + money(dp) + (dp > 0 && c.allowed_loss != null
        ? "  |  next trade may lose at most " + money(c.allowed_loss) : "  |  no profit yet - nothing to protect")
        + (c.last_hit ? "  |  last shield exit: " + c.last_hit : "");
    });
  }
  async function load() {
    try { render(await (await fetch("/api/profit_shield")).json()); }
    catch (e) { boxes.forEach((b) => { b.sel.disabled = true; b.pct.disabled = true; b.hint.textContent = "Profit shield unavailable (add-on not loaded)."; }); }
  }
  async function save(patch) {
    try {
      const r = await fetch("/api/profit_shield", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(patch) });
      const d = await r.json();
      if (!r.ok) { alert(d.error || "Could not save"); load(); return; }
      render(d);
    } catch (e) { alert("Could not save profit shield: " + e); load(); }
  }
  main.innerHTML = html("");
  wire(main);
  const names = ["Multi-trade", "Scan + Pine", "Auto SL / Target"];
  document.querySelectorAll(".multi-box").forEach((box, i) => {
    if (box.querySelector(":scope > .ps-box")) return;
    const root = document.createElement("div");
    root.className = "pl-box ps-box pl-mini";
    root.innerHTML = html(names[i] || "This section");
    const pl = box.querySelector(":scope > .pl-box");
    box.insertBefore(root, pl ? pl.nextSibling : box.firstChild);
    wire(root);
  });
  load();
  setInterval(load, 6000);
})();
