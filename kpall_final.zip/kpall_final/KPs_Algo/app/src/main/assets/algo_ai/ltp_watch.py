"""KP add-on: continuous LIVE LTP of the script(s) you selected - with or without an open trade.

The dashboard asks  GET /api/ltp_watch/state?symbols=NIFTY,BANKNIFTY  about once a second.  Asking is also what
"selects" the scripts: a script that is asked about is watched (and kept watched for a while after the last ask).

How the price is kept live (nothing of the trading engine is touched or used):
  1. This module opens its OWN Kite websocket (wss://ws.kite.trade, 'quote' mode) and subscribes the watched
     tokens.  Ticks arrive in real time, they use no REST quota, and the trading engine's own ticker is separate
     (Kite allows 3 connections per API key).
  2. When a script is newly selected, ONE REST quote gives the price immediately plus the previous close
     (for the change / % change).  REST is used again only as a slow fallback (every 2.5 s) while the websocket
     is not delivering ticks (e.g. websocket library missing / network hiccup).
  3. Needs a Zerodha login (today's access token).  Before login the strip says so, and it starts by itself the
     moment the login is done - nothing to press.
Everything is wrapped in try/except: a problem here can never affect a trade.
"""
import struct
import threading
import time
from datetime import datetime, timedelta, timezone

IST = timezone(timedelta(hours=5, minutes=30))
WS_URL = "wss://ws.kite.trade?api_key=%s&access_token=%s"
WATCH_TTL = 40.0          # keep watching this long after the last request for a script
REST_GAP = 1.3            # never call the quote API more often than this
REST_FALLBACK_EVERY = 2.5
MAX_SYMBOLS = 8

# watched name -> (exchange, tradingsymbol, is_index)
INDEX_MAP = {
    "NIFTY": ("NSE", "NIFTY 50", True),
    "BANKNIFTY": ("NSE", "NIFTY BANK", True),
    "FINNIFTY": ("NSE", "NIFTY FIN SERVICE", True),
    "MIDCPNIFTY": ("NSE", "NIFTY MID SELECT", True),
    "SENSEX": ("BSE", "SENSEX", True),
    "BANKEX": ("BSE", "BANKEX", True),
}

_S = {
    "lock": threading.RLock(),
    "watch": {},        # name -> last asked (time.time())
    "info": {},         # name -> dict(exchange, ts, is_index, token, key, ltp, close, t_update, error, source)
    "tok": {},          # token -> name
    "thread": None,
    "ws": None,         # dict(app, client_id, subscribed:set, connected_at, last_msg)
    "last_rest": 0.0,
    "last_fallback": 0.0,
    "appcore": None,
}


# ----------------------------------------------------------------------------- pure helpers (unit tested)
def clean_symbol(raw):
    s = str(raw or "").strip().upper().replace(" ", "")
    if not s or len(s) > 20 or not all(c.isalnum() or c in "&-_" for c in s):
        return None
    return s


def resolve_name(raw):
    """-> (name, exchange, tradingsymbol, is_index) or None."""
    s = clean_symbol(raw)
    if s is None:
        return None
    try:
        import underlyings                      # the app's own alias table (NIFTY50 -> NIFTY ...)
        s = underlyings.normalize_name(s).split(":")[-1] or s
    except Exception:                           # noqa: BLE001
        pass
    if s in INDEX_MAP:
        ex, ts, idx = INDEX_MAP[s]
        return s, ex, ts, idx
    return s, "NSE", s, False


def divisor(token):
    seg = token & 0xFF
    if seg == 3:            # cds
        return 10000000.0
    if seg == 6:            # bcd
        return 10000.0
    return 100.0


def parse_packets(data):
    """Kite binary frame -> [(token, ltp, close_or_None)].  1-byte frames are heartbeats."""
    out = []
    if not isinstance(data, (bytes, bytearray)) or len(data) < 4:
        return out
    try:
        n = struct.unpack_from(">H", data, 0)[0]
        pos = 2
        for _ in range(n):
            if pos + 2 > len(data):
                break
            ln = struct.unpack_from(">H", data, pos)[0]
            pos += 2
            pkt = data[pos:pos + ln]
            pos += ln
            if len(pkt) < 8:
                continue
            token = struct.unpack_from(">i", pkt, 0)[0]
            div = divisor(token)
            ltp = struct.unpack_from(">i", pkt, 4)[0] / div
            close = None
            if ln in (28, 32) and (token & 0xFF) == 9:          # index quote / full
                close = struct.unpack_from(">i", pkt, 20)[0] / div
            elif ln >= 44:                                      # equity quote / full
                close = struct.unpack_from(">i", pkt, 40)[0] / div
            out.append((token, ltp, close if close else None))
    except struct.error:
        pass
    return out


def market_session(now=None):
    """'OPEN' Mon-Fri 09:00-15:30 IST, else 'CLOSED' (holidays are not known here - tick age tells the truth)."""
    now = now or datetime.now(IST)
    if now.weekday() >= 5:
        return "CLOSED"
    mins = now.hour * 60 + now.minute
    return "OPEN" if 9 * 60 <= mins <= 15 * 60 + 30 else "CLOSED"


def item_view(name, info, now=None):
    now = now or time.time()
    if info is None:
        return {"symbol": name, "ltp": None, "status": "starting"}
    ltp, close = info.get("ltp"), info.get("close")
    age = (now - info["t_update"]) if info.get("t_update") else None
    view = {"symbol": name, "ltp": ltp, "close": close, "age": round(age, 1) if age is not None else None,
            "source": info.get("source")}
    if ltp is not None and close:
        view["change"] = round(ltp - close, 2)
        view["change_pct"] = round((ltp - close) / close * 100.0, 2)
    if info.get("error") and ltp is None:
        view["status"] = "error"
        view["error"] = info["error"]
    elif ltp is None:
        view["status"] = "starting"
    elif age is not None and age <= 4.0:
        view["status"] = "live"
    else:
        view["status"] = "closed" if market_session() == "CLOSED" else "stale"
    return view


# ----------------------------------------------------------------------------- state updates
def _set_price(name, ltp, close=None, source="ws"):
    with _S["lock"]:
        info = _S["info"].get(name)
        if info is None:
            return
        info["ltp"] = float(ltp)
        if close:
            info["close"] = float(close)
        info["t_update"] = time.time()
        info["source"] = source
        info["error"] = None


def on_ticks(ticks):
    for token, ltp, close in ticks:
        with _S["lock"]:
            name = _S["tok"].get(token)
        if name:
            _set_price(name, ltp, close, "ws")


def _quote_key(info):
    return "%s:%s" % (info["exchange"], info["ts"])


def rest_quote(client, names):
    """One REST quote call for the given names (rate limited). Fills price + previous close."""
    with _S["lock"]:
        if time.time() - _S["last_rest"] < REST_GAP:
            return False
        _S["last_rest"] = time.time()
        pairs = [(n, _S["info"][n]) for n in names if n in _S["info"]]
    if not pairs:
        return False
    try:
        q = client.get_quote([_quote_key(i) for _, i in pairs]) or {}
    except Exception as exc:                                    # noqa: BLE001
        for n, i in pairs:
            if i.get("ltp") is None:
                i["error"] = "price request failed: %s" % exc
        return False
    for n, i in pairs:
        row = q.get(_quote_key(i)) or {}
        px = row.get("last_price")
        if px:
            close = (row.get("ohlc") or {}).get("close")
            _set_price(n, px, close, "rest")
    return True


def resolve_instrument(client, name):
    r = resolve_name(name)
    if r is None:
        return None, "bad script name"
    nm, ex, ts, is_index = r
    try:
        inst = client.get_spot_instrument(ts, ex, is_index)
        token = int(inst["instrument_token"])
    except Exception as exc:                                    # noqa: BLE001
        return None, "script not found: %s" % exc
    return {"name": nm, "exchange": ex, "ts": ts, "is_index": is_index, "token": token}, None


# ----------------------------------------------------------------------------- websocket
def _ws_parts(client):
    k = getattr(client, "kite", None)
    return getattr(k, "api_key", None), getattr(k, "access_token", None)


def _ws_thread(client_id, api_key, access_token, holder):
    try:
        import websocket                                        # websocket-client
    except Exception:                                           # noqa: BLE001
        holder["failed"] = "websocket-client not installed"
        return
    backoff = 1.0
    while holder.get("run") and not holder.get("failed"):
        def on_open(ws):
            holder["connected_at"] = time.time()
            holder["subscribed"] = set()
            holder["app"] = ws
            sync_subscriptions(holder)

        def on_message(ws, message):
            holder["last_msg"] = time.time()
            if isinstance(message, (bytes, bytearray)) and len(message) > 1:
                on_ticks(parse_packets(message))

        def on_error(ws, error):
            holder["last_error"] = str(error)

        app = websocket.WebSocketApp(WS_URL % (api_key, access_token), on_open=on_open, on_message=on_message, on_error=on_error)
        try:
            app.run_forever(ping_interval=0, ping_timeout=None)
        except Exception as exc:                                # noqa: BLE001
            holder["last_error"] = str(exc)
        holder["app"] = None
        holder["connected_at"] = None
        if not holder.get("run"):
            break
        time.sleep(backoff)
        backoff = min(backoff * 2, 15.0)
        holder["reconnects"] = holder.get("reconnects", 0) + 1


def sync_subscriptions(holder):
    """Subscribe the tokens that are watched but not subscribed yet; unsubscribe expired ones."""
    app = holder.get("app")
    if app is None:
        return
    with _S["lock"]:
        want = set(_S["tok"].keys())
    have = holder.setdefault("subscribed", set())
    add, drop = sorted(want - have), sorted(have - want)
    import json
    try:
        if add:
            app.send(json.dumps({"a": "subscribe", "v": add}))
            app.send(json.dumps({"a": "mode", "v": ["quote", add]}))
            have.update(add)
        if drop:
            app.send(json.dumps({"a": "unsubscribe", "v": drop}))
            have.difference_update(drop)
    except Exception as exc:                                    # noqa: BLE001
        holder["last_error"] = "subscribe failed: %s" % exc


def ensure_ws(client):
    api_key, access_token = _ws_parts(client)
    if not api_key or not access_token:
        return None
    holder = _S["ws"]
    if holder and holder.get("client_id") == (id(client), access_token) and holder.get("run"):
        return holder
    if holder:
        holder["run"] = False
        try:
            if holder.get("app"):
                holder["app"].close()
        except Exception:                                       # noqa: BLE001
            pass
    holder = {"run": True, "client_id": (id(client), access_token), "subscribed": set(), "app": None}
    _S["ws"] = holder
    threading.Thread(target=_ws_thread, args=(id(client), api_key, access_token, holder), daemon=True, name="ltp-ws").start()
    return holder


# ----------------------------------------------------------------------------- worker
def _expire():
    now = time.time()
    with _S["lock"]:
        for n in [n for n, ts in _S["watch"].items() if now - ts > WATCH_TTL]:
            _S["watch"].pop(n, None)
            info = _S["info"].pop(n, None)
            if info and info.get("token") is not None:
                _S["tok"].pop(info["token"], None)


def tick_once(appcore):
    client = appcore.STATE.get("kite_client")
    if client is None or not appcore.STATE.get("logged_in"):
        return False
    _expire()
    with _S["lock"]:
        names = list(_S["watch"].keys())
    # 1. resolve newly watched scripts
    fresh = []
    for n in names:
        with _S["lock"]:
            info = _S["info"].get(n)
        if info is not None and info.get("token") is not None:
            continue
        if info is not None and time.time() - info.get("t_try", 0) < 15:
            continue
        inst, err = resolve_instrument(client, n)
        with _S["lock"]:
            if inst is None:
                _S["info"][n] = {"ltp": None, "close": None, "t_update": None, "error": err, "token": None, "t_try": time.time(),
                                 "exchange": "NSE", "ts": n}
                continue
            _S["info"][n] = {"ltp": None, "close": None, "t_update": None, "error": None, "token": inst["token"],
                             "exchange": inst["exchange"], "ts": inst["ts"], "source": None}
            _S["tok"][inst["token"]] = n
        fresh.append(n)
    with _S["lock"]:
        ready = [n for n in names if _S["info"].get(n, {}).get("token") is not None]
    if not ready:
        return True
    # 2. immediate first price (+ previous close) for new scripts
    need = [n for n in ready if _S["info"][n].get("ltp") is None or _S["info"][n].get("close") is None]
    if need:
        rest_quote(client, need)
    # 3. realtime ticks
    holder = ensure_ws(client)
    if holder and holder.get("app") is not None:
        sync_subscriptions(holder)
    # 4. slow REST fallback while ticks are not flowing
    flowing = bool(holder and holder.get("connected_at") and time.time() - holder.get("last_msg", 0) < 6)
    if not flowing and market_session() == "OPEN" and time.time() - _S["last_fallback"] >= REST_FALLBACK_EVERY:
        _S["last_fallback"] = time.time()
        rest_quote(client, ready)
    return True


def _worker(appcore):
    while True:
        try:
            tick_once(appcore)
        except Exception as exc:                                # noqa: BLE001
            print("[ltp_watch] worker error: %s" % exc)
        time.sleep(0.4)
        with _S["lock"]:
            if not _S["watch"] and time.time() - _S.get("last_ask", 0) > 120:
                _S["thread"] = None
                return


def ensure_worker(appcore):
    with _S["lock"]:
        t = _S["thread"]
        if t is not None and t.is_alive():
            return
        t = threading.Thread(target=_worker, args=(appcore,), daemon=True, name="ltp-worker")
        _S["thread"] = t
        t.start()


# ----------------------------------------------------------------------------- flask
def register(appcore):
    from flask import jsonify, request
    _S["appcore"] = appcore

    def state():
        raw = str(request.args.get("symbols", "")).split(",")
        names = []
        for r in raw:
            res = resolve_name(r)
            if res and res[0] not in names:
                names.append(res[0])
        names = names[:MAX_SYMBOLS]
        now = time.time()
        with _S["lock"]:
            for n in names:
                _S["watch"][n] = now
            _S["last_ask"] = now
        ensure_worker(appcore)
        logged = bool(appcore.STATE.get("logged_in")) and appcore.STATE.get("kite_client") is not None
        items = []
        with _S["lock"]:
            for n in names:
                items.append(item_view(n, _S["info"].get(n)))
        holder = _S["ws"]
        return jsonify({"ok": True, "logged_in": logged, "market": market_session(), "items": items,
                        "ws": bool(holder and holder.get("connected_at")),
                        "note": None if logged else "Login to Zerodha - prices start by themselves right after login"})

    appcore.app.add_url_rule("/api/ltp_watch/state", "ltp_watch_state", state, methods=["GET"])
    print("[ltp_watch] live LTP add-on loaded (websocket ticks + REST fallback)")
    return True
