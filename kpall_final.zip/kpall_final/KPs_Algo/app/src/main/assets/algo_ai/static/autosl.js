// Auto SL / Target panel (4th option). Self-contained; does not touch dashboard.js.
(function () {
  const $ = (id) => document.getElementById(id);
  if (!$("autoSlDetails")) return;
  const PARAM_IDS = ["asl_atr_mult", "asl_min_sl_pct", "asl_max_sl_pct", "asl_rr", "asl_be_enabled", "asl_trail_enabled"];

  function esc(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }
  function params() {
    return {
      atr_mult: parseFloat($("asl_atr_mult").value),
      min_sl_pct: parseFloat($("asl_min_sl_pct").value),
      max_sl_pct: parseFloat($("asl_max_sl_pct").value),
      rr: parseFloat($("asl_rr").value),
      be_enabled: $("asl_be_enabled").checked,
      trail_enabled: $("asl_trail_enabled").checked,
      auto_min_score: parseInt($("asl_min_score").value, 10),
      auto_instant: $("asl_instant").checked,
    };
  }
  async function call(url, body) {
    const opt = body === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) };
    const r = await fetch(url, opt);
    const d = await r.json().catch(() => ({}));
    if (!r.ok || d.ok === false) throw new Error(d.error || ("request failed: " + r.status));
    return d;
  }
  function money(x) { return (x >= 0 ? "+" : "") + Number(x).toFixed(2); }
  function cls(x) { return x > 0 ? "pos" : (x < 0 ? "neg" : ""); }

  let filled = false;
  function render(s) {
    if (!filled && s.params) {
      filled = true;
      $("asl_atr_mult").value = s.params.atr_mult; $("asl_min_sl_pct").value = s.params.min_sl_pct;
      $("asl_max_sl_pct").value = s.params.max_sl_pct; $("asl_rr").value = s.params.rr;
      if (s.params.auto_min_score) $("asl_min_score").value = String(s.params.auto_min_score);
      if (s.params.auto_instant !== undefined) $("asl_instant").checked = !!s.params.auto_instant;
      $("asl_be_enabled").checked = !!s.params.be_enabled; $("asl_trail_enabled").checked = !!s.params.trail_enabled;
    }
    $("aslStopBtn").disabled = !s.armed;
    const mode = s.live === null || s.live === undefined ? "" : (s.live ? " | LIVE orders" : " | DRY RUN (simulated)");
    $("aslStatus").textContent = s.armed
      ? ("Auto SL/Target is ON" + mode + " - " + (s.positions.length ? s.positions.length + " position(s)." : "no open position right now."))
      : ("Auto SL/Target is OFF" + mode + ". Press Execute to trade.");
    const hasAny = s.positions.length || s.closed.length;
    $("aslTotalRow").style.display = hasAny ? "" : "none";
    $("aslTotalPnl").textContent = money(s.total_pnl) + "  (open " + money(s.open_pnl) + ", closed " + money(s.closed_pnl) + ")";
    $("aslTotalPnl").className = cls(s.total_pnl);
    $("aslCards").innerHTML = s.positions.map((p) => {
      const done = String(p.status).indexOf("EXIT") === 0;
      return '<div class="multi-card"><div class="multi-card-head"><span class="multi-card-name">' + esc(p.symbol) +
        ' <span class="small">' + esc(p.side) + (p.simulated ? " (simulated)" : "") + "</span></span>" +
        '<span class="multi-card-actions"><span class="multi-card-ltp">LTP ' + p.ltp + "</span>" +
        (done ? "" : '<button class="btn btn-secondary asl-exit" data-sym="' + esc(p.symbol) + '">Exit now</button>') + "</span></div>" +
        '<div class="multi-card-sub">Qty ' + p.qty + " | Entry " + p.entry + "</div>" +
        '<div class="multi-card-sub"><b>SL ' + p.sl + "</b> | <b>Target " + p.target + "</b> | " + esc(p.stage) + "</div>" +
        '<div class="multi-card-sub">P&amp;L <b class="' + cls(p.pnl) + '">' + money(p.pnl) + "</b></div>" +
        '<div class="multi-card-status">' + esc(p.status) + " - levels from " + esc(p.levels_from) +
        (p.why ? "<br>" + esc(p.why) : "") + "</div></div>";
    }).join("");
    document.querySelectorAll(".asl-exit").forEach((b) => b.addEventListener("click", async () => {
      try { await call("/api/autosl/exit", { symbol: b.dataset.sym }); b.disabled = true; b.textContent = "Exiting..."; } catch (e) { $("aslStatus").textContent = e.message; }
    }));
    $("aslClosedBox").style.display = s.closed.length ? "" : "none";
    $("aslClosed").innerHTML = s.closed.slice().reverse().map((c) =>
      esc(c.time) + " " + esc(c.symbol) + " x" + c.qty + " in " + c.entry + " out " + c.exit + " (" + esc(c.reason) + ") " +
      '<b class="' + cls(c.pnl) + '">' + money(c.pnl) + "</b> " + esc(c.mode)).join("<br>");
    $("aslLog").textContent = (s.log || []).join("\n");
    const sc = s.scorecard, scBox = $("aslScore");
    if (sc && sc.trades) {
      scBox.style.display = "";
      scBox.textContent = "Scorecard (all closed trades, dry-run + live): " + sc.trades + " trades, " + sc.win_pct + "% won, avg win " +
        sc.avg_win + ", avg loss " + sc.avg_loss + ", net " + sc.net_pnl + " (expectancy " + sc.expectancy + " per trade). " +
        "Judge the system by net / expectancy, not by win % alone.";
    } else { scBox.style.display = "none"; }
    const an = s.analysis, box = $("aslAnalysis");
    if (an) {
      box.style.display = "";
      box.innerHTML = '<div class="multi-card"><div class="multi-card-name">Analysis - ' + esc(an.request) + " (" + esc(an.time) + ")</div>" +
        an.steps.map((x) => '<div>' + (x.ok ? "&#10003; " : "&#10007; ") + "<b>" + esc(x.label) + ":</b> " + esc(x.value) + "</div>").join("") +
        '<div style="margin-top:6px"><b>' + esc(an.result) + "</b></div></div>";
    } else { box.style.display = "none"; }
  }
  async function refresh() {
    try { render(await call("/api/autosl/state")); }
    catch (e) {
      $("aslStatus").textContent = "Auto SL/Target add-on is NOT running on the server (" + e.message +
        "). Close the black window, run run.bat again, then press Ctrl+F5 in the browser. If it still shows this, look in the black window for the line starting [autosl].";
    }
  }
  $("aslExecuteBtn").addEventListener("click", async () => {
    const name = $("asl_underlying").value.trim().toUpperCase();
    const dir = $("asl_direction").value;
    const lots = parseInt($("asl_lots").value, 10);
    if (!name) { $("aslStatus").textContent = "Type a script name first."; return; }
    if (!confirm("Execute " + dir + " on " + name + " x " + lots + " lot(s)?\n\nWith dry_run true in settings.json this is only a simulation.")) {
      $("aslStatus").textContent = "Cancelled."; return;
    }
    $("aslExecuteBtn").disabled = true;
    $("aslStatus").textContent = "Executing " + dir + " " + name + " ...";
    try {
      const r = await call("/api/autosl/enter", { underlying: name, direction: dir, lots: lots, strike_mode: $("asl_strike").value, params: params() });
      $("aslStatus").textContent = r.message;
    } catch (e) { $("aslStatus").textContent = "Not executed: " + e.message; }
    $("aslExecuteBtn").disabled = false;
    refresh();
  });
  $("aslStopBtn").addEventListener("click", async () => {
    try { render(await call("/api/autosl/disarm", {})); } catch (e) { $("aslStatus").textContent = e.message; }
  });
  refresh();
  setInterval(refresh, 2000);
})();
