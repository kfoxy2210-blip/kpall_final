// KP's Algo AI - Trade instrument selector (Option / Future, Buy / Sell).
// One selector in Control + the same selector inside Multi-trade, Scan + Pine and Auto SL.
// They all edit ONE shared setting (/api/instrument_mode, fut_mode.py), so every section always agrees.
(function () {
  const $ = (id) => document.getElementById(id);
  if (!$("ibInstrument")) return;

  const FIELDS = '<label class="ib-field">Trade instrument<select data-k="instrument">' +
    '<option value="OPTION">Option</option><option value="FUTURE">Future</option></select></label>' +
    '<label class="ib-field" data-w="option">Option side<select data-k="option_side">' +
    '<option value="BUY">Option BUY (CALL = buy CE, PUT = buy PE)</option>' +
    '<option value="SELL">Option SELL (CALL = sell PE, PUT = sell CE)</option></select></label>' +
    '<label class="ib-field" data-w="future" style="display:none">Future side<select data-k="future_side">' +
    '<option value="BOTH">Buy + Sell (CALL = BUY, PUT = SELL)</option>' +
    '<option value="BUY">Only BUY (on CALL)</option><option value="SELL">Only SELL (on PUT)</option></select></label>' +
    '<div class="ib-hint muted small"></div>';

  const panels = [];   // every selector on the page
  let current = { instrument: "OPTION", option_side: "BUY", future_side: "BOTH" };
  let locked = false;

  function describe(c) {
    if (c.instrument === "FUTURE") {
      const t = { BOTH: "CALL signal = BUY future, PUT signal = SELL future",
                  BUY: "only BUY future (on CALL signal); PUT signal = no trade",
                  SELL: "only SELL future (on PUT signal); CALL signal = no trade" }[c.future_side];
      return "FUTURE: " + t + ". BOTH / NO TRADE = no order. Lots and Settings Stop Loss / Target / Trailing / Force-exit apply.";
    }
    if (c.option_side === "SELL")
      return "OPTION SELL (writing): CALL signal = sell ATM PE, PUT signal = sell ATM CE. Margin heavy; rupee Stop Loss must be ON. BOTH / NO TRADE = no order.";
    return "OPTION BUY: original behaviour (CALL = buy CE, PUT = buy PE, BOTH = straddle).";
  }

  function wire(root) {
    const p = { root: root, sel: {}, hint: root.querySelector(".ib-hint") || root.querySelector("#ibHint") };
    root.querySelectorAll("select").forEach((s) => {
      const k = s.dataset.k || { ibInstrument: "instrument", ibOptionSide: "option_side", ibFutureSide: "future_side" }[s.id];
      if (!k) return;
      p.sel[k] = s;
      s.addEventListener("change", () => save({ [k]: s.value }));
    });
    p.optWrap = root.querySelector('[data-w="option"]') || $("ibOptionWrap");
    p.futWrap = root.querySelector('[data-w="future"]') || $("ibFutureWrap");
    panels.push(p);
    return p;
  }

  function render(c) {
    current = c;
    const warn = c.instrument === "FUTURE" || c.option_side === "SELL";
    panels.forEach((p) => {
      Object.keys(p.sel).forEach((k) => { p.sel[k].value = c[k]; p.sel[k].disabled = locked; });
      if (p.optWrap) p.optWrap.style.display = c.instrument === "OPTION" ? "" : "none";
      if (p.futWrap) p.futWrap.style.display = c.instrument === "FUTURE" ? "" : "none";
      p.root.classList.toggle("ib-warn", warn);
      if (p.hint) p.hint.textContent = describe(c);
    });
    paintLabels(c);
  }

  function paintLabels(c) {
    const dir = $("asl_direction");
    if (dir) {
      const sell = c.instrument === "OPTION" && c.option_side === "SELL";
      const txt = c.instrument === "FUTURE"
        ? { AUTO: "AUTO (trend)", CALL: "CALL (BUY future)", PUT: "PUT (SELL future)" }
        : sell ? { AUTO: "AUTO (trend)", CALL: "CALL (sell PE)", PUT: "PUT (sell CE)" }
               : { AUTO: "AUTO (trend)", CALL: "CALL (buy CE)", PUT: "PUT (buy PE)" };
      Array.from(dir.options).forEach((o) => { if (txt[o.value]) o.textContent = txt[o.value]; });
    }
    const lab = c.instrument === "FUTURE"
      ? { CALL: "Buy FUTURE", PUT: "Sell FUTURE", BOTH: "— (no future order)" }
      : c.option_side === "SELL" ? { CALL: "Sell PUT (bullish)", PUT: "Sell CALL (bearish)", BOTH: "— (no sell order)" }
                                 : { CALL: "Buy CALL", PUT: "Buy PUT", BOTH: "Buy BOTH (ATM)" };
    [["manualCallBtn", "CALL"], ["manualPutBtn", "PUT"], ["manualBothBtn", "BOTH"]].forEach(([id, d]) => {
      const b = $(id); if (b) b.textContent = lab[d];
    });
    const strike = $("asl_strike");
    if (strike && strike.parentElement) strike.parentElement.style.display = c.instrument === "FUTURE" ? "none" : "";
    const pick = $("optionPickCard");
    if (pick) pick.dataset.fut = (c.instrument === "FUTURE" || c.option_side === "SELL") ? "1" : "";
  }

  async function load() {
    try { render(await (await fetch("/api/instrument_mode")).json()); }
    catch (e) {
      panels.forEach((p) => { p.root.querySelectorAll("select").forEach((s) => (s.disabled = true)); });
      if (panels[0] && panels[0].hint) panels[0].hint.textContent = "Instrument selector unavailable (add-on not loaded).";
    }
  }

  async function save(change) {
    const want = Object.assign({}, current, change);
    if ((want.instrument === "FUTURE" || want.option_side === "SELL") && !window.__ibWarned &&
        (want.instrument !== current.instrument || want.option_side !== current.option_side)) {
      const mode = want.instrument === "FUTURE" ? "FUTURES" : "OPTION SELLING";
      if (!confirm(mode + " can lose much more than a bought option. Rupee Stop Loss is used, but check your Lots and Max Loss first. Continue?")) { load(); return; }
      window.__ibWarned = true;
    }
    try {
      const r = await fetch("/api/instrument_mode", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(want) });
      const d = await r.json();
      if (!r.ok) { alert(d.error || "Could not save"); load(); return; }
      render(d);
    } catch (e) { alert("Could not save instrument: " + e); load(); }
  }

  // 1) the Control-card selector (already in the page)
  wire($("instrumentBox"));
  // 2) a copy inside every segment box (Multi-trade, Scan + Pine, Auto SL)
  const names = ["Multi-trade", "Scan + Pine", "Auto SL / Target"];
  document.querySelectorAll(".multi-box").forEach((box, i) => {
    if (box.querySelector(":scope > .instrument-box")) return;
    const root = document.createElement("div");
    root.className = "instrument-box ib-mini";
    root.innerHTML = '<div class="ib-title">⚡ ' + (names[i] || "This section") + ' - trade instrument <span class="muted small">(same switch as Control)</span></div>' + FIELDS;
    box.insertBefore(root, box.firstChild);
    wire(root);
  });

  // lock all selectors while the engine runs (the server refuses changes then anyway)
  const stopBtn = $("stopBtn");
  if (stopBtn) new MutationObserver(() => {
    locked = !stopBtn.disabled;
    panels.forEach((p) => p.root.querySelectorAll("select").forEach((s) => (s.disabled = locked)));
  }).observe(stopBtn, { attributes: true, attributeFilter: ["disabled"] });

  load();

  // ---- lotto times: own Save button (clear message, no dependency on the big Settings form)
  const lb = $("lottoTimesSave");
  if (lb) {
    const msg = $("lottoTimesMsg");
    lb.addEventListener("click", async () => {
      msg.style.color = ""; msg.textContent = "Saving...";
      try {
        const r = await fetch("/api/lotto_times", { method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ lotto_entry_start: $("lotto_entry_start").value, lotto_entry_end: $("lotto_entry_end").value,
                                 lotto_force_exit_time: $("lotto_force_exit_time").value }) });
        const d = await r.json();
        msg.style.color = r.ok ? "#059669" : "#E11D48";
        msg.textContent = (r.ok ? "✔ " : "✖ NOT saved: ") + (d.message || d.error || "");
      } catch (e) { msg.style.color = "#E11D48"; msg.textContent = "✖ NOT saved: " + e; }
    });
  }
})();
