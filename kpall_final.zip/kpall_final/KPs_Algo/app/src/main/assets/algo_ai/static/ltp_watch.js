// KP's apps - LIVE LTP strip. Shows the live price of the script(s) you selected, continuously, from the moment the
// app opens - with or without an open trade. Purely a viewer: it only READS /api/ltp_watch/state and your inputs.
(function () {
  var product = document.body.getAttribute("data-product");
  var topbar = document.querySelector(".topbar");
  if (!product || !topbar) return;
  var $ = function (id) { return document.getElementById(id); };
  var LS = "kp_ltp_pinned_" + product;

  // ---- sticky stack under the top bar (kp_live.js puts the LIVE TRADE line into the same stack)
  var stack = document.createElement("div");
  stack.id = "kpStack";
  topbar.insertAdjacentElement("afterend", stack);
  var strip = document.createElement("div");
  strip.id = "kpLtp"; strip.className = "kp-ltp";
  strip.innerHTML = '<span class="kp-ltp-tag"><span class="kp-ltp-dot"></span><span class="kp-ltp-tagtxt">LIVE</span></span>' +
    '<span class="kp-ltp-chips"></span><button type="button" class="kp-ltp-add" title="Add a script to watch">+</button>';
  stack.appendChild(strip);
  var chipsBox = strip.querySelector(".kp-ltp-chips");
  var dot = strip.querySelector(".kp-ltp-dot");
  var tagTxt = strip.querySelector(".kp-ltp-tagtxt");
  function setTop() { stack.style.top = topbar.offsetHeight + "px"; }
  setTop(); window.addEventListener("resize", setTop); setTimeout(setTop, 500);

  // ---- which scripts to watch: the ones selected in this app + the ones you pinned with "+"
  function clean(s) {
    s = String(s || "").trim().toUpperCase().replace(/\s+/g, "");
    return /^[A-Z0-9&\-_]{1,20}$/.test(s) ? s : "";
  }
  function pinned() { try { return JSON.parse(localStorage.getItem(LS) || "[]").filter(clean).slice(0, 3); } catch (e) { return []; } }
  function savePinned(a) { try { localStorage.setItem(LS, JSON.stringify(a.slice(0, 3))); } catch (e) {} }
  function val(id) { var e = $(id); return e ? clean(e.value) : ""; }
  function selected() {
    var out = [];
    if (product === "algo") out.push(val("index"));
    else if (product === "auto") out.push(val("asl_underlying"));
    else if (product === "multi") document.querySelectorAll(".multi-name").forEach(function (e) { out.push(clean(e.value)); });
    else if (product === "pine") { ["scanOwn1", "scanOwn2", "scanOwn3"].forEach(function (i) { out.push(val(i)); }); }
    else { out.push(val("index")); out.push(val("asl_underlying")); }
    out = out.filter(Boolean);
    if (!out.length) out = [val("index") || "NIFTY"];
    return out;
  }
  function names() {
    var all = selected(), pins = pinned(), seen = {}, res = [];
    all.concat(pins).forEach(function (n) { if (n && !seen[n]) { seen[n] = 1; res.push(n); } });
    return res.slice(0, 7);
  }

  // ---- chips (updated in place - no flicker, no lost taps)
  var chips = {};
  function fmt(v) { return (v === null || v === undefined || isNaN(v)) ? "—" : Number(v).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  function build(list) {
    Object.keys(chips).forEach(function (n) { if (list.indexOf(n) < 0) { chips[n].el.remove(); delete chips[n]; } });
    list.forEach(function (n) {
      if (chips[n]) return;
      var el = document.createElement("span");
      el.className = "kp-lchip";
      el.innerHTML = '<b class="n"></b><span class="p">—</span><span class="c"></span><i class="x" title="Remove">×</i>';
      el.querySelector(".n").textContent = n;
      el.querySelector(".x").addEventListener("click", function (ev) {
        ev.stopPropagation();
        savePinned(pinned().filter(function (p) { return p !== n; })); refresh();
      });
      chipsBox.appendChild(el);
      chips[n] = { el: el, p: el.querySelector(".p"), c: el.querySelector(".c"), x: el.querySelector(".x"), last: null };
    });
    var pins = pinned();
    list.forEach(function (n) { chips[n].x.style.display = pins.indexOf(n) >= 0 ? "" : "none"; });
  }
  var msg = document.createElement("span");
  msg.className = "kp-ltp-msg"; msg.style.display = "none"; strip.insertBefore(msg, strip.querySelector(".kp-ltp-add"));

  function paint(data) {
    var items = (data && data.items) || [];
    var by = {};
    items.forEach(function (i) { by[i.symbol] = i; });
    var live = false, anyPrice = false;
    Object.keys(chips).forEach(function (n) {
      var c = chips[n], it = by[n];
      if (!it || it.ltp === null || it.ltp === undefined) {
        c.p.textContent = it && it.status === "error" ? "?" : "…";
        c.c.textContent = it && it.error ? "script not found" : "";
        c.c.className = "c";
        c.el.className = "kp-lchip" + (it && it.status === "error" ? " err" : "");
        return;
      }
      anyPrice = true;
      c.p.textContent = fmt(it.ltp);
      var cls = "kp-lchip " + (it.status || "");
      if (c.last !== null && it.ltp !== c.last) cls += it.ltp > c.last ? " up" : " down";
      c.last = it.ltp;
      c.el.className = cls;
      if (it.change_pct !== undefined) {
        c.c.textContent = (it.change >= 0 ? "▲ " : "▼ ") + Math.abs(it.change_pct).toFixed(2) + "%";
        c.c.className = "c " + (it.change >= 0 ? "pos" : "neg");
        c.el.title = it.symbol + "  " + fmt(it.ltp) + "   change " + (it.change >= 0 ? "+" : "") + fmt(it.change);
      }
      if (it.status === "live") live = true;
    });
    if (data && data.logged_in === false) {
      msg.textContent = "Login to Zerodha - live prices start by themselves"; msg.style.display = "";
    } else { msg.style.display = "none"; }
    dot.className = "kp-ltp-dot" + (live ? " on" : (anyPrice ? " idle" : ""));
    tagTxt.textContent = live ? "LIVE" : (data && data.market === "CLOSED" && anyPrice ? "CLOSED" : (anyPrice ? "WAIT" : "LIVE"));
  }

  // ---- polling (continuous, from page load; slower only while the app is in the background)
  var busy = false, current = names();
  function refresh() { current = names(); build(current); poll(); }
  function poll() {
    if (busy) return;
    busy = true;
    var ctl = (typeof AbortController === "function") ? new AbortController() : null;
    var t = setTimeout(function () { if (ctl) ctl.abort(); }, 4000);
    fetch("/api/ltp_watch/state?symbols=" + encodeURIComponent(current.join(",")), { cache: "no-store", signal: ctl ? ctl.signal : undefined })
      .then(function (r) { return r.json(); })
      .then(paint)
      .catch(function () { dot.className = "kp-ltp-dot"; })
      .then(function () { clearTimeout(t); busy = false; });
  }
  build(current);
  setInterval(function () {
    var n = names();
    if (n.join(",") !== current.join(",")) { current = n; build(current); }
    if (!document.hidden) poll();
  }, 1000);
  setInterval(function () { if (document.hidden) poll(); }, 6000);
  poll();

  // ---- add a script
  strip.querySelector(".kp-ltp-add").addEventListener("click", function () {
    var s = clean(prompt("Script to watch (NIFTY, BANKNIFTY, SENSEX, FINNIFTY or any F&O stock like RELIANCE):", ""));
    if (!s) return;
    var p = pinned();
    if (p.indexOf(s) < 0) { p.unshift(s); savePinned(p); }
    refresh();
  });
})();
