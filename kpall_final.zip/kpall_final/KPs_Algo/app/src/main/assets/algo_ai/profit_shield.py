"""Profit Shield add-on: "protect the day's profit from the next trade".

Dashboard box (Control card + Multi-trade + Scan/Pine + Auto SL, all the same switch, manual ON / OFF):

  Profit shield : OFF (default - everything works as before)  |  ON - a new trade may lose at most 80% of today's profit

Example: today's closed trades are +Rs 10,000. You start a new trade (Normal, Multi, Scan+Pine or Auto, option or
future). Its loss limit is frozen at the moment it starts: 80% x 10,000 = Rs 8,000. If that trade's loss reaches
Rs 8,000 it is squared off automatically, so at least Rs 2,000 of the day's profit stays with you.

  * "Today's profit" = realised P&L of today's CLOSED trades (the dashboard trade journal).
    If it is zero or negative the shield has nothing to protect and does not interfere.
  * The limit is frozen when the trade starts (first price tick after it is running), so it does not move while the
    trade is open.
  * It works next to everything else: Stop Loss, Profit lock, trailing, time exit and the Stop button all keep
    working - whichever comes first closes the trade. The shield only ever closes a trade earlier, never opens one.
  * Settings "P&L mode" decides what a trade is: COMBINED = all legs of that run together (straddle CE+PE);
    otherwise each leg on its own. Expiry-day Lotto legs are left alone (they have their own rules).

The compiled engine is not edited - same wrapping style as profit_lock.py. Load order: after profit_lock.
"""
import datetime as _dt
import json
import os
import threading
import time

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CFG_PATH = os.path.join(BASE_DIR, "profit_shield.json")
DEFAULT_PCT = 80.0
DEFAULT_CFG = {"enabled": False, "pct": DEFAULT_PCT}
REASON = "PROFIT_SHIELD"

_CFG_LOCK = threading.Lock()
_CFG_CACHE = {"mtime": None, "path": None, "cfg": dict(DEFAULT_CFG)}
_ORIG = {}
_CTX = {}
_CTX_LOCK = threading.Lock()
_PROFIT_CACHE = {"t": 0.0, "v": 0.0}
_LAST = {"profit": 0.0, "allow": None, "hit": None}     # for the dashboard status line


class ShieldDone(Exception):
    """Raised inside the wrapped compute_positions_pnl once every position is closed, to end the monitor."""


# ----------------------------------------------------------------------------- config
def normalize_cfg(raw):
    raw = raw if isinstance(raw, dict) else {}
    out = dict(DEFAULT_CFG)
    out["enabled"] = bool(raw.get("enabled", False))
    try:
        pct = float(raw.get("pct", DEFAULT_PCT))
        if 0 < pct <= 100:
            out["pct"] = round(pct, 2)
    except (TypeError, ValueError):
        pass
    return out


def load_cfg(path=None):
    path = path or CFG_PATH
    try:
        mtime = os.path.getmtime(path)
    except OSError:
        return dict(DEFAULT_CFG)
    with _CFG_LOCK:
        if _CFG_CACHE["path"] == path and _CFG_CACHE["mtime"] == mtime:
            return dict(_CFG_CACHE["cfg"])
        try:
            with open(path, "r", encoding="utf-8") as fh:
                cfg = normalize_cfg(json.load(fh))
        except (OSError, ValueError):
            cfg = dict(DEFAULT_CFG)
        _CFG_CACHE.update(path=path, mtime=mtime, cfg=cfg)
        return dict(cfg)


def save_cfg(cfg, path=None):
    path = path or CFG_PATH
    cfg = normalize_cfg(cfg)
    with _CFG_LOCK:
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(cfg, fh, indent=2)
        os.replace(tmp, path)
        _CFG_CACHE["mtime"] = None
    return cfg


def is_active():
    return bool(load_cfg()["enabled"])


# ----------------------------------------------------------------------------- maths
def allowed_loss(day_profit, pct):
    """Rupees the next trade may lose. None = nothing to protect (no profit today)."""
    try:
        day_profit = float(day_profit)
    except (TypeError, ValueError):
        return None
    if day_profit <= 0:
        return None
    return round(day_profit * float(pct) / 100.0, 2)


def breached(pnl, allow):
    """True when the trade's P&L is a loss of at least `allow` rupees."""
    if allow is None or allow <= 0:
        return False
    try:
        return float(pnl) <= -float(allow) + 1e-9
    except (TypeError, ValueError):
        return False


def realised_today(force=False):
    """Sum of today's closed P&L from the trade journal (every mode writes there - see journal_guard.py)."""
    now = time.time()
    if not force and now - _PROFIT_CACHE["t"] < 1.5:
        return _PROFIT_CACHE["v"]
    today = _dt.datetime.now().strftime("%Y-%m-%d")
    total = 0.0
    try:
        import trade_journal
        for t in trade_journal.trades_for(today) or []:
            if t.get("status") == "CLOSED":
                try:
                    total += float(t.get("pnl") or 0.0)
                except (TypeError, ValueError):
                    pass
    except Exception:
        pass
    _PROFIT_CACHE.update(t=now, v=round(total, 2))
    return _PROFIT_CACHE["v"]


def freeze_allowance(cfg):
    """Called once per trade. Returns the frozen rupee loss limit (or None)."""
    profit = realised_today(force=True)
    allow = allowed_loss(profit, cfg["pct"])
    _LAST.update(profit=profit, allow=allow)
    return allow


def check_leg(leg, log=None):
    """For fut_autosl.py: True when this future / sold-option leg lost its share of today's profit."""
    cfg = load_cfg()
    if not cfg["enabled"]:
        return False
    if "_ps_allow" not in leg:
        leg["_ps_allow"] = freeze_allowance(cfg)
        if log and leg["_ps_allow"] is not None:
            log("[profit-shield] %s: today's profit protected - this trade may lose at most Rs %.2f"
                % (leg.get("tradingsymbol"), leg["_ps_allow"]))
    if breached(leg.get("pnl"), leg["_ps_allow"]):
        _LAST["hit"] = leg.get("tradingsymbol")
        return True
    return False


# ----------------------------------------------------------------------------- engine wrappers
def _live_pnl_mode(ctx):
    mode = (ctx.get("settings") or {}).get("pnl_mode", "COMBINED")
    path = ctx.get("settings_path")
    if path:
        try:
            with open(path, "r", encoding="utf-8") as fh:
                mode = json.load(fh).get("pnl_mode", mode)
        except (OSError, ValueError):
            pass
    return str(mode or "COMBINED").upper()


def _emit(on_event, payload):
    try:
        _ORIG["engine"]._emit(on_event, payload)
    except Exception:
        pass


def _snapshot(positions):
    try:
        return _ORIG["engine"]._positions_snapshot(positions)
    except Exception:
        return []


def evaluate_positions(positions, ctx, cfg):
    """Returns ('ALL', (pnl, allow)) / ('LEGS', [(leg, allow)]) / None."""
    live = [p for p in positions if not p.get("lotto")]
    if not live:
        return None
    if "allow" not in ctx:
        ctx["allow"] = freeze_allowance(cfg)
        log = ctx.get("log") or print
        if ctx["allow"] is not None:
            log("[profit-shield] today's closed profit Rs %.2f -> this trade may lose at most Rs %.2f (%.4g%%)"
                % (_LAST["profit"], ctx["allow"], cfg["pct"]))
    allow = ctx["allow"]
    if allow is None:
        return None
    if _live_pnl_mode(ctx) == "COMBINED":
        for p in positions:
            if p.get("lotto"):
                return None
        total = sum(float(p.get("pnl") or 0.0) for p in positions)
        if breached(total, allow):
            return "ALL", (total, allow)
        return None
    hits = [(p, allow) for p in live if breached(p.get("pnl"), allow)]
    return ("LEGS", hits) if hits else None


def wrapped_compute_positions_pnl(kite_client, positions):
    result = _ORIG["compute_positions_pnl"](kite_client, positions)
    cfg = load_cfg()
    if not cfg["enabled"] or not positions:
        return result
    with _CTX_LOCK:
        ctx = _CTX.get(id(positions))
    if ctx is None:
        return result
    log = ctx.get("log") or print
    verdict = evaluate_positions(positions, ctx, cfg)
    if verdict is None:
        return result
    eng = _ORIG["engine"]
    kind, data = verdict
    if kind == "ALL":
        pnl, allow = data
        _LAST["hit"] = "run"
        log("[profit-shield] PROFIT SHIELD hit: trade loss Rs %.2f reached the allowed Rs %.2f "
            "(%.4g%% of today's profit) - squaring off" % (-pnl, allow, cfg["pct"]))
        snapshot = _snapshot(positions)
        eng.square_off_all(kite_client, positions, log, reason=REASON)
        _emit(ctx.get("on_event"), {"type": "exit", "reason": REASON, "positions": snapshot})
        raise ShieldDone()
    for p, allow in data:
        _LAST["hit"] = p.get("tradingsymbol")
        log("[profit-shield] PROFIT SHIELD hit on %s: loss Rs %.2f reached the allowed Rs %.2f - squaring off"
            % (p.get("tradingsymbol"), -float(p.get("pnl") or 0.0), allow))
        eng._square_off_one(kite_client, p, log, reason=REASON)
        _emit(ctx.get("on_event"), {"type": "leg_exit", "reason": REASON,
                                    "tradingsymbol": p.get("tradingsymbol"), "pnl": p.get("pnl")})
        try:
            positions.remove(p)
        except ValueError:
            pass
    if not positions:
        raise ShieldDone()
    return result


def wrapped_monitor_and_exit(kite_client, positions, settings, stop_event, log, on_event, settings_path, *a, **k):
    key = id(positions)
    with _CTX_LOCK:
        _CTX[key] = {"log": log, "on_event": on_event, "settings": settings, "settings_path": settings_path}
    try:
        return _ORIG["monitor_and_exit"](kite_client, positions, settings, stop_event, log, on_event,
                                         settings_path, *a, **k)
    except ShieldDone:
        return None
    finally:
        with _CTX_LOCK:
            _CTX.pop(key, None)


# ----------------------------------------------------------------------------- Auto SL (long options)
def _auto_qty(state):
    try:
        import autosl
        with autosl._LOCK:
            for v in (autosl.G.get("tracked") or {}).values():
                if v.get("state") is state:
                    return int(v.get("qty") or 0)
    except Exception:
        pass
    return 0


class _ShieldProxy(object):
    """Stands in for autosl.core (outside profit_lock's proxy). Everything is passed through except step():
    a long-option state exits when its loss reaches the frozen share of today's profit."""

    def __init__(self, real):
        object.__setattr__(self, "_real", real)

    def __getattr__(self, name):
        return getattr(object.__getattribute__(self, "_real"), name)

    def step(self, state, ltp, params):
        real = object.__getattribute__(self, "_real")
        cfg = load_cfg()
        if cfg["enabled"] and not getattr(state, "ps_skip", False):
            try:
                if not hasattr(state, "ps_allow"):
                    state.ps_allow = freeze_allowance(cfg)
                if state.ps_allow is not None:
                    qty = _auto_qty(state)
                    px = float(ltp)
                    if qty > 0 and breached((px - float(state.entry)) * qty, state.ps_allow):
                        real.step(state, ltp, params)
                        _LAST["hit"] = "auto"
                        return (REASON, px)
            except (TypeError, ValueError, AttributeError):
                pass
        return real.step(state, ltp, params)


def hook_autosl():
    try:
        import autosl
    except Exception:
        return False
    if isinstance(getattr(autosl, "core", None), _ShieldProxy):
        return True
    autosl.core = _ShieldProxy(autosl.core)
    return True


# ----------------------------------------------------------------------------- wiring
def patch_engine(eng):
    _ORIG["engine"] = eng
    _ORIG["compute_positions_pnl"] = eng.compute_positions_pnl
    _ORIG["monitor_and_exit"] = eng.monitor_and_exit
    eng.compute_positions_pnl = wrapped_compute_positions_pnl
    eng.monitor_and_exit = wrapped_monitor_and_exit


def status(cfg=None):
    cfg = cfg or load_cfg()
    profit = realised_today()
    return dict(cfg, ok=True, day_profit=profit, allowed_loss=allowed_loss(profit, cfg["pct"]),
                last_hit=_LAST.get("hit"))


def register(appcore):
    patch_engine(appcore.engine)
    auto = hook_autosl()

    from flask import jsonify, request

    @appcore.app.route("/api/profit_shield", methods=["GET"])
    def get_profit_shield():
        return jsonify(status())

    @appcore.app.route("/api/profit_shield", methods=["POST"])
    def set_profit_shield():
        body = request.get_json(silent=True) or {}
        merged = dict(load_cfg())
        if "enabled" in body:
            merged["enabled"] = str(body["enabled"]).lower() in ("1", "true", "on", "yes")
        if "pct" in body:
            try:
                pct = float(body["pct"])
            except (TypeError, ValueError):
                return jsonify({"ok": False, "error": "percent must be a number"}), 400
            if not 0 < pct <= 100:
                return jsonify({"ok": False, "error": "percent must be between 1 and 100"}), 400
            merged["pct"] = pct
        try:
            saved = save_cfg(merged)
        except OSError as exc:
            return jsonify({"ok": False, "error": "could not save: %s" % exc}), 500
        print("[profit-shield] %s (new trade may lose %.4g%% of today's profit)"
              % ("ON" if saved["enabled"] else "OFF", saved["pct"]))
        return jsonify(status(saved))

    print("[profit-shield] add-on loaded: optional protection of today's profit for Execute, Multi, Scan+Pine%s"
          % (", Auto SL" if auto else ""))
