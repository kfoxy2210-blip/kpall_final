// KP's apps - bottom navigation bar (tiny, no dependencies). Only jumps (scrolls) to cards; never touches the engine.
(function () {
  var product = document.body.getAttribute("data-product");
  if (!product) return;
  var q = function (s) { return document.querySelector(s); };

  var tabs = {
    algo:  [["🎛", "Control", ".control-card"], ["📈", "Live", ".dashboard-grid"], ["📒", "Trades", "#tradesCard"], ["⚙", "Settings", "#settingsPanel"]],
    multi: [["🎛", "Control", ".control-card"], ["🧩", "Multi", "#multiDetails"], ["📒", "Trades", "#tradesCard"], ["⚙", "Settings", "#settingsPanel"]],
    pine:  [["🎛", "Control", ".control-card"], ["🌲", "Scan+Pine", "#scanDetails"], ["📒", "Trades", "#tradesCard"], ["⚙", "Settings", "#settingsPanel"]],
    all:   [["🎛", "Control", ".control-card"], ["📈", "Live", ".dashboard-grid"], ["🧩", "Multi", "#multiDetails"], ["🌲", "Scan", "#scanDetails"], ["🛡", "Auto SL", "#autoSlDetails"], ["📒", "Trades", "#tradesCard"]],
    auto:  [["🎛", "Control", ".control-card"], ["🛡", "Auto SL", "#autoSlDetails"], ["📒", "Trades", "#tradesCard"], ["⚙", "Settings", "#settingsPanel"]]
  }[product];
  if (!tabs) return;

  var bar = document.createElement("nav");
  bar.className = "kp-nav";
  tabs.forEach(function (t) {
    var b = document.createElement("button");
    b.type = "button";
    b.innerHTML = '<span class="ico">' + t[0] + "</span><span>" + t[1] + "</span>";
    b.addEventListener("click", function () {
      var el = q(t[2]);
      if (!el) return;
      if (el.tagName === "DETAILS") el.open = true;
      if (el.id === "settingsPanel") el.classList.remove("collapsed");
      el.classList.add("kp-target");
      el.scrollIntoView({ block: "start" });
      Array.prototype.forEach.call(bar.children, function (x) { x.classList.remove("on"); });
      b.classList.add("on");
    });
    bar.appendChild(b);
  });
  bar.firstChild.classList.add("on");
  document.body.appendChild(bar);
})();
