// KP's Algo AI - Profit lock selector (OFF / ON = book profit at 12% of invested amount).
// One selector in Control + a copy in Multi-trade, Scan + Pine and Auto SL. All edit ONE shared setting (/api/profit_lock).
(function () {
  const main = document.getElementById("profitLockBox");
  if (!main) return;
  const boxes = [];
  let current = { enabled: false, pct: 12 };

  function html(title) {
    return (title ? '<div class="pl-title">💰 ' + title + ' - profit lock <span class="muted small">(same switch as Control)</span></div>' : "") +
      '<label class="pl-field">Profit lock (optional)<select data-pl>' +
      '<option value="off">OFF - works as before</option>' +
      '<option value="on">ON - auto square-off at 12% profit of invested amount</option></select></label>' +
      '<div class="pl-hint"></div>';
  }
  function wire(root) {
    const sel = root.querySelector("select[data-pl]");
    sel.addEventListener("change", () => save(sel.value === "on"));
    boxes.push({ root: root, sel: sel, hint: root.querySelector(".pl-hint") });
  }
  function render(c) {
    current = c;
    const pct = c.pct;
    boxes.forEach((b) => {
      b.sel.value = c.enabled ? "on" : "off";
      b.sel.options[1].textContent = "ON - auto square-off at " + pct + "% profit of invested amount";
      b.root.classList.toggle("pl-on", !!c.enabled);
      b.hint.textContent = c.enabled
        ? "ON: each trade is squared off automatically when profit reaches " + pct + "% of the amount used (option BUY = premium paid; future / option SELL = margin blocked). Stop Loss / other exits still work."
        : "OFF: trades exit only by your Settings (Stop Loss, Target, Trailing, Time exit) / Auto SL - exactly as before.";
    });
  }
  async function load() {
    try { render(await (await fetch("/api/profit_lock")).json()); }
    catch (e) { boxes.forEach((b) => { b.sel.disabled = true; b.hint.textContent = "Profit lock unavailable (add-on not loaded)."; }); }
  }
  async function save(enabled) {
    try {
      const r = await fetch("/api/profit_lock", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ enabled: enabled }) });
      const d = await r.json();
      if (!r.ok) { alert(d.error || "Could not save"); load(); return; }
      render(d);
    } catch (e) { alert("Could not save profit lock: " + e); load(); }
  }
  main.innerHTML = html("");
  wire(main);
  const names = ["Multi-trade", "Scan + Pine", "Auto SL / Target"];
  document.querySelectorAll(".multi-box").forEach((box, i) => {
    if (box.querySelector(":scope > .pl-box")) return;
    const root = document.createElement("div");
    root.className = "pl-box pl-mini";
    root.innerHTML = html(names[i] || "This section");
    const ib = box.querySelector(":scope > .instrument-box");
    box.insertBefore(root, ib ? ib.nextSibling : box.firstChild);
    wire(root);
  });
  load();
})();
